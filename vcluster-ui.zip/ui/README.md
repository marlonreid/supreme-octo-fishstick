# vcluster-ui

React + TypeScript + Vite frontend for the vCluster platform.

## Setup

```bash
npm install
npm run dev
# http://localhost:5173
```

Requires the API running on `http://localhost:5000`.  
Vite proxies all `/api/*` requests — no CORS config needed in dev.

## Structure

```
src/
├── types/api.ts                 # TypeScript types mirroring the API models
├── services/api.ts              # All fetch calls + SSE subscription
├── hooks/
│   ├── useEnvironments.ts       # List with 15s polling
│   └── useProgress.ts           # SSE stream per environment
└── components/
    ├── StatusBadge.tsx
    ├── ProgressLog.tsx
    ├── EnvironmentCard.tsx
    └── CreateEnvironmentModal.tsx
```
