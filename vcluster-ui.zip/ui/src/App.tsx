import { useState } from 'react'
import type { VClusterSummary } from './types/api'
import { useEnvironments } from './hooks/useEnvironments'
import { EnvironmentCard } from './components/EnvironmentCard'
import { CreateEnvironmentModal } from './components/CreateEnvironmentModal'

type Tab = 'active' | 'archived'

export default function App() {
  const { environments, loading, error, refresh } = useEnvironments()
  const [tab, setTab] = useState<Tab>('active')
  const [showCreate, setShowCreate] = useState(false)

  const active   = environments.filter(e => e.status !== 'Deleted')
  const archived = environments.filter(e => e.status === 'Deleted')
  const visible  = tab === 'active' ? active : archived

  const handleCreated = (_env: VClusterSummary) => {
    setShowCreate(false)
    refresh()
  }

  return (
    <div style={{ minHeight: '100vh', background: '#0d1117', color: '#c9d1d9', fontFamily: 'system-ui, sans-serif' }}>

      {/* Nav */}
      <nav style={styles.nav}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 32 }}>
          <span style={{ fontWeight: 700, fontSize: 16, color: '#e2e8f0' }}>⎈ vCluster Platform</span>
          <div style={{ display: 'flex', gap: 2 }}>
            <NavTab label={`Active (${active.length})`}   active={tab === 'active'}   onClick={() => setTab('active')} />
            <NavTab label={`Archived (${archived.length})`} active={tab === 'archived'} onClick={() => setTab('archived')} />
          </div>
        </div>
        <button style={styles.createBtn} onClick={() => setShowCreate(true)}>
          + New Environment
        </button>
      </nav>

      {/* Main */}
      <main style={{ maxWidth: 900, margin: '0 auto', padding: '32px 24px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
          <h1 style={{ margin: 0, fontSize: 20, fontWeight: 600, color: '#e2e8f0' }}>
            {tab === 'active' ? 'Active Environments' : 'Archived'}
          </h1>
          <button onClick={refresh} style={styles.refreshBtn}>↻ Refresh</button>
        </div>

        {loading && <p style={{ color: '#4a5568' }}>Loading...</p>}
        {error   && <p style={{ color: '#fc8181' }}>{error}</p>}

        {!loading && visible.length === 0 && (
          <p style={{ color: '#4a5568', fontSize: 14 }}>
            {tab === 'active'
              ? 'No active environments. Click "+ New Environment" to create one.'
              : 'No archived environments.'}
          </p>
        )}

        {visible.map(env => (
          <EnvironmentCard key={env.id} env={env} onRefresh={refresh} />
        ))}
      </main>

      {showCreate && (
        <CreateEnvironmentModal
          onCreated={handleCreated}
          onClose={() => setShowCreate(false)}
        />
      )}
    </div>
  )
}

function NavTab({ label, active, onClick }: { label: string; active: boolean; onClick: () => void }) {
  return (
    <button onClick={onClick} style={{
      background: 'none',
      border: 'none',
      borderBottom: `2px solid ${active ? '#58a6ff' : 'transparent'}`,
      padding: '6px 14px',
      color: active ? '#e2e8f0' : '#8b949e',
      fontWeight: active ? 600 : 400,
      fontSize: 14,
      cursor: 'pointer',
      transition: 'color 0.15s',
    }}>
      {label}
    </button>
  )
}

const styles: Record<string, React.CSSProperties> = {
  nav: {
    background: '#161b22',
    borderBottom: '1px solid #21262d',
    height: 56,
    padding: '0 24px',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    position: 'sticky',
    top: 0,
    zIndex: 50,
  },
  createBtn: {
    background: '#238636',
    border: 'none',
    borderRadius: 6,
    padding: '6px 16px',
    color: '#fff',
    fontWeight: 600,
    fontSize: 14,
    cursor: 'pointer',
  },
  refreshBtn: {
    background: 'none',
    border: '1px solid #30363d',
    borderRadius: 6,
    padding: '4px 12px',
    color: '#8b949e',
    fontSize: 12,
    cursor: 'pointer',
  },
}
