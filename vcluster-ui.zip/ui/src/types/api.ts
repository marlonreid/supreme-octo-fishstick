export type EnvironmentStatus =
  | 'Queued'
  | 'CreatingCluster'
  | 'ClusterReady'
  | 'DeployingWorkload'
  | 'Ready'
  | 'Sleeping'
  | 'Failed'
  | 'Deleting'
  | 'Deleted'

export type ProgressEventType =
  | 'Info'
  | 'PipelineQueued'
  | 'PipelineStarted'
  | 'PipelineLog'
  | 'PipelineComplete'
  | 'PipelineFailed'
  | 'ClusterReady'
  | 'DeployStarted'
  | 'EnvironmentReady'
  | 'Error'
  | 'StreamComplete'

export interface VClusterSummary {
  id: string
  name: string
  namespace: string
  status: EnvironmentStatus
  createdAt: string
  expiresAt: string | null
  currentCostGbp: number | null
}

export interface PodStatus {
  name: string
  phase: string
  ready: boolean
  restartCount: number
  startedAt: string | null
}

export interface VClusterDetail extends VClusterSummary {
  k8sVersion: string | null
  readyAt: string | null
  ttlHours: number | null
  costThresholdGbp: number | null
  pods: PodStatus[]
  kubeconfigSecretName: string | null
  errorMessage: string | null
}

export interface ProgressEvent {
  environmentId: string
  type: ProgressEventType
  message: string
  timestamp: string
  detail: string | null
}

export interface CreateVClusterRequest {
  name: string
  k8sVersion?: string
  ttlHours?: number
  costThresholdGbp?: number
}

export interface ApiResponse<T> {
  success: boolean
  data: T | null
  error: string | null
}
