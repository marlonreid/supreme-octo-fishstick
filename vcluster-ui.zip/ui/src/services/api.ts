import type {
  ApiResponse,
  CreateVClusterRequest,
  ProgressEvent,
  VClusterDetail,
  VClusterSummary,
} from '../types/api'

const BASE = '/api/environments'

async function request<T>(url: string, init?: RequestInit): Promise<T> {
  const res = await fetch(url, init)
  if (!res.ok) {
    const body = await res.json().catch(() => ({ error: res.statusText }))
    throw new Error((body as ApiResponse<unknown>)?.error ?? `HTTP ${res.status}`)
  }
  const json: ApiResponse<T> = await res.json()
  if (!json.success || json.data === null) throw new Error(json.error ?? 'Unknown error')
  return json.data
}

export const api = {
  listEnvironments: () =>
    request<VClusterSummary[]>(BASE),

  getEnvironment: (id: string) =>
    request<VClusterDetail>(`${BASE}/${id}`),

  createEnvironment: (payload: CreateVClusterRequest) =>
    request<VClusterSummary>(BASE, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    }),

  deleteEnvironment: async (id: string): Promise<void> => {
    const res = await fetch(`${BASE}/${id}`, { method: 'DELETE' })
    if (!res.ok) throw new Error(`HTTP ${res.status}`)
  },

  sleepEnvironment: async (id: string): Promise<void> => {
    await fetch(`${BASE}/${id}/sleep`, { method: 'POST' })
  },

  wakeEnvironment: async (id: string): Promise<void> => {
    await fetch(`${BASE}/${id}/wake`, { method: 'POST' })
  },

  getKubeconfig: async (id: string): Promise<string> => {
    const data = await request<{ kubeconfig: string }>(`${BASE}/${id}/kubeconfig`)
    return data.kubeconfig
  },

  subscribeProgress: (
    id: string,
    onEvent: (evt: ProgressEvent) => void,
    onComplete: () => void,
    onError: () => void
  ): EventSource => {
    const source = new EventSource(`${BASE}/${id}/progress`)

    source.onmessage = (e: MessageEvent) => {
      const evt: ProgressEvent = JSON.parse(e.data as string)
      if (evt.type === 'StreamComplete') {
        source.close()
        onComplete()
      } else {
        onEvent(evt)
      }
    }

    source.onerror = () => {
      source.close()
      onError()
    }

    return source
  },
}
