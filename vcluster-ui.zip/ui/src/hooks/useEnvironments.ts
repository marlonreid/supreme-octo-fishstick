import { useCallback, useEffect, useState } from 'react'
import type { VClusterSummary } from '../types/api'
import { api } from '../services/api'

export function useEnvironments() {
  const [environments, setEnvironments] = useState<VClusterSummary[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const refresh = useCallback(async () => {
    try {
      const data = await api.listEnvironments()
      setEnvironments(data)
      setError(null)
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Unknown error')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    refresh()
    const interval = setInterval(refresh, 15_000)
    return () => clearInterval(interval)
  }, [refresh])

  return { environments, loading, error, refresh }
}
