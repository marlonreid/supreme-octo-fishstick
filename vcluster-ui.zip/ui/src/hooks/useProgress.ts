import { useEffect, useRef, useState } from 'react'
import type { ProgressEvent } from '../types/api'
import { api } from '../services/api'

export function useProgress(environmentId: string | null) {
  const [events, setEvents] = useState<ProgressEvent[]>([])
  const [complete, setComplete] = useState(false)
  const sourceRef = useRef<EventSource | null>(null)

  useEffect(() => {
    if (!environmentId) return

    setEvents([])
    setComplete(false)

    const source = api.subscribeProgress(
      environmentId,
      (evt) => setEvents((prev) => [...prev, evt]),
      () => setComplete(true),
      () => setComplete(true)
    )

    sourceRef.current = source
    return () => source.close()
  }, [environmentId])

  return { events, complete }
}
