import type { EnvironmentStatus } from '../types/api'

interface BadgeConfig { bg: string; color: string; label: string }

const STYLES: Record<EnvironmentStatus, BadgeConfig> = {
  Queued:            { bg: '#2d3748', color: '#a0aec0', label: 'Queued' },
  CreatingCluster:   { bg: '#2a4365', color: '#63b3ed', label: 'Creating cluster' },
  ClusterReady:      { bg: '#1a365d', color: '#76e4f7', label: 'Cluster ready' },
  DeployingWorkload: { bg: '#2a4365', color: '#63b3ed', label: 'Deploying' },
  Ready:             { bg: '#1c4532', color: '#68d391', label: 'Ready' },
  Sleeping:          { bg: '#322659', color: '#b794f4', label: 'Sleeping' },
  Failed:            { bg: '#63171b', color: '#fc8181', label: 'Failed' },
  Deleting:          { bg: '#652b19', color: '#f6ad55', label: 'Deleting' },
  Deleted:           { bg: '#1a202c', color: '#718096', label: 'Deleted' },
}

export function StatusBadge({ status }: { status: EnvironmentStatus }) {
  const s = STYLES[status]
  return (
    <span style={{
      background: s.bg,
      color: s.color,
      padding: '2px 10px',
      borderRadius: 12,
      fontSize: 12,
      fontWeight: 600,
      letterSpacing: '0.03em',
      whiteSpace: 'nowrap',
    }}>
      {s.label}
    </span>
  )
}
