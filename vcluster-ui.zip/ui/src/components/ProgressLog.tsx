import { useEffect, useRef } from 'react'
import type { ProgressEvent, ProgressEventType } from '../types/api'

const COLOUR: Partial<Record<ProgressEventType, string>> = {
  Info:              '#a0aec0',
  PipelineQueued:    '#63b3ed',
  PipelineStarted:   '#63b3ed',
  PipelineLog:       '#4a5568',
  PipelineComplete:  '#68d391',
  PipelineFailed:    '#fc8181',
  ClusterReady:      '#76e4f7',
  DeployStarted:     '#63b3ed',
  EnvironmentReady:  '#68d391',
  Error:             '#fc8181',
}

interface Props {
  events: ProgressEvent[]
  complete: boolean
}

export function ProgressLog({ events, complete }: Props) {
  const bottomRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [events])

  if (events.length === 0 && !complete) {
    return (
      <p style={{ color: '#4a5568', fontStyle: 'italic', fontSize: 13, margin: 0 }}>
        Waiting for pipeline...
      </p>
    )
  }

  return (
    <div style={{
      background: '#0d1117',
      border: '1px solid #21262d',
      borderRadius: 8,
      padding: '12px 16px',
      fontFamily: 'ui-monospace, monospace',
      fontSize: 12,
      lineHeight: 1.7,
      maxHeight: 300,
      overflowY: 'auto',
    }}>
      {events.map((evt, i) => (
        <div key={i} style={{ color: COLOUR[evt.type] ?? '#a0aec0' }}>
          <span style={{ color: '#4a5568', marginRight: 8 }}>
            {new Date(evt.timestamp).toLocaleTimeString()}
          </span>
          {evt.message}
        </div>
      ))}
      {complete && (
        <div style={{ color: '#4a5568', marginTop: 8 }}>── stream closed ──</div>
      )}
      <div ref={bottomRef} />
    </div>
  )
}
