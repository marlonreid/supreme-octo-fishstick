import { useState } from 'react'
import type { CreateVClusterRequest, VClusterSummary } from '../types/api'
import { api } from '../services/api'

interface Props {
  onCreated: (env: VClusterSummary) => void
  onClose: () => void
}

export function CreateEnvironmentModal({ onCreated, onClose }: Props) {
  const [name, setName] = useState('')
  const [k8sVersion, setK8sVersion] = useState('')
  const [ttlHours, setTtlHours] = useState('')
  const [costLimit, setCostLimit] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const submit = async () => {
    if (!name.trim()) { setError('Name is required'); return }
    setLoading(true)
    setError(null)
    try {
      const payload: CreateVClusterRequest = {
        name: name.trim(),
        ...(k8sVersion && { k8sVersion }),
        ...(ttlHours && { ttlHours: parseInt(ttlHours) }),
        ...(costLimit && { costThresholdGbp: parseFloat(costLimit) }),
      }
      const env = await api.createEnvironment(payload)
      onCreated(env)
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to create')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div style={styles.overlay}>
      <div style={styles.modal}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
          <h2 style={{ margin: 0, fontSize: 18, color: '#e2e8f0' }}>New Environment</h2>
          <button onClick={onClose} style={styles.closeBtn}>✕</button>
        </div>

        <label style={styles.label}>Name *</label>
        <input
          style={styles.input}
          value={name}
          onChange={e => setName(e.target.value)}
          placeholder="my-feature"
          autoFocus
        />

        <label style={styles.label}>K8s version</label>
        <input
          style={styles.input}
          value={k8sVersion}
          onChange={e => setK8sVersion(e.target.value)}
          placeholder="leave blank for default"
        />

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
          <div>
            <label style={styles.label}>TTL (hours)</label>
            <input style={styles.input} type="number" value={ttlHours} onChange={e => setTtlHours(e.target.value)} placeholder="e.g. 8" />
          </div>
          <div>
            <label style={styles.label}>Cost limit (£)</label>
            <input style={styles.input} type="number" step="0.01" value={costLimit} onChange={e => setCostLimit(e.target.value)} placeholder="e.g. 5.00" />
          </div>
        </div>

        {error && <p style={{ color: '#fc8181', fontSize: 13, margin: '8px 0 0' }}>{error}</p>}

        <div style={{ display: 'flex', gap: 12, marginTop: 24 }}>
          <button style={styles.primaryBtn} onClick={submit} disabled={loading}>
            {loading ? 'Creating...' : 'Create'}
          </button>
          <button style={styles.secondaryBtn} onClick={onClose} disabled={loading}>
            Cancel
          </button>
        </div>
      </div>
    </div>
  )
}

const styles: Record<string, React.CSSProperties> = {
  overlay: {
    position: 'fixed', inset: 0,
    background: 'rgba(0,0,0,0.75)',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    zIndex: 100,
  },
  modal: {
    background: '#161b22',
    border: '1px solid #30363d',
    borderRadius: 12,
    padding: 32,
    width: 480,
    maxWidth: '90vw',
  },
  label: {
    display: 'block',
    fontSize: 12,
    color: '#718096',
    fontWeight: 600,
    marginBottom: 6,
    marginTop: 16,
  },
  input: {
    width: '100%',
    background: '#0d1117',
    border: '1px solid #30363d',
    borderRadius: 6,
    padding: '8px 12px',
    color: '#e2e8f0',
    fontSize: 14,
    outline: 'none',
  },
  primaryBtn: {
    background: '#238636',
    border: 'none',
    borderRadius: 6,
    padding: '8px 20px',
    color: '#fff',
    fontSize: 14,
    fontWeight: 600,
    cursor: 'pointer',
  },
  secondaryBtn: {
    background: 'transparent',
    border: '1px solid #30363d',
    borderRadius: 6,
    padding: '8px 20px',
    color: '#8b949e',
    fontSize: 14,
    cursor: 'pointer',
  },
  closeBtn: {
    background: 'none',
    border: 'none',
    color: '#8b949e',
    fontSize: 18,
    cursor: 'pointer',
    padding: 4,
    lineHeight: 1,
  },
}
