PE-controlled module. Do NOT change from app repos.

Inputs: environment, customer, project, workload_name, allow_vnet_subnet_ids, enable_private_endpoint.
All naming/location/subscription/tags resolved by PE configs passed via `platform_config_path` and `tags_dict_path`.
