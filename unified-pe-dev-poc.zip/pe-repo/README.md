# PE Repo — Terraform Guardrails & Reusable Stacks

This repository is **owned by Platform Engineering**. App teams **do not** copy code; their pipelines **check out this repo** and call the Terraform here.

## Layout
- `stacks/`: opinionated **root modules** (wrappers) that encode naming, tags, remote state, and provider config.
- `modules/`: reusable components called by stacks; can also be used directly if allowed.
- `policy/`: OPA Conftest policies for plan-time checks.
- `platform/`: central configuration (subs, regions, diagnostics, tag dictionaries).

> App pipelines should usually call a **stack** (easier & stricter). PE keeps full control over RG naming, location, SKUs, tags, backends.
