# Process: Team proposals → critique → unified approach (PE-owned infra code)

## Developer
- Wants a **single pipeline** that *references* PE’s Terraform so there’s no infra code to copy.
- Provides only `environment`, `customer`, `project`, `workload_name` (in `infra/inputs.tfvars`).

## Platform Engineering
- Provides versioned stacks/modules and policy in **PE repo**.
- Controls naming, subscriptions, regions, SKUs, tags, diagnostics centrally via `platform/` configs.
- Publishes a least-privilege service connection (`svc-conn-pe-limited`).

## Security
- OPA Conftest runs on every plan.
- Azure Policy at subscription level prevents drift.
- Secrets via Key Vault (not shown here, but recommended).

## Technical Manager
- One pipeline per app, zero handoffs.
- Fast PR feedback, safe apply on main.
- Low maintenance: PE updates propagate to all apps (pin ref if needed).

## Unified
- App pipeline uses **multi-repo checkout** to pull **PE repo** at a controlled ref.
- Runs Terraform **from the PE stack path** with minimal variables.
- PE retains control of naming/location/subscription/tiers/tags.

See `.ado/azure-pipelines.yml` for exact steps.
