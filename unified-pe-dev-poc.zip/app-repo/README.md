# App Repo — Single Pipeline using PE Terraform

This repo belongs to the **app team**. It does **not** own infra code.
Pipeline **checks out the PE repo** and runs Terraform from there, passing only minimal variables.

See `.ado/azure-pipelines.yml`.
