# App Repo (Enhanced) — Single Pipeline using PE Stacks by Tag

This repo **does not** contain infra code. The pipeline checks out the **PE repo at a tag** and runs Terraform from the **PE stack**.

- Minimal inputs: `infra/inputs.tfvars`
- Plan artifacts are published and the **exact plan** is applied.
- Uses OIDC-enabled service connection (configure in ADO).
- Centralized backend is configured by PE via `-backend-config` parameters.
- Drift detection nightly pipeline included.
