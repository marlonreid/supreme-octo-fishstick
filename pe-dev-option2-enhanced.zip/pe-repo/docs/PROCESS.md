# Process (Round 2): proposals → critiques → unified

## Developer (DX)
- Single app pipeline
- Minimal inputs via tfvars
- Uses PE stacks by tag

## Platform Engineering (governance & cost)
- Full control: subs/regions/naming/tags/SKUs/networking in platform config
- OIDC service connection, custom roles, centralized backend
- ADO templates for consistent steps
- Versioned policy bundle

## Security
- OPA plan gates
- Azure Policy runtime
- Private endpoint + selected networks only
- No dev access to network IDs

## Technical Manager
- One pipeline, no handoffs
- Pin-by-tag for safe rollouts
- Drift detection nightly
- Infracost optional

## Unified
- App pipelines consume `stacks/` by **tagged PE repo**
- Apply uses **exact plan artifact**
- Backend in PE subscription; RBAC’d
