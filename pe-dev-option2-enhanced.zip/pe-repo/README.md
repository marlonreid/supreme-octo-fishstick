# PE Repo (Enhanced) — Terraform Guardrails, Policy Bundles, and ADO Templates

**Owned by Platform Engineering.** App pipelines *reference* this repo at a **tag** (SemVer), not by copying code.

## Highlights
- **Stacks (root)** under `stacks/` — golden entry points for apps.
- **Modules** under `modules/` — building blocks.
- **Platform config** under `platform/` — subscriptions, regions, diagnostics, naming, VNets/Subnets for private endpoints.
- **Policy bundle** under `policy/bundle/` — OPA bundle versioned with tags.
- **ADO templates** under `.ado/templates/` — standard Plan/Apply with tflint, checkov, OPA, Infracost, plan artifacting.
- **SemVer tags** for releases; apps pin a tag.

> Storage accounts are restricted to **selected networks only** with **private endpoints** in a **PE-defined subnet**. Devs do not pass network IDs.
