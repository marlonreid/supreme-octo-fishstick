This module enforces:
- HTTPS-only, TLS 1.2+, public access disabled, deny-by-default network rules
- Diagnostics to Log Analytics
- **Private endpoint** on a **PE-defined subnet**; devs cannot set network IDs
- Subscriptions/regions, naming, and tags from PE platform config
