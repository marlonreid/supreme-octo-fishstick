# HTML Screenshot POC

A Kubernetes-native pipeline that:

1. **Feeder Service** – pushes HTML payloads into an **Azure Event Hub**
2. **Screenshot Service** – reads those payloads, renders them with **Playwright + headless Chromium** and saves the PNG to **Azure Blob Storage**
3. **KEDA** – automatically scales the Screenshot Service pods based on the number of unprocessed events

```
┌────────────┐     Event Hub     ┌─────────────────────────────────┐    Azure Blob
│   Feeder   │──── (messages) ──▶│  Screenshot Service (N pods)    │──▶  Storage
│  (k8s Job) │                   │  EventProcessorClient           │    /screenshots/
└────────────┘                   │  → Playwright / Chromium        │    yyyy/MM/dd/<id>.png
                                 │  → BlobStorageService           │
                                 └─────────────────────────────────┘
                                          ▲
                                    KEDA ScaledObject
                                 (azure-event-hub trigger)
```

---

## Repository Layout

```
.
├── src/
│   ├── ScreenshotService/      # Worker service (.NET 8)
│   │   ├── Models/
│   │   │   └── HtmlRenderRequest.cs
│   │   ├── Services/
│   │   │   ├── Options.cs
│   │   │   ├── EventHubProcessorService.cs
│   │   │   ├── PlaywrightRenderer.cs
│   │   │   └── BlobStorageService.cs
│   │   ├── Program.cs
│   │   ├── appsettings.json
│   │   ├── ScreenshotService.csproj
│   │   └── Dockerfile
│   └── FeederService/          # One-shot console app (.NET 8)
│       ├── Program.cs
│       ├── FeederService.csproj
│       └── Dockerfile
└── helm/
    ├── screenshot-service/     # Helm chart – Deployment + KEDA ScaledObject
    └── feeder-service/         # Helm chart – Kubernetes Job
```

---

## Prerequisites

| Tool | Purpose | Install |
|------|---------|---------|
| .NET 8 SDK | Build & run locally | https://dotnet.microsoft.com/download |
| Docker | Build container images | https://docs.docker.com/get-docker/ |
| kubectl | Interact with local cluster | https://kubernetes.io/docs/tasks/tools/ |
| Helm ≥ 3 | Deploy charts | https://helm.sh/docs/intro/install/ |
| KEDA ≥ 2.13 | Event-driven autoscaling | See below |
| Rancher Desktop / k3s | Local Kubernetes | https://rancherdesktop.io/ |

---

## Azure Resources (manual setup)

Create the following in the Azure portal or with the Azure CLI.

### 1 – Event Hub Namespace + Event Hub

```bash
# Create resource group
az group create --name rg-screenshot-poc --location uksouth

# Create Event Hub namespace (Standard tier required for consumer groups)
az eventhubs namespace create \
  --resource-group rg-screenshot-poc \
  --name evhns-screenshot-poc \
  --sku Standard \
  --location uksouth

# Create the Event Hub (topic)
az eventhubs eventhub create \
  --resource-group rg-screenshot-poc \
  --namespace-name evhns-screenshot-poc \
  --name html-render-jobs \
  --partition-count 4 \
  --message-retention 1

# Grab the namespace connection string (used by both services + KEDA)
az eventhubs namespace authorization-rule keys list \
  --resource-group rg-screenshot-poc \
  --namespace-name evhns-screenshot-poc \
  --name RootManageSharedAccessKey \
  --query primaryConnectionString -o tsv
```

### 2 – Storage Account (checkpoints + screenshots)

You can use the same storage account for both containers, or separate ones.

```bash
az storage account create \
  --resource-group rg-screenshot-poc \
  --name stscreenshotpoc \
  --sku Standard_LRS \
  --location uksouth

# Grab the connection string
az storage account show-connection-string \
  --resource-group rg-screenshot-poc \
  --name stscreenshotpoc \
  --query connectionString -o tsv
```

> The **`checkpoints`** and **`screenshots`** blob containers are created automatically by the Screenshot Service on first start.

---

## Install KEDA on your local cluster

```bash
helm repo add kedacore https://kedacore.github.io/charts
helm repo update
helm install keda kedacore/keda \
  --namespace keda \
  --create-namespace \
  --version 2.16.0
```

Verify KEDA is running:

```bash
kubectl get pods -n keda
```

---

## Build & Push Docker Images

Replace `<registry>` with your local registry address (e.g. `localhost:5000` for a local registry in Rancher Desktop, or your Docker Hub username).

```bash
# Screenshot Service
docker build -t <registry>/screenshot-service:latest ./src/ScreenshotService
docker push <registry>/screenshot-service:latest

# Feeder Service
docker build -t <registry>/feeder-service:latest ./src/FeederService
docker push <registry>/feeder-service:latest
```

> **Rancher Desktop tip:** If you're using the built-in containerd runtime with Rancher Desktop, use `nerdctl` instead of `docker` and images are automatically available in the cluster without pushing.
>
> ```bash
> nerdctl build -t screenshot-service:latest ./src/ScreenshotService
> nerdctl build -t feeder-service:latest ./src/FeederService
> ```
> Then set `image.pullPolicy: Never` in the values files.

---

## Deploy the Screenshot Service

```bash
helm install screenshot-service ./helm/screenshot-service \
  --namespace screenshot-poc \
  --create-namespace \
  --set image.repository=<registry>/screenshot-service \
  --set azure.eventHubConnectionString="<YOUR_EVENT_HUB_CONNECTION_STRING>" \
  --set azure.eventHubName="html-render-jobs" \
  --set azure.checkpointConnectionString="<YOUR_STORAGE_CONNECTION_STRING>" \
  --set azure.screenshotConnectionString="<YOUR_STORAGE_CONNECTION_STRING>"
```

Verify the deployment:

```bash
kubectl get deployment -n screenshot-poc
kubectl get scaledobject -n screenshot-poc
kubectl get pods -n screenshot-poc
```

> With `keda.minReplicaCount: 0` (the default), there will be **0 pods** until the feeder publishes messages. This is intentional – KEDA scales from zero when events arrive.

---

## Send Test Messages (Feeder Service)

### Option A – Kubernetes Job (recommended for end-to-end testing)

```bash
helm install feeder ./helm/feeder-service \
  --namespace screenshot-poc \
  --set image.repository=<registry>/feeder-service \
  --set azure.eventHubConnectionString="<YOUR_EVENT_HUB_CONNECTION_STRING>" \
  --set azure.eventHubName="html-render-jobs" \
  --set messageCount=50
```

Watch the Job run:

```bash
kubectl get jobs -n screenshot-poc -w
kubectl logs -n screenshot-poc -l app.kubernetes.io/name=feeder-service --tail=50
```

To run the feeder again, uninstall and reinstall (each install creates a new Job name):

```bash
helm uninstall feeder -n screenshot-poc
helm install feeder ./helm/feeder-service ...
```

### Option B – Run locally

```bash
export EVENT_HUB_CONNECTION_STRING="<YOUR_CONNECTION_STRING>"
export EVENT_HUB_NAME="html-render-jobs"
export MESSAGE_COUNT=20

cd src/FeederService
dotnet run
```

---

## Watch KEDA Scale

In a separate terminal, watch pods scale up as events accumulate:

```bash
watch kubectl get pods -n screenshot-poc
```

And monitor KEDA's view of the scaler:

```bash
kubectl describe scaledobject -n screenshot-poc
kubectl get hpa -n screenshot-poc   # KEDA creates an HPA under the hood
```

---

## Verify Screenshots in Blob Storage

```bash
az storage blob list \
  --connection-string "<YOUR_STORAGE_CONNECTION_STRING>" \
  --container-name screenshots \
  --output table
```

Or open the Azure Portal → Storage Account → Containers → screenshots.

Screenshots are stored under the path pattern `screenshots/yyyy/MM/dd/<job-id>.png`.

---

## Configuration Reference

### Screenshot Service (`helm/screenshot-service/values.yaml`)

| Key | Default | Description |
|-----|---------|-------------|
| `azure.eventHubConnectionString` | `""` | Event Hub namespace connection string |
| `azure.eventHubName` | `html-render-jobs` | Event Hub name |
| `azure.consumerGroup` | `$Default` | Consumer group |
| `azure.checkpointConnectionString` | `""` | Storage for EventProcessorClient checkpoints |
| `azure.checkpointContainerName` | `checkpoints` | Checkpoint blob container |
| `azure.screenshotConnectionString` | `""` | Storage for output screenshots |
| `azure.screenshotContainerName` | `screenshots` | Screenshot blob container |
| `app.maxConcurrentCalls` | `4` | Max concurrent Playwright pages per pod |
| `keda.enabled` | `true` | Install KEDA ScaledObject |
| `keda.minReplicaCount` | `0` | Scale to zero when idle |
| `keda.maxReplicaCount` | `10` | Hard pod ceiling |
| `keda.unprocessedEventThreshold` | `10` | Events per partition before adding a pod |
| `keda.activationThreshold` | `1` | Events before scaling from 0 |
| `keda.pollingInterval` | `15` | Seconds between KEDA lag checks |
| `keda.cooldownPeriod` | `60` | Seconds before scaling down |
| `resources.requests.memory` | `512Mi` | Chromium needs memory – don't set this too low |

### Feeder Service (`helm/feeder-service/values.yaml`)

| Key | Default | Description |
|-----|---------|-------------|
| `azure.eventHubConnectionString` | `""` | Event Hub connection string |
| `azure.eventHubName` | `html-render-jobs` | Event Hub name |
| `messageCount` | `50` | Messages to publish per Job run |

---

## Event Payload Schema

The Feeder publishes JSON messages with the following shape:

```json
{
  "id": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
  "html": "<html>...</html>",
  "viewportWidth": 1280,
  "viewportHeight": 720,
  "metadata": {
    "source": "feeder-service",
    "index": "0"
  }
}
```

Any service that can write this JSON to the Event Hub can trigger a screenshot render.

---

## Running Locally (without Kubernetes)

For fast inner-loop development, run both services directly:

```bash
# Terminal 1 – Screenshot Service
cd src/ScreenshotService
# Install Playwright browsers on first run
dotnet tool install --global Microsoft.Playwright.CLI 2>/dev/null || true
playwright install chromium

export EventHub__ConnectionString="<YOUR_EH_CONNECTION_STRING>"
export EventHub__EventHubName="html-render-jobs"
export EventHub__CheckpointConnectionString="<YOUR_STORAGE_CONNECTION_STRING>"
export BlobStorage__ConnectionString="<YOUR_STORAGE_CONNECTION_STRING>"
dotnet run

# Terminal 2 – Feeder
cd src/FeederService
export EVENT_HUB_CONNECTION_STRING="<YOUR_EH_CONNECTION_STRING>"
export EVENT_HUB_NAME="html-render-jobs"
export MESSAGE_COUNT=5
dotnet run
```

---

## Architecture Notes

### Why `blobMetadata` checkpoint strategy?

KEDA's `azure-event-hub` trigger needs to calculate consumer lag (latest offset minus checkpoint offset). The .NET `EventProcessorClient` stores checkpoints as **blob metadata** (not blob content), which corresponds to KEDA's `checkpointStrategy: blobMetadata`. Both KEDA and the service must point at the same blob container.

### Scale-to-zero behaviour

When `minReplicaCount: 0`, KEDA will terminate all pods after the `cooldownPeriod` elapses with no events. The next batch of events will trigger KEDA to spin pods back up within the `pollingInterval`. During the cold-start (~5-10 s for .NET + Chromium launch), a few events may accumulate in the hub before being processed – this is expected.

### Concurrent Playwright pages

Each pod opens a single long-lived Chromium instance. The `maxConcurrentCalls` setting (default 4) controls how many browser pages are open simultaneously per pod. A `SemaphoreSlim` ensures this limit is respected. Tune this based on your pod memory limit.

### Partition ownership

The `EventProcessorClient` claims partition ownership via blob leases. If you scale to more pods than partitions, the extra pods will remain idle (no work to claim). The recommended maximum replica count is the partition count of your Event Hub.

---

## Troubleshooting

**Pods stuck at 0 even after feeder runs**
- Check KEDA logs: `kubectl logs -n keda -l app=keda-operator --tail=100`
- Verify the checkpoint container exists and the connection string is correct
- Confirm the consumer group matches between the Screenshot Service and KEDA trigger

**Chromium crashes / OOMKilled**
- Increase `resources.limits.memory` to at least `1.5Gi` and `resources.requests.memory` to `512Mi`
- Reduce `app.maxConcurrentCalls` to 1 or 2

**`PLAYWRIGHT_BROWSERS_PATH` not found**
- Ensure the image is built from `mcr.microsoft.com/playwright/dotnet:v1.49.0-noble`
- The env var `PLAYWRIGHT_BROWSERS_PATH=/ms-playwright` must be set in the container

**Event Hub connection error (`401 Unauthorized`)**
- Confirm the connection string is the full namespace-level string (contains `SharedAccessKeyName` and `SharedAccessKey`)
- Do **not** use the entity-path scoped connection string for KEDA – it needs the namespace scope to enumerate offsets
