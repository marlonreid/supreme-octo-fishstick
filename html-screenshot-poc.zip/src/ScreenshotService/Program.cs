using ScreenshotService.Services;

var builder = Host.CreateApplicationBuilder(args);

builder.Services.Configure<EventHubOptions>(
    builder.Configuration.GetSection("EventHub"));

builder.Services.Configure<BlobStorageOptions>(
    builder.Configuration.GetSection("BlobStorage"));

builder.Services.AddSingleton<PlaywrightRenderer>();
builder.Services.AddSingleton<BlobStorageService>();
builder.Services.AddHostedService<EventHubProcessorService>();

var host = builder.Build();

// Ensure the Playwright renderer is initialised before events start arriving
var renderer = host.Services.GetRequiredService<PlaywrightRenderer>();
await renderer.InitializeAsync();

await host.RunAsync();
