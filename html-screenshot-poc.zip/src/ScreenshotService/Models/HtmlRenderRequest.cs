namespace ScreenshotService.Models;

/// <summary>
/// The JSON payload sent to the Event Hub.
/// </summary>
public sealed class HtmlRenderRequest
{
    /// <summary>Unique identifier for this render job.</summary>
    public string Id { get; set; } = Guid.NewGuid().ToString();

    /// <summary>The raw HTML string to render.</summary>
    public string Html { get; set; } = string.Empty;

    /// <summary>
    /// Optional metadata forwarded to blob metadata tags
    /// (e.g. originating system, template name, …).
    /// </summary>
    public Dictionary<string, string> Metadata { get; set; } = new();

    /// <summary>
    /// Optional viewport width in pixels (default 1280).
    /// </summary>
    public int ViewportWidth { get; set; } = 1280;

    /// <summary>
    /// Optional viewport height in pixels (default 720).
    /// </summary>
    public int ViewportHeight { get; set; } = 720;
}
