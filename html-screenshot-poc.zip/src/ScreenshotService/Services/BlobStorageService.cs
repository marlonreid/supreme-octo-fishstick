using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using Microsoft.Extensions.Options;

namespace ScreenshotService.Services;

public sealed class BlobStorageService
{
    private readonly BlobContainerClient          _container;
    private readonly ILogger<BlobStorageService>  _logger;

    public BlobStorageService(
        IOptions<BlobStorageOptions>   options,
        ILogger<BlobStorageService>    logger)
    {
        _logger    = logger;
        _container = new BlobContainerClient(options.Value.ConnectionString, options.Value.ContainerName);
    }

    public async Task EnsureContainerExistsAsync(CancellationToken ct = default)
    {
        await _container.CreateIfNotExistsAsync(
            publicAccessType: PublicAccessType.None,
            cancellationToken: ct);

        _logger.LogInformation("Screenshot container '{Name}' is ready.", _container.Name);
    }

    /// <summary>
    /// Uploads <paramref name="pngBytes"/> as a block blob and returns the blob URI.
    /// </summary>
    /// <param name="blobName">Full blob path, e.g. "2024/01/job-id.png"</param>
    public async Task<Uri> UploadAsync(
        string            blobName,
        byte[]            pngBytes,
        IDictionary<string, string>? metadata = null,
        CancellationToken ct = default)
    {
        var blob    = _container.GetBlobClient(blobName);
        using var ms = new MemoryStream(pngBytes);

        await blob.UploadAsync(ms, new BlobUploadOptions
        {
            HttpHeaders = new BlobHttpHeaders { ContentType = "image/png" },
            Metadata    = metadata as Dictionary<string, string>
        }, cancellationToken: ct);

        _logger.LogInformation("Saved screenshot → {Uri}", blob.Uri);
        return blob.Uri;
    }
}
