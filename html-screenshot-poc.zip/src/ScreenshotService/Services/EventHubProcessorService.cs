using System.Text;
using System.Text.Json;
using Azure.Messaging.EventHubs;
using Azure.Messaging.EventHubs.Processor;
using Azure.Storage.Blobs;
using Microsoft.Extensions.Options;
using ScreenshotService.Models;

namespace ScreenshotService.Services;

/// <summary>
/// Long-running background service that pulls events from Azure Event Hub,
/// renders the embedded HTML with Playwright and persists the screenshot to
/// Azure Blob Storage.
/// </summary>
public sealed class EventHubProcessorService : BackgroundService
{
    private readonly EventProcessorClient        _processor;
    private readonly PlaywrightRenderer          _renderer;
    private readonly BlobStorageService          _blobService;
    private readonly ILogger<EventHubProcessorService> _logger;
    private readonly SemaphoreSlim               _concurrency;

    public EventHubProcessorService(
        IOptions<EventHubOptions>  ehOptions,
        PlaywrightRenderer         renderer,
        BlobStorageService         blobService,
        ILogger<EventHubProcessorService> logger)
    {
        var opt = ehOptions.Value;

        var checkpointStore = new BlobContainerClient(
            opt.CheckpointConnectionString,
            opt.CheckpointContainerName);

        _processor = new EventProcessorClient(
            checkpointStore,
            opt.ConsumerGroup,
            opt.ConnectionString,
            opt.EventHubName,
            new EventProcessorClientOptions
            {
                // Keep partition ownership for a longer time so KEDA scale-down
                // doesn't cause unnecessary rebalancing.
                PartitionOwnershipExpirationInterval = TimeSpan.FromSeconds(90)
            });

        _renderer    = renderer;
        _blobService = blobService;
        _logger      = logger;
        _concurrency = new SemaphoreSlim(opt.MaxConcurrentCalls, opt.MaxConcurrentCalls);
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        await _blobService.EnsureContainerExistsAsync(stoppingToken);

        _processor.ProcessEventAsync += HandleEventAsync;
        _processor.ProcessErrorAsync += HandleErrorAsync;

        _logger.LogInformation("Starting Event Hub processor…");
        await _processor.StartProcessingAsync(stoppingToken);

        try
        {
            // Hold until the host signals shutdown.
            await Task.Delay(Timeout.Infinite, stoppingToken);
        }
        catch (OperationCanceledException)
        {
            // Expected on graceful shutdown.
        }
        finally
        {
            _logger.LogInformation("Stopping Event Hub processor…");
            await _processor.StopProcessingAsync();
        }
    }

    // ─── Event handler ────────────────────────────────────────────────────────

    private async Task HandleEventAsync(ProcessEventArgs args)
    {
        if (args.CancellationToken.IsCancellationRequested) return;
        if (!args.HasEvent) return;   // heartbeat / no-event callback

        HtmlRenderRequest? request = null;
        string messageId = "(unknown)";

        try
        {
            var json = Encoding.UTF8.GetString(args.Data.Body.ToArray());
            request   = JsonSerializer.Deserialize<HtmlRenderRequest>(json,
                new JsonSerializerOptions { PropertyNameCaseInsensitive = true });

            if (request is null || string.IsNullOrWhiteSpace(request.Html))
            {
                _logger.LogWarning("Received empty or unreadable event – skipping.");
                await args.UpdateCheckpointAsync(args.CancellationToken);
                return;
            }

            messageId = request.Id;
            _logger.LogInformation("[{Id}] Received render request (HTML length: {Len})", messageId, request.Html.Length);

            // Throttle concurrent Playwright pages.
            await _concurrency.WaitAsync(args.CancellationToken);
            try
            {
                var png = await _renderer.RenderAsync(
                    request.Html,
                    request.ViewportWidth,
                    request.ViewportHeight,
                    args.CancellationToken);

                var blobName = BuildBlobName(request);
                var metadata = BuildBlobMetadata(request, args);

                await _blobService.UploadAsync(blobName, png, metadata, args.CancellationToken);
                _logger.LogInformation("[{Id}] Screenshot saved → {Blob}", messageId, blobName);
            }
            finally
            {
                _concurrency.Release();
            }

            // Only checkpoint after successful processing.
            await args.UpdateCheckpointAsync(args.CancellationToken);
        }
        catch (OperationCanceledException)
        {
            _logger.LogWarning("[{Id}] Processing cancelled.", messageId);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "[{Id}] Failed to process event.", messageId);
            // Do NOT checkpoint – the event will be reprocessed after ownership expires.
        }
    }

    private Task HandleErrorAsync(ProcessErrorEventArgs args)
    {
        _logger.LogError(
            args.Exception,
            "Event Hub processor error on partition {Partition} (operation: {Operation})",
            args.PartitionId,
            args.Operation);
        return Task.CompletedTask;
    }

    // ─── Helpers ──────────────────────────────────────────────────────────────

    private static string BuildBlobName(HtmlRenderRequest req)
    {
        var now = DateTimeOffset.UtcNow;
        // screenshots/2024/06/15/<id>.png  – easy date-prefix partitioning in blob storage
        return $"screenshots/{now:yyyy/MM/dd}/{req.Id}.png";
    }

    private static Dictionary<string, string> BuildBlobMetadata(
        HtmlRenderRequest req,
        ProcessEventArgs  args)
    {
        var meta = new Dictionary<string, string>
        {
            ["jobId"]       = req.Id,
            ["partitionId"] = args.Partition.PartitionId,
            ["enqueuedAt"]  = args.Data.EnqueuedTime.ToString("O")
        };

        foreach (var (k, v) in req.Metadata)
            meta[k] = v;

        return meta;
    }
}
