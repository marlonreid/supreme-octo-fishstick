using Microsoft.Playwright;

namespace ScreenshotService.Services;

/// <summary>
/// Manages a single long-lived Chromium browser instance and renders HTML to PNG.
/// Thread-safe: multiple callers may request screenshots concurrently – each call
/// opens its own page and closes it when done.
/// </summary>
public sealed class PlaywrightRenderer : IAsyncDisposable
{
    private readonly ILogger<PlaywrightRenderer> _logger;
    private IPlaywright? _playwright;
    private IBrowser?    _browser;
    private bool         _disposed;

    public PlaywrightRenderer(ILogger<PlaywrightRenderer> logger)
    {
        _logger = logger;
    }

    // Called once at startup before events arrive.
    public async Task InitializeAsync()
    {
        _logger.LogInformation("Launching headless Chromium…");

        _playwright = await Playwright.CreateAsync();

        _browser = await _playwright.Chromium.LaunchAsync(new BrowserTypeLaunchOptions
        {
            Headless = true,
            Args = new[]
            {
                "--no-sandbox",
                "--disable-setuid-sandbox",
                "--disable-dev-shm-usage",   // avoid /dev/shm issues in containers
                "--disable-gpu",
                "--single-process"
            }
        });

        _logger.LogInformation("Chromium ready (version: {Version})", _browser.Version);
    }

    /// <summary>
    /// Renders <paramref name="html"/> at the requested viewport and returns a PNG byte array.
    /// </summary>
    public async Task<byte[]> RenderAsync(
        string html,
        int    viewportWidth  = 1280,
        int    viewportHeight = 720,
        CancellationToken cancellationToken = default)
    {
        if (_browser is null)
            throw new InvalidOperationException("PlaywrightRenderer has not been initialised. Call InitializeAsync() first.");

        // Each call gets its own browser context + page for isolation.
        await using var context = await _browser.NewContextAsync(new BrowserNewContextOptions
        {
            ViewportSize = new ViewportSize { Width = viewportWidth, Height = viewportHeight }
        });

        var page = await context.NewPageAsync();

        try
        {
            cancellationToken.ThrowIfCancellationRequested();

            await page.SetContentAsync(html, new PageSetContentOptions
            {
                // Wait until there are no more than 0 network connections for at least 500 ms.
                WaitUntil = WaitUntilState.NetworkIdle,
                Timeout   = 15_000   // 15 s – reasonable for local rendering
            });

            var screenshot = await page.ScreenshotAsync(new PageScreenshotOptions
            {
                FullPage = true,
                Type     = ScreenshotType.Png
            });

            return screenshot;
        }
        finally
        {
            await page.CloseAsync();
        }
    }

    public async ValueTask DisposeAsync()
    {
        if (_disposed) return;
        _disposed = true;

        if (_browser is not null)
        {
            await _browser.CloseAsync();
            await _browser.DisposeAsync();
        }

        _playwright?.Dispose();
    }
}
