namespace ScreenshotService.Services;

public sealed class EventHubOptions
{
    /// <summary>Azure Event Hub namespace connection string.</summary>
    public string ConnectionString { get; set; } = string.Empty;

    /// <summary>Name of the Event Hub (topic).</summary>
    public string EventHubName { get; set; } = string.Empty;

    /// <summary>Consumer group. Defaults to $Default.</summary>
    public string ConsumerGroup { get; set; } = "$Default";

    /// <summary>Storage connection string used for checkpointing.</summary>
    public string CheckpointConnectionString { get; set; } = string.Empty;

    /// <summary>Blob container that holds EventProcessorClient checkpoints.</summary>
    public string CheckpointContainerName { get; set; } = "checkpoints";

    /// <summary>
    /// Maximum number of events to process concurrently per partition.
    /// Increase for higher throughput at the cost of more browser pages.
    /// </summary>
    public int MaxConcurrentCalls { get; set; } = 4;
}

public sealed class BlobStorageOptions
{
    /// <summary>Azure Storage connection string for screenshot output.</summary>
    public string ConnectionString { get; set; } = string.Empty;

    /// <summary>Blob container where PNG screenshots are stored.</summary>
    public string ContainerName { get; set; } = "screenshots";
}
