{{- define "feeder-service.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "feeder-service.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{- define "feeder-service.labels" -}}
helm.sh/chart: {{ include "feeder-service.name" . }}-{{ .Chart.Version }}
{{ include "feeder-service.selectorLabels" . }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{- define "feeder-service.selectorLabels" -}}
app.kubernetes.io/name: {{ include "feeder-service.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}
