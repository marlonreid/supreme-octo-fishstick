namespace VClusterApi.Models;

public record CreateVClusterRequest(
    string Name,
    string Namespace,
    string? K8sVersion = null,
    VClusterResourceLimits? ResourceLimits = null,
    Dictionary<string, string>? Labels = null
);

public record VClusterResourceLimits(
    string CpuLimit = "1000m",
    string MemoryLimit = "1Gi",
    string StorageSize = "5Gi"
);

public record VClusterSummary(
    string Name,
    string Namespace,
    string Status,
    string? K8sVersion,
    DateTime? CreatedAt,
    Dictionary<string, string> Labels
);

public record VClusterDetail(
    string Name,
    string Namespace,
    string Status,
    string? K8sVersion,
    DateTime? CreatedAt,
    Dictionary<string, string> Labels,
    VClusterPodStatus[] Pods,
    string? KubeconfigSecretName
);

public record VClusterPodStatus(
    string Name,
    string Phase,
    bool Ready,
    int RestartCount,
    DateTime? StartedAt
);

public record VClusterKubeconfig(
    string VClusterName,
    string Namespace,
    string Kubeconfig
);

public record ApiResponse<T>(bool Success, T? Data, string? Error = null);
