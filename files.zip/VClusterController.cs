using Microsoft.AspNetCore.Mvc;
using VClusterApi.Models;
using VClusterApi.Services;

namespace VClusterApi.Controllers;

[ApiController]
[Route("api/vclusters")]
[Produces("application/json")]
public class VClusterController(IVClusterService vclusterService, ILogger<VClusterController> logger) : ControllerBase
{
    // GET /api/vclusters
    // GET /api/vclusters?namespace=my-ns
    [HttpGet]
    [ProducesResponseType<ApiResponse<IEnumerable<VClusterSummary>>>(StatusCodes.Status200OK)]
    public async Task<IActionResult> List([FromQuery] string? @namespace, CancellationToken ct)
    {
        var clusters = await vclusterService.ListVClustersAsync(@namespace, ct);
        return Ok(new ApiResponse<IEnumerable<VClusterSummary>>(true, clusters));
    }

    // GET /api/vclusters/{namespace}/{name}
    [HttpGet("{namespace}/{name}")]
    [ProducesResponseType<ApiResponse<VClusterDetail>>(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> Get(string @namespace, string name, CancellationToken ct)
    {
        var detail = await vclusterService.GetVClusterAsync(name, @namespace, ct);
        if (detail is null)
            return NotFound(new ApiResponse<VClusterDetail>(false, null, $"vCluster '{name}' not found in namespace '{@namespace}'"));

        return Ok(new ApiResponse<VClusterDetail>(true, detail));
    }

    // POST /api/vclusters
    [HttpPost]
    [ProducesResponseType<ApiResponse<VClusterSummary>>(StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> Create([FromBody] CreateVClusterRequest request, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(request.Name) || string.IsNullOrWhiteSpace(request.Namespace))
            return BadRequest(new ApiResponse<VClusterSummary>(false, null, "Name and Namespace are required."));

        var summary = await vclusterService.CreateVClusterAsync(request, ct);
        return CreatedAtAction(
            nameof(Get),
            new { @namespace = summary.Namespace, name = summary.Name },
            new ApiResponse<VClusterSummary>(true, summary));
    }

    // DELETE /api/vclusters/{namespace}/{name}
    [HttpDelete("{namespace}/{name}")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> Delete(string @namespace, string name, CancellationToken ct)
    {
        var existing = await vclusterService.GetVClusterAsync(name, @namespace, ct);
        if (existing is null)
            return NotFound(new ApiResponse<object>(false, null, $"vCluster '{name}' not found."));

        await vclusterService.DeleteVClusterAsync(name, @namespace, ct);
        return NoContent();
    }

    // GET /api/vclusters/{namespace}/{name}/kubeconfig
    [HttpGet("{namespace}/{name}/kubeconfig")]
    [ProducesResponseType<ApiResponse<VClusterKubeconfig>>(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetKubeconfig(string @namespace, string name, CancellationToken ct)
    {
        try
        {
            var kc = await vclusterService.GetKubeconfigAsync(name, @namespace, ct);
            return Ok(new ApiResponse<VClusterKubeconfig>(true, kc));
        }
        catch (InvalidOperationException ex)
        {
            logger.LogWarning("Kubeconfig not ready for {Name}: {Message}", name, ex.Message);
            return NotFound(new ApiResponse<VClusterKubeconfig>(false, null, ex.Message));
        }
    }

    // POST /api/vclusters/{namespace}/{name}/sleep
    [HttpPost("{namespace}/{name}/sleep")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    public async Task<IActionResult> Sleep(string @namespace, string name, CancellationToken ct)
    {
        await vclusterService.SleepVClusterAsync(name, @namespace, ct);
        return NoContent();
    }

    // POST /api/vclusters/{namespace}/{name}/wake
    [HttpPost("{namespace}/{name}/wake")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    public async Task<IActionResult> Wake(string @namespace, string name, CancellationToken ct)
    {
        await vclusterService.WakeVClusterAsync(name, @namespace, ct);
        return NoContent();
    }
}
