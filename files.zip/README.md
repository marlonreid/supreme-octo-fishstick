# VCluster API

A .NET 10 Web API for managing ephemeral vCluster instances on AKS via the Kubernetes client library.

## Architecture

```
┌─────────────────────────────────────────────┐
│  AKS Cluster                                │
│                                             │
│  ┌──────────────────┐                       │
│  │  vcluster-api ns │                       │
│  │  Deployment      │  ClusterRole          │
│  │  (this API)      │──────────────────►    │
│  └──────────────────┘  namespaces,          │
│                         statefulsets,        │
│  ┌──────────────────┐   services, secrets   │
│  │  vc-team-a ns    │                       │
│  │  StatefulSet     │                       │
│  │  Service         │                       │
│  │  Secret(kc)      │                       │
│  └──────────────────┘                       │
│  ┌──────────────────┐                       │
│  │  vc-team-b ns    │                       │
│  │  StatefulSet     │                       │
│  └──────────────────┘                       │
└─────────────────────────────────────────────┘
```

## Prerequisites

- AKS cluster with a node pool (B2s or larger per vCluster)
- Azure Container Registry
- `kubectl` configured against the cluster
- `az` CLI authenticated

## Quick Start

### 1. Build and push the image

```bash
az acr login --name <YOUR_ACR>

docker build -t <YOUR_ACR>.azurecr.io/vcluster-api:latest .
docker push <YOUR_ACR>.azurecr.io/vcluster-api:latest
```

### 2. Update the image reference

```bash
# In k8s-manifests.yaml, replace <YOUR_ACR> with your registry name
sed -i 's/<YOUR_ACR>/myregistry/g' k8s-manifests.yaml
```

### 3. Deploy to AKS

```bash
kubectl apply -f k8s-manifests.yaml

# Verify the API pod is running
kubectl get pods -n vcluster-api
kubectl logs -n vcluster-api deployment/vcluster-api
```

### 4. Local development (kubeconfig)

```bash
dotnet run

# The API auto-detects kubeconfig when not running in-cluster
# Scalar UI available at: https://localhost:7xxx/scalar
```

---

## API Reference

### List vClusters

```bash
# All managed vClusters
curl http://localhost:8080/api/vclusters

# Filter by namespace
curl "http://localhost:8080/api/vclusters?namespace=vc-team-a"
```

### Get vCluster detail

```bash
curl http://localhost:8080/api/vclusters/vc-team-a/my-cluster
```

### Create a vCluster

```bash
curl -X POST http://localhost:8080/api/vclusters \
  -H "Content-Type: application/json" \
  -d '{
    "name": "my-cluster",
    "namespace": "vc-team-a",
    "k8sVersion": "0.20.0",
    "resourceLimits": {
      "cpuLimit": "1000m",
      "memoryLimit": "1Gi",
      "storageSize": "5Gi"
    },
    "labels": {
      "team": "platform",
      "env": "ephemeral"
    }
  }'
```

### Delete a vCluster

```bash
# Deletes the entire namespace (cascades to all resources)
curl -X DELETE http://localhost:8080/api/vclusters/vc-team-a/my-cluster
```

### Get kubeconfig

```bash
# Returns the kubeconfig to connect directly to the vCluster API server
curl http://localhost:8080/api/vclusters/vc-team-a/my-cluster/kubeconfig \
  | jq -r '.data.kubeconfig' > ./vc-kubeconfig.yaml

KUBECONFIG=./vc-kubeconfig.yaml kubectl get nodes
```

### Sleep a vCluster (scale to 0)

```bash
curl -X POST http://localhost:8080/api/vclusters/vc-team-a/my-cluster/sleep
```

### Wake a vCluster (scale to 1)

```bash
curl -X POST http://localhost:8080/api/vclusters/vc-team-a/my-cluster/wake
```

---

## Useful kubectl commands during development

```bash
# Watch vCluster pods come up
kubectl get pods -n vc-team-a -w

# Check StatefulSet status
kubectl get sts -n vc-team-a

# Tail vCluster logs
kubectl logs -n vc-team-a statefulset/my-cluster -f

# Inspect the kubeconfig secret (base64 decode to verify)
kubectl get secret -n vc-team-a vc-my-cluster -o jsonpath='{.data.config}' | base64 -d

# List all API-managed namespaces
kubectl get ns -l app.kubernetes.io/managed-by=vcluster-api

# Describe the StatefulSet for troubleshooting
kubectl describe sts -n vc-team-a my-cluster

# Force delete a stuck namespace
kubectl delete namespace vc-team-a --force --grace-period=0
```

---

## Integration with kube-janitor (IDP POC)

To automatically reap ephemeral vClusters, annotate the namespace at creation time:

```json
{
  "labels": { "team": "platform" },
  "annotations": {
    "janitor/ttl": "8h",
    "janitor/expires": "2026-06-10T18:00:00Z"
  }
}
```

The `CreateVClusterRequest` model accepts a `Labels` dictionary — extend with an
`Annotations` dictionary if you need to pass these through the API.

---

## RBAC notes for AKS Workload Identity

When using AKS Workload Identity instead of a ServiceAccount token, replace the
`ServiceAccount` + `ClusterRoleBinding` with a federated credential bound to your
managed identity, and inject `AZURE_CLIENT_ID` into the pod spec. The Kubernetes
client itself still uses the mounted ServiceAccount token for K8s API calls.
