using k8s;
using k8s.Models;
using System.Text;
using System.Text.Json;
using VClusterApi.Models;

namespace VClusterApi.Services;

/// <summary>
/// Manages vCluster instances on AKS by driving the Kubernetes API directly.
/// vClusters are represented as StatefulSets (the vCluster control plane pod)
/// within a dedicated namespace, plus a Service and optional PVC.
///
/// This service follows the vCluster OSS pattern: one namespace per vCluster,
/// a StatefulSet named after the vCluster, and a kubeconfig stored in a Secret.
/// </summary>
public class VClusterService(IKubernetes k8s, ILogger<VClusterService> logger) : IVClusterService
{
    // Label applied to every resource this API owns
    private const string ManagedByLabel = "app.kubernetes.io/managed-by";
    private const string ManagedByValue = "vcluster-api";
    private const string VClusterLabel = "app";
    private const string VClusterLabelValue = "vcluster";

    // -------------------------------------------------------------------------
    // List
    // -------------------------------------------------------------------------

    public async Task<IEnumerable<VClusterSummary>> ListVClustersAsync(
        string? namespaceName = null,
        CancellationToken ct = default)
    {
        // vClusters live in their own namespaces — discover by listing namespaces
        // labelled by this API, or fall back to a specific namespace if provided.
        var namespaces = namespaceName is not null
            ? [namespaceName]
            : await GetManagedNamespacesAsync(ct);

        var summaries = new List<VClusterSummary>();

        foreach (var ns in namespaces)
        {
            try
            {
                var statefulSets = await k8s.AppsV1.ListNamespacedStatefulSetAsync(
                    ns,
                    labelSelector: $"{VClusterLabel}={VClusterLabelValue}",
                    cancellationToken: ct);

                summaries.AddRange(statefulSets.Items.Select(ss => ToSummary(ss, ns)));
            }
            catch (Exception ex)
            {
                logger.LogWarning(ex, "Failed to list vClusters in namespace {Namespace}", ns);
            }
        }

        return summaries;
    }

    // -------------------------------------------------------------------------
    // Get
    // -------------------------------------------------------------------------

    public async Task<VClusterDetail?> GetVClusterAsync(
        string name,
        string namespaceName,
        CancellationToken ct = default)
    {
        V1StatefulSet? ss;
        try
        {
            ss = await k8s.AppsV1.ReadNamespacedStatefulSetAsync(name, namespaceName, cancellationToken: ct);
        }
        catch (k8s.Autorest.HttpOperationException ex) when (ex.Response.StatusCode == System.Net.HttpStatusCode.NotFound)
        {
            return null;
        }

        var pods = await k8s.CoreV1.ListNamespacedPodAsync(
            namespaceName,
            labelSelector: $"{VClusterLabel}={VClusterLabelValue}",
            cancellationToken: ct);

        var podStatuses = pods.Items.Select(p => new VClusterPodStatus(
            p.Metadata.Name,
            p.Status.Phase ?? "Unknown",
            p.Status?.ContainerStatuses?.All(cs => cs.Ready) ?? false,
            p.Status?.ContainerStatuses?.Sum(cs => cs.RestartCount) ?? 0,
            p.Status?.StartTime
        )).ToArray();

        return new VClusterDetail(
            ss.Metadata.Name,
            namespaceName,
            ResolveStatus(ss),
            ss.Metadata.Labels?.GetValueOrDefault("vcluster.loft.sh/version"),
            ss.Metadata.CreationTimestamp,
            ss.Metadata.Labels ?? [],
            podStatuses,
            KubeconfigSecretName(name)
        );
    }

    // -------------------------------------------------------------------------
    // Create
    // -------------------------------------------------------------------------

    public async Task<VClusterSummary> CreateVClusterAsync(
        CreateVClusterRequest request,
        CancellationToken ct = default)
    {
        logger.LogInformation("Creating vCluster {Name} in namespace {Namespace}", request.Name, request.Namespace);

        await EnsureNamespaceAsync(request.Namespace, ct);

        var limits = request.ResourceLimits ?? new VClusterResourceLimits();

        // -- StatefulSet (vCluster control plane) ------------------------------
        var statefulSet = BuildStatefulSet(request, limits);
        await k8s.AppsV1.CreateNamespacedStatefulSetAsync(statefulSet, request.Namespace, cancellationToken: ct);

        // -- Headless service for vCluster API server --------------------------
        var service = BuildService(request.Name, request.Labels);
        await k8s.CoreV1.CreateNamespacedServiceAsync(service, request.Namespace, cancellationToken: ct);

        logger.LogInformation("vCluster {Name} created successfully", request.Name);

        var ss = await k8s.AppsV1.ReadNamespacedStatefulSetAsync(request.Name, request.Namespace, cancellationToken: ct);
        return ToSummary(ss, request.Namespace);
    }

    // -------------------------------------------------------------------------
    // Delete
    // -------------------------------------------------------------------------

    public async Task DeleteVClusterAsync(
        string name,
        string namespaceName,
        CancellationToken ct = default)
    {
        logger.LogInformation("Deleting vCluster {Name} from namespace {Namespace}", name, namespaceName);

        // Delete the namespace entirely — this cascades to all owned resources
        await k8s.CoreV1.DeleteNamespaceAsync(namespaceName, cancellationToken: ct);

        logger.LogInformation("Namespace {Namespace} deletion initiated", namespaceName);
    }

    // -------------------------------------------------------------------------
    // Kubeconfig
    // -------------------------------------------------------------------------

    public async Task<VClusterKubeconfig> GetKubeconfigAsync(
        string name,
        string namespaceName,
        CancellationToken ct = default)
    {
        var secretName = KubeconfigSecretName(name);

        V1Secret secret;
        try
        {
            secret = await k8s.CoreV1.ReadNamespacedSecretAsync(secretName, namespaceName, cancellationToken: ct);
        }
        catch (k8s.Autorest.HttpOperationException ex) when (ex.Response.StatusCode == System.Net.HttpStatusCode.NotFound)
        {
            throw new InvalidOperationException(
                $"Kubeconfig secret '{secretName}' not found in namespace '{namespaceName}'. " +
                "The vCluster may still be initialising.");
        }

        var kubeconfigBytes = secret.Data.GetValueOrDefault("config")
            ?? throw new InvalidOperationException("Secret exists but contains no 'config' key.");

        return new VClusterKubeconfig(name, namespaceName, Encoding.UTF8.GetString(kubeconfigBytes));
    }

    // -------------------------------------------------------------------------
    // Sleep / Wake  (patch replicas on the StatefulSet)
    // -------------------------------------------------------------------------

    public async Task SleepVClusterAsync(string name, string namespaceName, CancellationToken ct = default)
    {
        logger.LogInformation("Sleeping vCluster {Name}", name);
        await PatchReplicasAsync(name, namespaceName, replicas: 0, ct);
    }

    public async Task WakeVClusterAsync(string name, string namespaceName, CancellationToken ct = default)
    {
        logger.LogInformation("Waking vCluster {Name}", name);
        await PatchReplicasAsync(name, namespaceName, replicas: 1, ct);
    }

    // -------------------------------------------------------------------------
    // Private helpers
    // -------------------------------------------------------------------------

    private async Task PatchReplicasAsync(string name, string namespaceName, int replicas, CancellationToken ct)
    {
        var patch = new V1Patch(
            JsonSerializer.Serialize(new { spec = new { replicas } }),
            V1Patch.PatchType.MergePatch);

        await k8s.AppsV1.PatchNamespacedStatefulSetAsync(patch, name, namespaceName, cancellationToken: ct);
    }

    private async Task<IEnumerable<string>> GetManagedNamespacesAsync(CancellationToken ct)
    {
        var namespaces = await k8s.CoreV1.ListNamespaceAsync(
            labelSelector: $"{ManagedByLabel}={ManagedByValue}",
            cancellationToken: ct);

        return namespaces.Items.Select(n => n.Metadata.Name);
    }

    private async Task EnsureNamespaceAsync(string namespaceName, CancellationToken ct)
    {
        try
        {
            await k8s.CoreV1.ReadNamespaceAsync(namespaceName, cancellationToken: ct);
            logger.LogDebug("Namespace {Namespace} already exists", namespaceName);
        }
        catch (k8s.Autorest.HttpOperationException ex) when (ex.Response.StatusCode == System.Net.HttpStatusCode.NotFound)
        {
            var ns = new V1Namespace
            {
                Metadata = new V1ObjectMeta
                {
                    Name = namespaceName,
                    Labels = new Dictionary<string, string>
                    {
                        [ManagedByLabel] = ManagedByValue,
                        ["vcluster.loft.sh/namespace"] = "true"
                    }
                }
            };
            await k8s.CoreV1.CreateNamespaceAsync(ns, cancellationToken: ct);
            logger.LogInformation("Created namespace {Namespace}", namespaceName);
        }
    }

    private static V1StatefulSet BuildStatefulSet(CreateVClusterRequest request, VClusterResourceLimits limits)
    {
        var labels = new Dictionary<string, string>(request.Labels ?? [])
        {
            [VClusterLabel] = VClusterLabelValue,
            [ManagedByLabel] = ManagedByValue,
            ["vcluster.loft.sh/object-name"] = request.Name
        };

        if (request.K8sVersion is not null)
            labels["vcluster.loft.sh/version"] = request.K8sVersion;

        return new V1StatefulSet
        {
            Metadata = new V1ObjectMeta
            {
                Name = request.Name,
                NamespaceProperty = request.Namespace,
                Labels = labels
            },
            Spec = new V1StatefulSetSpec
            {
                ServiceName = request.Name,
                Replicas = 1,
                Selector = new V1LabelSelector
                {
                    MatchLabels = new Dictionary<string, string>
                    {
                        [VClusterLabel] = VClusterLabelValue
                    }
                },
                Template = new V1PodTemplateSpec
                {
                    Metadata = new V1ObjectMeta { Labels = labels },
                    Spec = new V1PodSpec
                    {
                        TerminationGracePeriodSeconds = 10,
                        Containers =
                        [
                            new V1Container
                            {
                                Name = "vcluster",
                                // vcluster OSS image — pin to a specific version in production
                                Image = $"ghcr.io/loft-sh/vcluster:{request.K8sVersion ?? "latest"}",
                                Args =
                                [
                                    "start",
                                    "--name", request.Name,
                                    "--tls-san", $"{request.Name}.{request.Namespace}.svc.cluster.local"
                                ],
                                Resources = new V1ResourceRequirements
                                {
                                    Requests = new Dictionary<string, ResourceQuantity>
                                    {
                                        ["cpu"] = new("200m"),
                                        ["memory"] = new("256Mi")
                                    },
                                    Limits = new Dictionary<string, ResourceQuantity>
                                    {
                                        ["cpu"] = new(limits.CpuLimit),
                                        ["memory"] = new(limits.MemoryLimit)
                                    }
                                },
                                VolumeMounts =
                                [
                                    new V1VolumeMount { Name = "data", MountPath = "/data" }
                                ]
                            }
                        ]
                    }
                },
                VolumeClaimTemplates =
                [
                    new V1PersistentVolumeClaim
                    {
                        Metadata = new V1ObjectMeta { Name = "data" },
                        Spec = new V1PersistentVolumeClaimSpec
                        {
                            AccessModes = ["ReadWriteOnce"],
                            Resources = new V1VolumeResourceRequirements
                            {
                                Requests = new Dictionary<string, ResourceQuantity>
                                {
                                    ["storage"] = new(limits.StorageSize)
                                }
                            }
                        }
                    }
                ]
            }
        };
    }

    private static V1Service BuildService(string name, Dictionary<string, string>? extraLabels)
    {
        var labels = new Dictionary<string, string>(extraLabels ?? [])
        {
            [VClusterLabel] = VClusterLabelValue,
            [ManagedByLabel] = ManagedByValue
        };

        return new V1Service
        {
            Metadata = new V1ObjectMeta { Name = name, Labels = labels },
            Spec = new V1ServiceSpec
            {
                ClusterIP = "None",   // headless — required for StatefulSet DNS
                Selector = new Dictionary<string, string>
                {
                    [VClusterLabel] = VClusterLabelValue
                },
                Ports =
                [
                    new V1ServicePort { Name = "https", Port = 443, TargetPort = 8443 }
                ]
            }
        };
    }

    private static string ResolveStatus(V1StatefulSet ss)
    {
        if (ss.Spec.Replicas == 0) return "Sleeping";
        var ready = ss.Status?.ReadyReplicas ?? 0;
        var desired = ss.Spec.Replicas ?? 1;
        return ready >= desired ? "Running" : "Provisioning";
    }

    private static VClusterSummary ToSummary(V1StatefulSet ss, string ns) =>
        new(
            ss.Metadata.Name,
            ns,
            ResolveStatus(ss),
            ss.Metadata.Labels?.GetValueOrDefault("vcluster.loft.sh/version"),
            ss.Metadata.CreationTimestamp,
            ss.Metadata.Labels ?? []
        );

    private static string KubeconfigSecretName(string vclusterName) => $"vc-{vclusterName}";
}
