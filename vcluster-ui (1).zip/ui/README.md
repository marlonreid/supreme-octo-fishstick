# vcluster-ui

React + TypeScript + Vite + MUI frontend.

## Setup

```bash
npm install
npm run dev
# http://localhost:5173
```

## Structure

```
src/
├── types/index.ts           # All TypeScript types
├── data/dummy.ts            # Dummy data (replace with API calls)
├── components/
│   ├── StatusChip.tsx       # Coloured status badge
│   └── Breadcrumbs.tsx      # Navigation breadcrumb trail
└── pages/
    ├── EnvironmentsPage.tsx        # Screen 1 — environment grid
    ├── EnvironmentDetailPage.tsx   # Screen 2 — workloads + logs
    └── WorkloadDetailPage.tsx      # Screen 3 — components + data packs
```

## Connecting to the API

All data currently comes from `src/data/dummy.ts`.
When the API is ready, replace the imports in each page with `fetch` calls to `/api/environments`, `/api/workloads`, etc.
