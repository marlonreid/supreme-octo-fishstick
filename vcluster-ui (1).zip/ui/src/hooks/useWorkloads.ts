import { useApi } from './useApi'
import { listWorkloads } from '../services/api'

export function useWorkloads(environmentId: string | null) {
  return useApi(
    () => listWorkloads(environmentId!),
    environmentId  // null → skip fetch until we have an id
  )
}
