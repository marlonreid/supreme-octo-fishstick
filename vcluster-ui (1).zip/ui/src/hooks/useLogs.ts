import { useApi } from './useApi'
import { listLogs } from '../services/api'

export function useLogs(environmentId: string | null) {
  return useApi(
    () => listLogs(environmentId!),
    environmentId
  )
}
