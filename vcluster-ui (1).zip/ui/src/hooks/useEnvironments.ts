import { useApi } from './useApi'
import { listEnvironments } from '../services/api'

export function useEnvironments() {
  return useApi(listEnvironments, 'environments')
}
