import { useCallback, useEffect, useState } from 'react'

export interface UseApiResult<T> {
  data: T | null
  loading: boolean
  error: string | null
  refresh: () => void
}

/**
 * Generic hook for any async data fetch.
 * Re-runs whenever the `key` changes (pass a stable string like the entity id).
 *
 * Usage:
 *   const { data, loading, error } = useApi(() => listWorkloads(envId), envId)
 */
export function useApi<T>(
  fn: () => Promise<T>,
  key?: string | null
): UseApiResult<T> {
  const [data, setData] = useState<T | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [tick, setTick] = useState(0)

  const refresh = useCallback(() => setTick(t => t + 1), [])

  useEffect(() => {
    // Skip if key is explicitly null (means "not ready yet")
    if (key === null) return

    let cancelled = false
    setLoading(true)
    setError(null)

    fn()
      .then(result => { if (!cancelled) setData(result) })
      .catch(e => { if (!cancelled) setError(e instanceof Error ? e.message : String(e)) })
      .finally(() => { if (!cancelled) setLoading(false) })

    return () => { cancelled = true }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key, tick])

  return { data, loading, error, refresh }
}
