import { useApi } from './useApi'
import { listComponents, listDataPacks } from '../services/api'

export function useComponents(workloadId: string | null) {
  return useApi(
    () => listComponents(workloadId!),
    workloadId
  )
}

export function useDataPacks(workloadId: string | null) {
  return useApi(
    () => listDataPacks(workloadId!),
    workloadId
  )
}
