export type EnvironmentStatus = 'Running' | 'Deploying' | 'Sleeping' | 'Failed' | 'Provisioning'
export type WorkloadStatus    = 'Running' | 'Deploying' | 'Failed' | 'Stopped'
export type ComponentStatus   = 'Running' | 'Stopped'  | 'Failed'

export interface Environment {
  id: string
  name: string
  status: EnvironmentStatus
  timeUp: string        // e.g. "2d 8h 32m"
  timeToTeardown: string // e.g. "14d 17h"
  costPerHour: string   // e.g. "$0.32"
  totalCost: string     // e.g. "$5.32"
  namespace: string
  createdAt: string
}

export interface Workload {
  id: string
  environmentId: string
  name: string
  status: WorkloadStatus
  version: string       // e.g. "v 26.03"
  url?: string
}

export interface WorkloadComponent {
  id: string
  workloadId: string
  name: string
  status: ComponentStatus
  url: string
}

export interface DataPack {
  id: string
  workloadId: string
  name: string
  lastDeployed?: string
}

export interface LogEntry {
  id: string
  timestamp: string
  message: string
}
