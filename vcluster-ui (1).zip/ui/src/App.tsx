import { useState } from 'react'
import { ThemeProvider, createTheme } from '@mui/material/styles'
import CssBaseline from '@mui/material/CssBaseline'
import Box from '@mui/material/Box'
import AppBar from '@mui/material/AppBar'
import Toolbar from '@mui/material/Toolbar'
import Typography from '@mui/material/Typography'
import Container from '@mui/material/Container'
import HubIcon from '@mui/icons-material/Hub'
import { EnvironmentsPage } from './pages/EnvironmentsPage'
import { EnvironmentDetailPage } from './pages/EnvironmentDetailPage'
import { WorkloadDetailPage } from './pages/WorkloadDetailPage'
import type { Environment, Workload } from './types'

const theme = createTheme({
  palette: {
    mode: 'dark',
    primary:    { main: '#58a6ff' },
    background: { default: '#0d1117', paper: '#161b22' },
    divider: '#21262d',
  },
  typography: {
    fontFamily: '"Inter", system-ui, sans-serif',
  },
  components: {
    MuiCard: {
      styleOverrides: {
        root: { backgroundImage: 'none', backgroundColor: '#161b22' },
      },
    },
    MuiPaper: {
      styleOverrides: {
        root: { backgroundImage: 'none', backgroundColor: '#161b22' },
      },
    },
    MuiOutlinedInput: {
      styleOverrides: {
        root: { '& .MuiOutlinedInput-notchedOutline': { borderColor: '#30363d' } },
      },
    },
    MuiDivider: {
      styleOverrides: { root: { borderColor: '#21262d' } },
    },
  },
})

type View = 'environments' | 'environment' | 'workload'

export default function App() {
  const [view, setView] = useState<View>('environments')
  const [selectedEnv, setSelectedEnv] = useState<Environment | null>(null)
  const [selectedWorkload, setSelectedWorkload] = useState<Workload | null>(null)

  const goToEnvironment = (env: Environment) => {
    setSelectedEnv(env)
    setSelectedWorkload(null)
    setView('environment')
  }

  const goToWorkload = (workload: Workload) => {
    setSelectedWorkload(workload)
    setView('workload')
  }

  const goToEnvironments = () => {
    setSelectedEnv(null)
    setSelectedWorkload(null)
    setView('environments')
  }

  const goBackToEnvironment = () => {
    setSelectedWorkload(null)
    setView('environment')
  }

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <Box sx={{ minHeight: '100vh', bgcolor: 'background.default' }}>

        {/* App bar */}
        <AppBar
          position="sticky"
          elevation={0}
          sx={{ bgcolor: '#161b22', borderBottom: '1px solid #21262d' }}
        >
          <Toolbar sx={{ gap: 1.5 }}>
            <HubIcon sx={{ color: 'primary.main' }} />
            <Typography
              fontWeight={700}
              fontSize="1rem"
              sx={{ cursor: 'pointer', userSelect: 'none' }}
              onClick={goToEnvironments}
            >
              Ava Environments
            </Typography>
          </Toolbar>
        </AppBar>

        {/* Page content */}
        <Container maxWidth="lg" sx={{ py: 4 }}>
          {view === 'environments' && (
            <EnvironmentsPage onSelectEnvironment={goToEnvironment} />
          )}

          {view === 'environment' && selectedEnv && (
            <EnvironmentDetailPage
              environment={selectedEnv}
              onBack={goToEnvironments}
              onSelectWorkload={goToWorkload}
            />
          )}

          {view === 'workload' && selectedEnv && selectedWorkload && (
            <WorkloadDetailPage
              environment={selectedEnv}
              workload={selectedWorkload}
              onBackToEnvironments={goToEnvironments}
              onBackToEnvironment={goBackToEnvironment}
            />
          )}
        </Container>
      </Box>
    </ThemeProvider>
  )
}
