import type { Environment, Workload, WorkloadComponent, DataPack, LogEntry } from '../types'
import {
  ENVIRONMENTS,
  WORKLOADS,
  COMPONENTS,
  DATA_PACKS,
  LOGS,
} from '../data/dummy'

// ─────────────────────────────────────────────────────────────────────────────
// Toggle this to false once the API is ready.
// When true, every call returns dummy data instead of hitting the network.
// ─────────────────────────────────────────────────────────────────────────────
const USE_DUMMY = true

const BASE = '/api'

// ── Generic fetch helper ──────────────────────────────────────────────────────

async function get<T>(path: string): Promise<T> {
  const res = await fetch(`${BASE}${path}`)
  if (!res.ok) throw new Error(`GET ${path} failed: ${res.status} ${res.statusText}`)
  return res.json() as Promise<T>
}

async function post<T>(path: string, body?: unknown): Promise<T> {
  const res = await fetch(`${BASE}${path}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: body !== undefined ? JSON.stringify(body) : undefined,
  })
  if (!res.ok) throw new Error(`POST ${path} failed: ${res.status} ${res.statusText}`)
  return res.json() as Promise<T>
}

async function del(path: string): Promise<void> {
  const res = await fetch(`${BASE}${path}`, { method: 'DELETE' })
  if (!res.ok) throw new Error(`DELETE ${path} failed: ${res.status} ${res.statusText}`)
}

// ── Environments ──────────────────────────────────────────────────────────────

export async function listEnvironments(): Promise<Environment[]> {
  if (USE_DUMMY) return ENVIRONMENTS
  // TODO: adjust response shape to match your API
  return get<Environment[]>('/environments')
}

export async function getEnvironment(id: string): Promise<Environment> {
  if (USE_DUMMY) {
    const env = ENVIRONMENTS.find(e => e.id === id)
    if (!env) throw new Error(`Environment ${id} not found`)
    return env
  }
  return get<Environment>(`/environments/${id}`)
}

export async function createEnvironment(payload: {
  name: string
  k8sVersion?: string
  ttlHours?: number
  costThresholdGbp?: number
}): Promise<Environment> {
  if (USE_DUMMY) throw new Error('createEnvironment: dummy mode, not implemented')
  return post<Environment>('/environments', payload)
}

export async function deleteEnvironment(id: string): Promise<void> {
  if (USE_DUMMY) return
  return del(`/environments/${id}`)
}

// ── Workloads ─────────────────────────────────────────────────────────────────

export async function listWorkloads(environmentId: string): Promise<Workload[]> {
  if (USE_DUMMY) return WORKLOADS.filter(w => w.environmentId === environmentId)
  return get<Workload[]>(`/environments/${environmentId}/workloads`)
}

export async function getWorkload(environmentId: string, workloadId: string): Promise<Workload> {
  if (USE_DUMMY) {
    const w = WORKLOADS.find(w => w.id === workloadId && w.environmentId === environmentId)
    if (!w) throw new Error(`Workload ${workloadId} not found`)
    return w
  }
  return get<Workload>(`/environments/${environmentId}/workloads/${workloadId}`)
}

export async function createWorkload(environmentId: string, payload: {
  name: string
  version?: string
}): Promise<Workload> {
  if (USE_DUMMY) throw new Error('createWorkload: dummy mode, not implemented')
  return post<Workload>(`/environments/${environmentId}/workloads`, payload)
}

export async function deleteWorkload(environmentId: string, workloadId: string): Promise<void> {
  if (USE_DUMMY) return
  return del(`/environments/${environmentId}/workloads/${workloadId}`)
}

// ── Components ────────────────────────────────────────────────────────────────

export async function listComponents(workloadId: string): Promise<WorkloadComponent[]> {
  if (USE_DUMMY) return COMPONENTS.filter(c => c.workloadId === workloadId)
  // TODO: adjust path to match your API
  return get<WorkloadComponent[]>(`/workloads/${workloadId}/components`)
}

// ── Data packs ────────────────────────────────────────────────────────────────

export async function listDataPacks(workloadId: string): Promise<DataPack[]> {
  if (USE_DUMMY) return DATA_PACKS.filter(d => d.workloadId === workloadId)
  return get<DataPack[]>(`/workloads/${workloadId}/datapacks`)
}

export async function redeployDataPack(workloadId: string, dataPackId: string): Promise<void> {
  if (USE_DUMMY) return
  return post(`/workloads/${workloadId}/datapacks/${dataPackId}/redeploy`)
}

// ── Logs ──────────────────────────────────────────────────────────────────────

export async function listLogs(environmentId: string): Promise<LogEntry[]> {
  if (USE_DUMMY) return LOGS
  return get<LogEntry[]>(`/environments/${environmentId}/logs`)
}

// ── SSE progress stream ───────────────────────────────────────────────────────

export function subscribeProgress(
  environmentId: string,
  onEvent: (data: { type: string; message: string; timestamp: string }) => void,
  onComplete: () => void,
  onError: () => void
): EventSource {
  const source = new EventSource(`${BASE}/environments/${environmentId}/progress`)

  source.onmessage = (e: MessageEvent) => {
    const evt = JSON.parse(e.data as string) as { type: string; message: string; timestamp: string }
    if (evt.type === 'StreamComplete') {
      source.close()
      onComplete()
    } else {
      onEvent(evt)
    }
  }

  source.onerror = () => {
    source.close()
    onError()
  }

  return source
}
