import Box from '@mui/material/Box'
import Grid from '@mui/material/Grid'
import Card from '@mui/material/Card'
import CardContent from '@mui/material/CardContent'
import Typography from '@mui/material/Typography'
import Button from '@mui/material/Button'
import Divider from '@mui/material/Divider'
import Paper from '@mui/material/Paper'
import Stack from '@mui/material/Stack'
import Chip from '@mui/material/Chip'
import CircularProgress from '@mui/material/CircularProgress'
import Alert from '@mui/material/Alert'
import DeleteOutlineIcon from '@mui/icons-material/DeleteOutline'
import ReplayIcon from '@mui/icons-material/Replay'
import OpenInNewIcon from '@mui/icons-material/OpenInNew'
import { StatusChip } from '../components/StatusChip'
import { Breadcrumbs } from '../components/Breadcrumbs'
import { useComponents, useDataPacks } from '../hooks/useWorkloadDetail'
import { redeployDataPack } from '../services/api'
import type { Environment, Workload } from '../types'

interface Props {
  environment: Environment
  workload: Workload
  onBackToEnvironments: () => void
  onBackToEnvironment: () => void
}

export function WorkloadDetailPage({ environment, workload, onBackToEnvironments, onBackToEnvironment }: Props) {
  const { data: components, loading: cLoading, error: cError } = useComponents(workload.id)
  const { data: dataPacks, loading: dLoading, error: dError, refresh: refreshPacks } = useDataPacks(workload.id)

  const handleRedeploy = async (dataPackId: string) => {
    await redeployDataPack(workload.id, dataPackId)
    refreshPacks()
  }

  return (
    <Box>
      <Breadcrumbs
        crumbs={[
          { label: 'Ava Environments',  onClick: onBackToEnvironments },
          { label: environment.name,    onClick: onBackToEnvironment },
          { label: workload.name },
        ]}
      />

      {/* Workload header */}
      <Paper variant="outlined" sx={{ p: 3, mb: 4, borderRadius: 2 }}>
        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 2 }}>
          <Typography fontWeight={700} fontSize="1.25rem">{workload.name}</Typography>
          {workload.url && (
            <Typography
              component="a"
              href={workload.url}
              target="_blank"
              rel="noopener noreferrer"
              variant="caption"
              color="primary"
              sx={{ display: 'flex', alignItems: 'center', gap: 0.5, textDecoration: 'none', '&:hover': { textDecoration: 'underline' } }}
            >
              {workload.url}
              <OpenInNewIcon sx={{ fontSize: 12 }} />
            </Typography>
          )}
          <StatusChip status={workload.status} />
        </Box>
      </Paper>

      {/* Components */}
      <Box sx={{ mb: 4 }}>
        <Typography fontWeight={700} fontSize="1rem" sx={{ mb: 2 }}>Components</Typography>
        <Divider sx={{ mb: 2 }} />

        {cLoading && <Box sx={{ display: 'flex', justifyContent: 'center', py: 4 }}><CircularProgress size={28} /></Box>}
        {cError   && <Alert severity="error">{cError}</Alert>}

        {!cLoading && !cError && (
          <Grid container spacing={2}>
            {(components ?? []).map(c => (
              <Grid item xs={12} sm={6} md={4} key={c.id}>
                <Card variant="outlined" sx={{ borderRadius: 2, height: '100%' }}>
                  <CardContent sx={{ p: 2.5 }}>
                    <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 1.5 }}>
                      <Typography fontWeight={700} fontSize="0.95rem">{c.name}</Typography>
                      <StatusChip status={c.status} />
                    </Box>
                    <Typography
                      component="a"
                      href={c.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      variant="caption"
                      color="primary"
                      sx={{ display: 'block', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', textDecoration: 'none', '&:hover': { textDecoration: 'underline' } }}
                    >
                      {c.url}
                    </Typography>
                  </CardContent>
                </Card>
              </Grid>
            ))}
            {(components ?? []).length === 0 && (
              <Grid item xs={12}><Typography color="text.secondary">No components.</Typography></Grid>
            )}
          </Grid>
        )}
      </Box>

      {/* Data packs */}
      <Box sx={{ mb: 4 }}>
        <Typography fontWeight={700} fontSize="1rem" sx={{ mb: 2 }}>Data packs</Typography>
        <Divider sx={{ mb: 2 }} />

        {dLoading && <Box sx={{ display: 'flex', justifyContent: 'center', py: 4 }}><CircularProgress size={28} /></Box>}
        {dError   && <Alert severity="error">{dError}</Alert>}

        {!dLoading && !dError && (
          <Grid container spacing={2}>
            {(dataPacks ?? []).map(dp => (
              <Grid item xs={12} sm={6} md={4} key={dp.id}>
                <Card variant="outlined" sx={{ borderRadius: 2 }}>
                  <CardContent sx={{ p: 2.5 }}>
                    <Typography fontWeight={700} fontSize="0.95rem" sx={{ mb: 1.5 }}>{dp.name}</Typography>
                    <Stack direction="row" spacing={1} alignItems="center">
                      <Button
                        size="small"
                        variant="outlined"
                        startIcon={<ReplayIcon fontSize="small" />}
                        onClick={() => handleRedeploy(dp.id)}
                        sx={{ borderRadius: 2, fontSize: '0.75rem' }}
                      >
                        Redeploy
                      </Button>
                      {dp.lastDeployed && (
                        <Chip
                          label={`Last: ${new Date(dp.lastDeployed).toLocaleDateString()}`}
                          size="small"
                          variant="outlined"
                          sx={{ fontSize: '0.7rem' }}
                        />
                      )}
                    </Stack>
                  </CardContent>
                </Card>
              </Grid>
            ))}
            {(dataPacks ?? []).length === 0 && (
              <Grid item xs={12}><Typography color="text.secondary">No data packs.</Typography></Grid>
            )}
          </Grid>
        )}
      </Box>

      {/* Delete workload */}
      <Box sx={{ display: 'flex', justifyContent: 'flex-end' }}>
        <Button variant="outlined" color="error" startIcon={<DeleteOutlineIcon />} sx={{ borderRadius: 2 }}>
          Delete Workload
        </Button>
      </Box>
    </Box>
  )
}
