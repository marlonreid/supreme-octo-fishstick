import { useState } from 'react'
import Box from '@mui/material/Box'
import Grid from '@mui/material/Grid'
import Card from '@mui/material/Card'
import CardActionArea from '@mui/material/CardActionArea'
import CardContent from '@mui/material/CardContent'
import Typography from '@mui/material/Typography'
import Button from '@mui/material/Button'
import TextField from '@mui/material/TextField'
import InputAdornment from '@mui/material/InputAdornment'
import Divider from '@mui/material/Divider'
import Stack from '@mui/material/Stack'
import Paper from '@mui/material/Paper'
import CircularProgress from '@mui/material/CircularProgress'
import Alert from '@mui/material/Alert'
import AddIcon from '@mui/icons-material/Add'
import SearchIcon from '@mui/icons-material/Search'
import DeleteOutlineIcon from '@mui/icons-material/DeleteOutline'
import AccessTimeIcon from '@mui/icons-material/AccessTime'
import TimerOffIcon from '@mui/icons-material/TimerOff'
import AttachMoneyIcon from '@mui/icons-material/AttachMoney'
import { StatusChip } from '../components/StatusChip'
import { Breadcrumbs } from '../components/Breadcrumbs'
import { useWorkloads } from '../hooks/useWorkloads'
import { useLogs } from '../hooks/useLogs'
import type { Environment, Workload } from '../types'

interface Props {
  environment: Environment
  onBack: () => void
  onSelectWorkload: (workload: Workload) => void
}

export function EnvironmentDetailPage({ environment, onBack, onSelectWorkload }: Props) {
  const [search, setSearch] = useState('')
  const { data: workloads, loading: wLoading, error: wError } = useWorkloads(environment.id)
  const { data: logs, loading: lLoading } = useLogs(environment.id)

  const filtered = (workloads ?? []).filter(w =>
    w.name.toLowerCase().includes(search.toLowerCase())
  )

  return (
    <Box>
      <Breadcrumbs
        crumbs={[
          { label: 'Ava Environments', onClick: onBack },
          { label: environment.name },
        ]}
      />

      {/* Environment header */}
      <Paper variant="outlined" sx={{ p: 3, mb: 4, borderRadius: 2 }}>
        <Box sx={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 2 }}>
          <Typography fontWeight={700} fontSize="1.25rem">{environment.name}</Typography>
          <Stack spacing={0.5} alignItems="flex-end">
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.8 }}>
              <AccessTimeIcon sx={{ fontSize: 14, color: 'text.secondary' }} />
              <Typography variant="caption" color="text.secondary">
                time up: <strong>{environment.timeUp}</strong>
              </Typography>
            </Box>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.8 }}>
              <TimerOffIcon sx={{ fontSize: 14, color: 'text.secondary' }} />
              <Typography variant="caption" color="text.secondary">
                time to teardown: <strong>{environment.timeToTeardown}</strong>
              </Typography>
            </Box>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.8 }}>
              <AttachMoneyIcon sx={{ fontSize: 14, color: 'text.secondary' }} />
              <Typography variant="caption" color="text.secondary">
                cost: <strong>{environment.totalCost}</strong>
              </Typography>
            </Box>
          </Stack>
          <StatusChip status={environment.status} />
        </Box>
      </Paper>

      {/* Workloads */}
      <Box sx={{ mb: 4 }}>
        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 2 }}>
          <Typography fontWeight={700} fontSize="1rem">Workloads</Typography>
          <Box sx={{ display: 'flex', gap: 1.5 }}>
            <Button variant="outlined" size="small" startIcon={<AddIcon />} sx={{ borderRadius: 2 }}>
              Add new workload
            </Button>
            <TextField
              size="small"
              placeholder="Search"
              value={search}
              onChange={e => setSearch(e.target.value)}
              sx={{ width: 180 }}
              InputProps={{
                endAdornment: (
                  <InputAdornment position="end">
                    <SearchIcon fontSize="small" sx={{ color: 'text.secondary' }} />
                  </InputAdornment>
                ),
              }}
            />
          </Box>
        </Box>
        <Divider sx={{ mb: 2 }} />

        {wLoading && <Box sx={{ display: 'flex', justifyContent: 'center', py: 4 }}><CircularProgress size={28} /></Box>}
        {wError   && <Alert severity="error">{wError}</Alert>}

        {!wLoading && !wError && (
          <Grid container spacing={2}>
            {filtered.map(workload => (
              <Grid item xs={12} sm={6} md={4} key={workload.id}>
                <Card
                  variant="outlined"
                  sx={{ borderRadius: 2, '&:hover': { borderColor: 'primary.main' }, transition: 'border-color 0.15s' }}
                >
                  <CardActionArea onClick={() => onSelectWorkload(workload)} sx={{ p: 0 }}>
                    <CardContent sx={{ p: 2.5 }}>
                      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 1.5 }}>
                        <Typography fontWeight={700} fontSize="0.95rem">{workload.name}</Typography>
                        <StatusChip status={workload.status} />
                      </Box>
                      <Box sx={{ display: 'inline-block', border: '1px solid', borderColor: 'divider', borderRadius: 1.5, px: 1.5, py: 0.5 }}>
                        <Typography variant="caption" fontWeight={600} color="text.secondary">{workload.version}</Typography>
                      </Box>
                    </CardContent>
                  </CardActionArea>
                </Card>
              </Grid>
            ))}
            {filtered.length === 0 && (
              <Grid item xs={12}>
                <Typography color="text.secondary">No workloads found.</Typography>
              </Grid>
            )}
          </Grid>
        )}
      </Box>

      {/* Logs */}
      <Box sx={{ mb: 4 }}>
        <Typography fontWeight={700} fontSize="1rem" sx={{ mb: 2 }}>Logs</Typography>
        <Divider sx={{ mb: 2 }} />
        <Paper variant="outlined" sx={{ p: 2, borderRadius: 2, minHeight: 100 }}>
          {lLoading && <CircularProgress size={20} />}
          {!lLoading && (logs ?? []).map(log => (
            <Box key={log.id} sx={{ display: 'flex', gap: 2, mb: 0.5 }}>
              <Typography variant="caption" color="text.disabled" sx={{ whiteSpace: 'nowrap', fontFamily: 'monospace' }}>
                {new Date(log.timestamp).toLocaleTimeString()}
              </Typography>
              <Typography variant="caption" sx={{ fontFamily: 'monospace' }}>{log.message}</Typography>
            </Box>
          ))}
        </Paper>
      </Box>

      {/* Delete */}
      <Box sx={{ display: 'flex', justifyContent: 'flex-end' }}>
        <Button variant="outlined" color="error" startIcon={<DeleteOutlineIcon />} sx={{ borderRadius: 2 }}>
          Delete Environment
        </Button>
      </Box>
    </Box>
  )
}
