import { useState } from 'react'
import Box from '@mui/material/Box'
import Grid from '@mui/material/Grid'
import Card from '@mui/material/Card'
import CardActionArea from '@mui/material/CardActionArea'
import CardContent from '@mui/material/CardContent'
import Typography from '@mui/material/Typography'
import Button from '@mui/material/Button'
import TextField from '@mui/material/TextField'
import InputAdornment from '@mui/material/InputAdornment'
import Divider from '@mui/material/Divider'
import Stack from '@mui/material/Stack'
import CircularProgress from '@mui/material/CircularProgress'
import Alert from '@mui/material/Alert'
import AddIcon from '@mui/icons-material/Add'
import SearchIcon from '@mui/icons-material/Search'
import AccessTimeIcon from '@mui/icons-material/AccessTime'
import TimerOffIcon from '@mui/icons-material/TimerOff'
import AttachMoneyIcon from '@mui/icons-material/AttachMoney'
import { StatusChip } from '../components/StatusChip'
import { useEnvironments } from '../hooks/useEnvironments'
import type { Environment } from '../types'

interface Props {
  onSelectEnvironment: (env: Environment) => void
}

export function EnvironmentsPage({ onSelectEnvironment }: Props) {
  const [search, setSearch] = useState('')
  const { data: environments, loading, error } = useEnvironments()

  const filtered = (environments ?? []).filter(e =>
    e.name.toLowerCase().includes(search.toLowerCase())
  )

  return (
    <Box>
      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 3 }}>
        <Button variant="outlined" startIcon={<AddIcon />} size="medium" sx={{ fontWeight: 600, borderRadius: 2 }}>
          Add new environment
        </Button>
        <TextField
          size="small"
          placeholder="Search"
          value={search}
          onChange={e => setSearch(e.target.value)}
          sx={{ width: 220 }}
          InputProps={{
            endAdornment: (
              <InputAdornment position="end">
                <SearchIcon fontSize="small" sx={{ color: 'text.secondary' }} />
              </InputAdornment>
            ),
          }}
        />
      </Box>

      {loading && <Box sx={{ display: 'flex', justifyContent: 'center', mt: 6 }}><CircularProgress /></Box>}
      {error   && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}

      {!loading && !error && (
        <Grid container spacing={2}>
          {filtered.map(env => (
            <Grid item xs={12} sm={6} md={4} key={env.id}>
              <Card
                variant="outlined"
                sx={{
                  borderRadius: 2,
                  transition: 'border-color 0.15s, box-shadow 0.15s',
                  '&:hover': { borderColor: 'primary.main' },
                }}
              >
                <CardActionArea onClick={() => onSelectEnvironment(env)} sx={{ p: 0 }}>
                  <CardContent sx={{ p: 2.5 }}>
                    <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 1.5 }}>
                      <Typography fontWeight={700} fontSize="1rem" noWrap sx={{ mr: 1 }}>
                        {env.name}
                      </Typography>
                      <StatusChip status={env.status} />
                    </Box>
                    <Divider sx={{ mb: 1.5 }} />
                    <Stack spacing={0.6}>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.8 }}>
                        <AccessTimeIcon sx={{ fontSize: 14, color: 'text.secondary' }} />
                        <Typography variant="caption" color="text.secondary">
                          time up: <strong>{env.timeUp}</strong>
                        </Typography>
                      </Box>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.8 }}>
                        <TimerOffIcon sx={{ fontSize: 14, color: 'text.secondary' }} />
                        <Typography variant="caption" color="text.secondary">
                          time to teardown: <strong>{env.timeToTeardown}</strong>
                        </Typography>
                      </Box>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.8 }}>
                        <AttachMoneyIcon sx={{ fontSize: 14, color: 'text.secondary' }} />
                        <Typography variant="caption" color="text.secondary">
                          cost: <strong>{env.totalCost}</strong>
                          <Typography component="span" variant="caption" color="text.disabled" sx={{ ml: 0.5 }}>
                            ({env.costPerHour}/h)
                          </Typography>
                        </Typography>
                      </Box>
                    </Stack>
                  </CardContent>
                </CardActionArea>
              </Card>
            </Grid>
          ))}

          {filtered.length === 0 && (
            <Grid item xs={12}>
              <Typography color="text.secondary" sx={{ textAlign: 'center', mt: 4 }}>
                No environments found.
              </Typography>
            </Grid>
          )}
        </Grid>
      )}
    </Box>
  )
}
