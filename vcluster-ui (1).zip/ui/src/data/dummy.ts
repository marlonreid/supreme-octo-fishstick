import type { Environment, Workload, WorkloadComponent, DataPack, LogEntry } from '../types'

export const ENVIRONMENTS: Environment[] = [
  {
    id: 'bouncing-gorilla',
    name: 'bouncing-gorilla',
    status: 'Running',
    timeUp: '2d 8h 32m',
    timeToTeardown: '14d 17h',
    costPerHour: '$0.32',
    totalCost: '$5.32',
    namespace: 'vc-bouncing-gorilla',
    createdAt: '2026-06-09T10:00:00Z',
  },
  {
    id: 'hungry-cat',
    name: 'hungry-cat',
    status: 'Running',
    timeUp: '2d 8h 32m',
    timeToTeardown: '14d 17h',
    costPerHour: '$0.32',
    totalCost: '$5.32',
    namespace: 'vc-hungry-cat',
    createdAt: '2026-06-09T10:00:00Z',
  },
  {
    id: 'golden-oyster',
    name: 'golden-oyster',
    status: 'Running',
    timeUp: '2d 8h 32m',
    timeToTeardown: '14d 17h',
    costPerHour: '$0.32',
    totalCost: '$5.32',
    namespace: 'vc-golden-oyster',
    createdAt: '2026-06-09T10:00:00Z',
  },
  {
    id: 'angry-wombat',
    name: 'angry-wombat',
    status: 'Deploying',
    timeUp: '2d 8h 32m',
    timeToTeardown: '14d 17h',
    costPerHour: '$0.32',
    totalCost: '$5.32',
    namespace: 'vc-angry-wombat',
    createdAt: '2026-06-09T10:00:00Z',
  },
]

export const WORKLOADS: Workload[] = [
  {
    id: 'weatherforecast',
    environmentId: 'bouncing-gorilla',
    name: 'Weatherforecast',
    status: 'Running',
    version: 'v 26.03',
    url: 'http://bouncing-gorilla-weatherforecast.example.com',
  },
  {
    id: 'fizzbuzz',
    environmentId: 'bouncing-gorilla',
    name: 'Fizzbuzz',
    status: 'Running',
    version: 'v 26.03',
    url: 'http://bouncing-gorilla-fizzbuzz.example.com',
  },
  {
    id: 'dataservice',
    environmentId: 'hungry-cat',
    name: 'DataService',
    status: 'Running',
    version: 'v 25.11',
    url: 'http://hungry-cat-dataservice.example.com',
  },
  {
    id: 'authportal',
    environmentId: 'golden-oyster',
    name: 'AuthPortal',
    status: 'Running',
    version: 'v 26.01',
    url: 'http://golden-oyster-authportal.example.com',
  },
]

export const COMPONENTS: WorkloadComponent[] = [
  {
    id: 'fizzbuzz-api',
    workloadId: 'fizzbuzz',
    name: 'Fizzbuzz API',
    status: 'Running',
    url: 'http://bouncing-gorilla-fizzbuzz-api.example.com',
  },
  {
    id: 'fizzbuzz-ui',
    workloadId: 'fizzbuzz',
    name: 'Fizzbuzz UI',
    status: 'Running',
    url: 'http://bouncing-gorilla-fizzbuzz-ui.example.com',
  },
  {
    id: 'fizzbuzz-db',
    workloadId: 'fizzbuzz',
    name: 'Fizzbuzz DB',
    status: 'Running',
    url: 'http://bouncing-gorilla-fizzbuzz-db.example.com',
  },
  {
    id: 'weatherforecast-api',
    workloadId: 'weatherforecast',
    name: 'Weatherforecast API',
    status: 'Running',
    url: 'http://bouncing-gorilla-weatherforecast-api.example.com',
  },
  {
    id: 'weatherforecast-ui',
    workloadId: 'weatherforecast',
    name: 'Weatherforecast UI',
    status: 'Running',
    url: 'http://bouncing-gorilla-weatherforecast-ui.example.com',
  },
]

export const DATA_PACKS: DataPack[] = [
  {
    id: 'customer-x-config',
    workloadId: 'fizzbuzz',
    name: 'Customer X config',
    lastDeployed: '2026-06-10T14:00:00Z',
  },
  {
    id: 'seed-data-v2',
    workloadId: 'fizzbuzz',
    name: 'Seed data v2',
    lastDeployed: '2026-06-08T09:00:00Z',
  },
  {
    id: 'demo-dataset',
    workloadId: 'weatherforecast',
    name: 'Demo dataset',
    lastDeployed: '2026-06-09T11:00:00Z',
  },
]

export const LOGS: LogEntry[] = [
  { id: '1', timestamp: '2026-06-11T12:00:00Z', message: 'Environment ready' },
  { id: '2', timestamp: '2026-06-11T12:01:00Z', message: "Workload 'Fizzbuzz' ready" },
  { id: '3', timestamp: '2026-06-11T12:02:00Z', message: "Workload 'Weatherforecast' ready" },
]
