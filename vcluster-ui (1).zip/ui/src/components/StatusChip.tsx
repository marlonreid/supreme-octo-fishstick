import Chip from '@mui/material/Chip'
import type { EnvironmentStatus, WorkloadStatus, ComponentStatus } from '../types'

type AnyStatus = EnvironmentStatus | WorkloadStatus | ComponentStatus

const CONFIG: Record<string, { color: 'success' | 'warning' | 'error' | 'default'; label: string }> = {
  Running:     { color: 'success', label: 'Running' },
  Deploying:   { color: 'warning', label: 'Deploying' },
  Provisioning:{ color: 'warning', label: 'Provisioning' },
  Sleeping:    { color: 'default', label: 'Sleeping' },
  Failed:      { color: 'error',   label: 'Failed' },
  Stopped:     { color: 'default', label: 'Stopped' },
}

export function StatusChip({ status }: { status: AnyStatus }) {
  const cfg = CONFIG[status] ?? { color: 'default' as const, label: status }
  return (
    <Chip
      label={cfg.label}
      color={cfg.color}
      size="small"
      variant="outlined"
      sx={{ fontWeight: 600, fontSize: '0.7rem', height: 24 }}
    />
  )
}
