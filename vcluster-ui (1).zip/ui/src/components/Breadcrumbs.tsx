import MuiBreadcrumbs from '@mui/material/Breadcrumbs'
import Typography from '@mui/material/Typography'
import Link from '@mui/material/Link'
import NavigateNextIcon from '@mui/icons-material/NavigateNext'

export interface Crumb {
  label: string
  onClick?: () => void
}

export function Breadcrumbs({ crumbs }: { crumbs: Crumb[] }) {
  return (
    <MuiBreadcrumbs
      separator={<NavigateNextIcon fontSize="small" />}
      sx={{ mb: 3, '& .MuiBreadcrumbs-separator': { color: 'text.secondary' } }}
    >
      {crumbs.map((crumb, i) => {
        const isLast = i === crumbs.length - 1
        return isLast ? (
          <Typography key={i} color="text.primary" fontWeight={600} fontSize="0.9rem">
            {crumb.label}
          </Typography>
        ) : (
          <Link
            key={i}
            component="button"
            onClick={crumb.onClick}
            underline="hover"
            color="text.secondary"
            fontSize="0.9rem"
            sx={{ cursor: 'pointer' }}
          >
            {crumb.label}
          </Link>
        )
      })}
    </MuiBreadcrumbs>
  )
}
