using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using VClusterApi.Models;

namespace VClusterApi.Services;

public interface IAzdoService
{
    /// <summary>Trigger a pipeline and return the run ID immediately.</summary>
    Task<int> TriggerPipelineAsync(int pipelineId, Dictionary<string, string> parameters, CancellationToken ct = default);

    /// <summary>Poll until the run reaches a terminal state. Yields log lines as they appear.</summary>
    IAsyncEnumerable<AzdoLogLine> StreamRunLogsAsync(int runId, CancellationToken ct = default);

    /// <summary>Get current run state without streaming.</summary>
    Task<AzdoPipelineRun> GetRunAsync(int runId, CancellationToken ct = default);
}

/// <summary>
/// Wraps the Azure DevOps Pipelines REST API.
///
/// Configuration (appsettings.json / env vars):
///   AzDo__OrgUrl        = https://dev.azure.com/your-org
///   AzDo__Project       = your-project
///   AzDo__Pat           = your-personal-access-token   (Pipelines: Read & Execute)
///
/// For production on AKS use a Managed Identity + AzDO service connection instead of PAT.
/// See README-AZDO.md for setup steps.
/// </summary>
public class AzdoService : IAzdoService
{
    private readonly HttpClient _http;
    private readonly ILogger<AzdoService> _logger;
    private readonly string _project;

    // How often to poll AzDO for new log lines whilst a pipeline is running
    private static readonly TimeSpan PollInterval = TimeSpan.FromSeconds(3);

    public AzdoService(IConfiguration config, ILogger<AzdoService> logger)
    {
        _logger = logger;
        _project = config["AzDo:Project"]
            ?? throw new InvalidOperationException("AzDo:Project not configured");

        var orgUrl = config["AzDo:OrgUrl"]
            ?? throw new InvalidOperationException("AzDo:OrgUrl not configured");
        var pat = config["AzDo:Pat"]
            ?? throw new InvalidOperationException("AzDo:Pat not configured");

        _http = new HttpClient { BaseAddress = new Uri($"{orgUrl.TrimEnd('/')}/") };

        var token = Convert.ToBase64String(Encoding.ASCII.GetBytes($":{pat}"));
        _http.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", token);
        _http.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
    }

    public async Task<int> TriggerPipelineAsync(
        int pipelineId,
        Dictionary<string, string> parameters,
        CancellationToken ct = default)
    {
        // https://learn.microsoft.com/en-us/rest/api/azure/devops/pipelines/runs/run-pipeline
        var url = $"{_project}/_apis/pipelines/{pipelineId}/runs?api-version=7.1";

        var body = new
        {
            templateParameters = parameters
        };

        var json = JsonSerializer.Serialize(body);
        var content = new StringContent(json, Encoding.UTF8, "application/json");

        var response = await _http.PostAsync(url, content, ct);
        response.EnsureSuccessStatusCode();

        var responseJson = await response.Content.ReadAsStringAsync(ct);
        var doc = JsonNode.Parse(responseJson)!;
        var runId = doc["id"]!.GetValue<int>();

        _logger.LogInformation("Triggered pipeline {PipelineId}, run {RunId}", pipelineId, runId);
        return runId;
    }

    public async Task<AzdoPipelineRun> GetRunAsync(int runId, CancellationToken ct = default)
    {
        // We use the Build API here — the Pipelines runs endpoint doesn't expose result directly
        var url = $"{_project}/_apis/build/builds/{runId}?api-version=7.1";
        var response = await _http.GetAsync(url, ct);
        response.EnsureSuccessStatusCode();

        var json = JsonNode.Parse(await response.Content.ReadAsStringAsync(ct))!;

        return new AzdoPipelineRun(
            runId,
            json["status"]?.GetValue<string>() ?? "unknown",
            json["result"]?.GetValue<string>()
        );
    }

    public async IAsyncEnumerable<AzdoLogLine> StreamRunLogsAsync(
        int runId,
        [System.Runtime.CompilerServices.EnumeratorCancellation] CancellationToken ct = default)
    {
        // AzDO doesn't push logs — we poll the timeline + log content
        // Strategy: poll build timeline, find completed steps, fetch their log tails
        var emittedLines = new HashSet<string>(); // dedupe across polls

        while (!ct.IsCancellationRequested)
        {
            var run = await GetRunAsync(runId, ct);

            // Fetch timeline to get log IDs for each step
            var timelineUrl = $"{_project}/_apis/build/builds/{runId}/timeline?api-version=7.1";
            var timelineResp = await _http.GetAsync(timelineUrl, ct);

            if (timelineResp.IsSuccessStatusCode)
            {
                var timelineJson = JsonNode.Parse(await timelineResp.Content.ReadAsStringAsync(ct));
                var records = timelineJson?["records"]?.AsArray() ?? [];

                foreach (var record in records)
                {
                    var logId = record?["log"]?["id"]?.GetValue<int>();
                    var stepName = record?["name"]?.GetValue<string>() ?? "step";
                    if (logId is null) continue;

                    var logUrl = $"{_project}/_apis/build/builds/{runId}/logs/{logId}?api-version=7.1";
                    var logResp = await _http.GetAsync(logUrl, ct);
                    if (!logResp.IsSuccessStatusCode) continue;

                    var logText = await logResp.Content.ReadAsStringAsync(ct);
                    var lines = logText.Split('\n', StringSplitOptions.RemoveEmptyEntries);

                    foreach (var (line, idx) in lines.Select((l, i) => (l, i)))
                    {
                        var key = $"{logId}:{idx}";
                        if (emittedLines.Contains(key)) continue;
                        emittedLines.Add(key);

                        var trimmed = line.Trim();
                        if (!string.IsNullOrEmpty(trimmed))
                            yield return new AzdoLogLine(idx, $"[{stepName}] {trimmed}");
                    }
                }
            }

            // Terminal states — stop polling
            if (run.State == "completed" || run.State == "canceling")
                yield break;

            await Task.Delay(PollInterval, ct);
        }
    }
}
