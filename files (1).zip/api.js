const BASE = '/api/environments'

export async function listEnvironments() {
  const res = await fetch(BASE)
  if (!res.ok) throw new Error('Failed to list environments')
  const { data } = await res.json()
  return data
}

export async function getEnvironment(id) {
  const res = await fetch(`${BASE}/${id}`)
  if (!res.ok) throw new Error('Failed to get environment')
  const { data } = await res.json()
  return data
}

export async function createEnvironment(payload) {
  const res = await fetch(BASE, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  })
  if (!res.ok) throw new Error('Failed to create environment')
  const { data } = await res.json()
  return data
}

export async function deleteEnvironment(id) {
  const res = await fetch(`${BASE}/${id}`, { method: 'DELETE' })
  if (!res.ok) throw new Error('Failed to delete environment')
}

export async function sleepEnvironment(id) {
  await fetch(`${BASE}/${id}/sleep`, { method: 'POST' })
}

export async function wakeEnvironment(id) {
  await fetch(`${BASE}/${id}/wake`, { method: 'POST' })
}

export async function getKubeconfig(id) {
  const res = await fetch(`${BASE}/${id}/kubeconfig`)
  if (!res.ok) throw new Error('Kubeconfig not ready yet')
  const { data } = await res.json()
  return data.kubeconfig
}

// Returns an EventSource — caller is responsible for closing it
export function subscribeToProgress(environmentId, onEvent, onComplete, onError) {
  const source = new EventSource(`${BASE}/${environmentId}/progress`)

  source.onmessage = (e) => {
    const evt = JSON.parse(e.data)
    if (evt.type === 'StreamComplete') {
      source.close()
      onComplete?.()
    } else {
      onEvent(evt)
    }
  }

  source.onerror = (e) => {
    source.close()
    onError?.(e)
  }

  return source
}
