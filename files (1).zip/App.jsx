import { useState } from 'react'
import { useEnvironments } from './hooks/useEnvironments'
import { EnvironmentCard } from './components/EnvironmentCard'
import { CreateEnvironmentModal } from './components/CreateEnvironmentModal'

export default function App() {
  const { environments, loading, error, refresh } = useEnvironments()
  const [showCreate, setShowCreate] = useState(false)
  const [activeTab, setActiveTab] = useState('environments')

  const handleCreated = (env) => {
    setShowCreate(false)
    refresh()
  }

  const active = environments.filter(e => !['Deleted'].includes(e.status))
  const archived = environments.filter(e => e.status === 'Deleted')

  return (
    <div style={{ minHeight: '100vh', background: '#0d1117', color: '#c9d1d9', fontFamily: 'system-ui, sans-serif' }}>

      {/* Nav */}
      <nav style={navStyle}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 32 }}>
          <span style={{ fontWeight: 700, fontSize: 16, color: '#e2e8f0' }}>
            ⎈ vCluster Platform
          </span>
          <div style={{ display: 'flex', gap: 4 }}>
            <NavTab label="Environments" active={activeTab === 'environments'} onClick={() => setActiveTab('environments')} />
            <NavTab label="Archived" active={activeTab === 'archived'} onClick={() => setActiveTab('archived')} />
          </div>
        </div>
        <button style={createBtn} onClick={() => setShowCreate(true)}>
          + New Environment
        </button>
      </nav>

      {/* Body */}
      <main style={{ maxWidth: 900, margin: '0 auto', padding: '32px 24px' }}>

        {activeTab === 'environments' && (
          <>
            <SectionHeader
              title="Active Environments"
              count={active.length}
              onRefresh={refresh}
            />

            {loading && <Muted>Loading...</Muted>}
            {error && <div style={{ color: '#fc8181' }}>{error}</div>}

            {!loading && active.length === 0 && (
              <Muted>No active environments. Create one to get started.</Muted>
            )}

            {active.map(env => (
              <EnvironmentCard key={env.id} env={env} onRefresh={refresh} />
            ))}
          </>
        )}

        {activeTab === 'archived' && (
          <>
            <SectionHeader title="Archived" count={archived.length} onRefresh={refresh} />
            {archived.length === 0 && <Muted>No archived environments.</Muted>}
            {archived.map(env => (
              <EnvironmentCard key={env.id} env={env} onRefresh={refresh} />
            ))}
          </>
        )}
      </main>

      {showCreate && (
        <CreateEnvironmentModal
          onCreated={handleCreated}
          onClose={() => setShowCreate(false)}
        />
      )}
    </div>
  )
}

function NavTab({ label, active, onClick }) {
  return (
    <button onClick={onClick} style={{
      background: 'none', border: 'none',
      padding: '6px 14px', borderRadius: 6,
      color: active ? '#e2e8f0' : '#8b949e',
      fontWeight: active ? 600 : 400,
      borderBottom: active ? '2px solid #58a6ff' : '2px solid transparent',
      cursor: 'pointer', fontSize: 14
    }}>
      {label}
    </button>
  )
}

function SectionHeader({ title, count, onRefresh }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
      <h1 style={{ margin: 0, fontSize: 20, color: '#e2e8f0', fontWeight: 600 }}>
        {title}
        <span style={{ marginLeft: 8, fontSize: 14, color: '#4a5568', fontWeight: 400 }}>({count})</span>
      </h1>
      <button onClick={onRefresh} style={{
        background: 'none', border: '1px solid #30363d',
        borderRadius: 6, padding: '4px 12px', color: '#8b949e',
        fontSize: 12, cursor: 'pointer'
      }}>↻ Refresh</button>
    </div>
  )
}

function Muted({ children }) {
  return <p style={{ color: '#4a5568', fontSize: 14 }}>{children}</p>
}

const navStyle = {
  background: '#161b22',
  borderBottom: '1px solid #21262d',
  padding: '0 24px',
  height: 56,
  display: 'flex', alignItems: 'center', justifyContent: 'space-between',
  position: 'sticky', top: 0, zIndex: 50
}

const createBtn = {
  background: '#238636', border: 'none',
  borderRadius: 6, padding: '6px 16px',
  color: '#fff', fontWeight: 600,
  fontSize: 14, cursor: 'pointer'
}
