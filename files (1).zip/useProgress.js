import { useState, useEffect, useRef } from 'react'
import { subscribeToProgress } from '../services/api'

export function useProgress(environmentId) {
  const [events, setEvents] = useState([])
  const [complete, setComplete] = useState(false)
  const sourceRef = useRef(null)

  useEffect(() => {
    if (!environmentId) return

    setEvents([])
    setComplete(false)

    const source = subscribeToProgress(
      environmentId,
      (evt) => setEvents(prev => [...prev, evt]),
      () => setComplete(true),
      () => setComplete(true)
    )

    sourceRef.current = source

    return () => {
      source.close()
    }
  }, [environmentId])

  return { events, complete }
}
