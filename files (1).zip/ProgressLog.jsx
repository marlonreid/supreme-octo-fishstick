import { useEffect, useRef } from 'react'

const EVENT_COLOURS = {
  Info:              '#a0aec0',
  PipelineQueued:    '#63b3ed',
  PipelineStarted:   '#63b3ed',
  PipelineLog:       '#718096',
  PipelineComplete:  '#68d391',
  PipelineFailed:    '#fc8181',
  ClusterReady:      '#76e4f7',
  DeployStarted:     '#63b3ed',
  EnvironmentReady:  '#68d391',
  Error:             '#fc8181',
}

export function ProgressLog({ events, complete }) {
  const bottomRef = useRef(null)

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [events])

  if (events.length === 0 && !complete) {
    return (
      <div style={{ color: '#4a5568', fontStyle: 'italic', fontSize: 13 }}>
        Waiting for pipeline...
      </div>
    )
  }

  return (
    <div style={{
      background: '#0d1117',
      borderRadius: 8,
      padding: '12px 16px',
      fontFamily: 'monospace',
      fontSize: 12,
      lineHeight: 1.7,
      maxHeight: 320,
      overflowY: 'auto',
      border: '1px solid #21262d'
    }}>
      {events.map((evt, i) => (
        <div key={i} style={{ color: EVENT_COLOURS[evt.type] ?? '#a0aec0' }}>
          <span style={{ color: '#4a5568', marginRight: 8 }}>
            {new Date(evt.timestamp).toLocaleTimeString()}
          </span>
          {evt.message}
        </div>
      ))}
      {complete && (
        <div style={{ color: '#4a5568', marginTop: 8 }}>── stream closed ──</div>
      )}
      <div ref={bottomRef} />
    </div>
  )
}
