import { useState, useEffect, useCallback } from 'react'
import { listEnvironments } from '../services/api'

export function useEnvironments() {
  const [environments, setEnvironments] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  const refresh = useCallback(async () => {
    try {
      const data = await listEnvironments()
      setEnvironments(data)
      setError(null)
    } catch (e) {
      setError(e.message)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    refresh()
    // Poll every 15s to pick up status changes from background orchestration
    const interval = setInterval(refresh, 15000)
    return () => clearInterval(interval)
  }, [refresh])

  return { environments, loading, error, refresh }
}
