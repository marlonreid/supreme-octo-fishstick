import { useState } from 'react'
import { deleteEnvironment, sleepEnvironment, wakeEnvironment, getKubeconfig } from '../services/api'
import { StatusBadge } from './StatusBadge'
import { ProgressLog } from './ProgressLog'
import { useProgress } from '../hooks/useProgress'

const ACTIVE_STATUSES = ['Queued', 'CreatingCluster', 'ClusterReady', 'DeployingWorkload', 'Deleting']

export function EnvironmentCard({ env, onRefresh }) {
  const isActive = ACTIVE_STATUSES.includes(env.status)
  const [showLog, setShowLog] = useState(isActive)
  const [kubeconfigCopied, setKubeconfigCopied] = useState(false)

  const { events, complete } = useProgress(isActive ? env.id : null)

  const handleDelete = async () => {
    if (!confirm(`Delete environment "${env.name}"?`)) return
    await deleteEnvironment(env.id)
    onRefresh()
  }

  const handleSleep = async () => { await sleepEnvironment(env.id); onRefresh() }
  const handleWake = async () => { await wakeEnvironment(env.id); onRefresh() }

  const handleCopyKubeconfig = async () => {
    const kc = await getKubeconfig(env.id)
    await navigator.clipboard.writeText(kc)
    setKubeconfigCopied(true)
    setTimeout(() => setKubeconfigCopied(false), 2000)
  }

  const expiresIn = env.expiresAt
    ? Math.max(0, Math.round((new Date(env.expiresAt) - Date.now()) / 3600000))
    : null

  return (
    <div style={card}>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 12 }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 4 }}>
            <span style={{ fontWeight: 700, color: '#e2e8f0', fontSize: 15 }}>{env.name}</span>
            <StatusBadge status={env.status} />
          </div>
          <div style={{ fontSize: 12, color: '#4a5568' }}>
            ns: {env.namespace}
            {expiresIn !== null && (
              <span style={{ marginLeft: 12, color: expiresIn < 2 ? '#fc8181' : '#718096' }}>
                ⏱ expires in {expiresIn}h
              </span>
            )}
            {env.currentCostGbp != null && (
              <span style={{ marginLeft: 12, color: '#f6ad55' }}>
                £{env.currentCostGbp.toFixed(2)}
              </span>
            )}
          </div>
        </div>

        {/* Actions */}
        <div style={{ display: 'flex', gap: 8, flexShrink: 0 }}>
          {env.status === 'Ready' && (
            <>
              <ActionButton onClick={handleCopyKubeconfig} title={kubeconfigCopied ? '✓ Copied' : 'Copy kubeconfig'} />
              <ActionButton onClick={handleSleep} title="Sleep" />
            </>
          )}
          {env.status === 'Sleeping' && (
            <ActionButton onClick={handleWake} title="Wake" />
          )}
          {(isActive || events.length > 0) && (
            <ActionButton onClick={() => setShowLog(v => !v)} title={showLog ? 'Hide log' : 'Show log'} />
          )}
          {!['Deleted', 'Deleting'].includes(env.status) && (
            <ActionButton onClick={handleDelete} title="Delete" danger />
          )}
        </div>
      </div>

      {/* Progress log */}
      {showLog && (isActive || events.length > 0) && (
        <div style={{ marginTop: 16 }}>
          <ProgressLog events={events} complete={complete} />
        </div>
      )}
    </div>
  )
}

function ActionButton({ onClick, title, danger }) {
  return (
    <button onClick={onClick} style={{
      background: danger ? 'rgba(248,81,73,0.1)' : 'rgba(255,255,255,0.05)',
      border: `1px solid ${danger ? 'rgba(248,81,73,0.4)' : '#30363d'}`,
      borderRadius: 6, padding: '4px 12px',
      color: danger ? '#f85149' : '#8b949e',
      fontSize: 12, cursor: 'pointer'
    }}>
      {title}
    </button>
  )
}

const card = {
  background: '#161b22',
  border: '1px solid #21262d',
  borderRadius: 10,
  padding: '16px 20px',
  marginBottom: 12
}
