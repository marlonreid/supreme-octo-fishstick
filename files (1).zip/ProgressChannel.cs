using System.Collections.Concurrent;
using System.Threading.Channels;
using VClusterApi.Models;

namespace VClusterApi.Services;

/// <summary>
/// Per-environment broadcast channel.
/// VClusterService writes progress events; SSE endpoints subscribe and read them.
/// Multiple browser tabs can connect simultaneously — each gets its own reader.
/// </summary>
public class ProgressChannel
{
    // environmentId → list of active subscriber channels
    private readonly ConcurrentDictionary<string, ConcurrentBag<Channel<ProgressEvent>>> _subscribers = new();

    /// <summary>Subscribe to events for a specific environment. Dispose the returned object to unsubscribe.</summary>
    public (ChannelReader<ProgressEvent> Reader, IDisposable Unsubscribe) Subscribe(string environmentId)
    {
        var channel = Channel.CreateUnbounded<ProgressEvent>(new UnboundedChannelOptions
        {
            SingleReader = true,
            SingleWriter = false
        });

        var bag = _subscribers.GetOrAdd(environmentId, _ => new ConcurrentBag<Channel<ProgressEvent>>());
        bag.Add(channel);

        var unsubscribe = new Unsubscriber(() =>
        {
            // Channels can't be removed from ConcurrentBag — we mark complete instead
            channel.Writer.TryComplete();
        });

        return (channel.Reader, unsubscribe);
    }

    /// <summary>Broadcast an event to all subscribers for this environment.</summary>
    public void Publish(ProgressEvent evt)
    {
        if (!_subscribers.TryGetValue(evt.EnvironmentId, out var bag)) return;

        foreach (var channel in bag)
            channel.Writer.TryWrite(evt);
    }

    /// <summary>Complete all subscribers for this environment (terminal state reached).</summary>
    public void Complete(string environmentId)
    {
        if (!_subscribers.TryGetValue(environmentId, out var bag)) return;

        foreach (var channel in bag)
            channel.Writer.TryComplete();

        _subscribers.TryRemove(environmentId, out _);
    }

    private class Unsubscriber(Action onDispose) : IDisposable
    {
        public void Dispose() => onDispose();
    }
}
