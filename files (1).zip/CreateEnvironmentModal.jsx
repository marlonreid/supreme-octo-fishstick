import { useState } from 'react'
import { createEnvironment } from '../services/api'

export function CreateEnvironmentModal({ onCreated, onClose }) {
  const [form, setForm] = useState({
    name: '',
    k8sVersion: '',
    ttlHours: '',
    costThresholdGbp: ''
  })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)

  const set = (field) => (e) => setForm(f => ({ ...f, [field]: e.target.value }))

  const submit = async () => {
    if (!form.name.trim()) return setError('Name is required')
    setLoading(true)
    setError(null)
    try {
      const env = await createEnvironment({
        name: form.name.trim(),
        namespace: `vc-${form.name.trim()}`,
        k8sVersion: form.k8sVersion || null,
        ttlHours: form.ttlHours ? parseInt(form.ttlHours) : null,
        costThresholdGbp: form.costThresholdGbp ? parseFloat(form.costThresholdGbp) : null
      })
      onCreated(env)
    } catch (e) {
      setError(e.message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div style={overlay}>
      <div style={modal}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
          <h2 style={{ margin: 0, fontSize: 18, color: '#e2e8f0' }}>New Environment</h2>
          <button onClick={onClose} style={closeBtn}>✕</button>
        </div>

        <Field label="Name *">
          <input style={input} value={form.name} onChange={set('name')} placeholder="my-feature-branch" />
        </Field>

        <Field label="K8s Version">
          <input style={input} value={form.k8sVersion} onChange={set('k8sVersion')} placeholder="leave blank for default" />
        </Field>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
          <Field label="TTL (hours)">
            <input style={input} type="number" value={form.ttlHours} onChange={set('ttlHours')} placeholder="e.g. 8" />
          </Field>
          <Field label="Cost limit (£)">
            <input style={input} type="number" step="0.01" value={form.costThresholdGbp} onChange={set('costThresholdGbp')} placeholder="e.g. 5.00" />
          </Field>
        </div>

        {error && <div style={{ color: '#fc8181', fontSize: 13, marginTop: 8 }}>{error}</div>}

        <div style={{ display: 'flex', gap: 12, marginTop: 24 }}>
          <button style={primaryBtn} onClick={submit} disabled={loading}>
            {loading ? 'Creating...' : 'Create'}
          </button>
          <button style={secondaryBtn} onClick={onClose} disabled={loading}>Cancel</button>
        </div>
      </div>
    </div>
  )
}

function Field({ label, children }) {
  return (
    <div style={{ marginBottom: 16 }}>
      <label style={{ display: 'block', fontSize: 12, color: '#718096', marginBottom: 6, fontWeight: 600 }}>
        {label}
      </label>
      {children}
    </div>
  )
}

const overlay = {
  position: 'fixed', inset: 0,
  background: 'rgba(0,0,0,0.7)',
  display: 'flex', alignItems: 'center', justifyContent: 'center',
  zIndex: 100
}
const modal = {
  background: '#161b22',
  border: '1px solid #30363d',
  borderRadius: 12,
  padding: 32,
  width: 480,
  maxWidth: '90vw'
}
const input = {
  width: '100%', boxSizing: 'border-box',
  background: '#0d1117', border: '1px solid #30363d',
  borderRadius: 6, padding: '8px 12px',
  color: '#e2e8f0', fontSize: 14,
  outline: 'none'
}
const primaryBtn = {
  background: '#238636', border: 'none', borderRadius: 6,
  padding: '8px 20px', color: '#fff', fontSize: 14,
  cursor: 'pointer', fontWeight: 600
}
const secondaryBtn = {
  background: 'transparent', border: '1px solid #30363d',
  borderRadius: 6, padding: '8px 20px', color: '#8b949e',
  fontSize: 14, cursor: 'pointer'
}
const closeBtn = {
  background: 'none', border: 'none', color: '#8b949e',
  fontSize: 18, cursor: 'pointer', padding: 4
}
