using k8s;
using k8s.Models;
using System.Text;
using System.Text.Json;
using VClusterApi.Models;

namespace VClusterApi.Services;

public class VClusterService(
    IKubernetes k8s,
    IAzdoService azdo,
    EnvironmentStore store,
    ProgressChannel progress,
    IConfiguration config,
    ILogger<VClusterService> logger) : IVClusterService
{
    private const string ManagedByLabel = "app.kubernetes.io/managed-by";
    private const string ManagedByValue = "vcluster-api";
    private const string AppLabel = "app";
    private const string AppLabelValue = "vcluster";

    // Pipeline IDs from config — see appsettings.json
    private int CreatePipelineId => config.GetValue<int>("Pipelines:CreateVCluster");
    private int DeployPipelineId => config.GetValue<int>("Pipelines:DeployWorkload");
    private int DeletePipelineId => config.GetValue<int>("Pipelines:DeleteVCluster");

    // How long to wait between readiness polls after cluster creation
    private static readonly TimeSpan ReadinessPollInterval = TimeSpan.FromSeconds(5);
    private static readonly TimeSpan ReadinessTimeout = TimeSpan.FromMinutes(10);

    // -------------------------------------------------------------------------
    // Create — fire and forget the long-running work, return immediately
    // -------------------------------------------------------------------------

    public async Task<VClusterEnvironment> CreateAsync(CreateVClusterRequest request, CancellationToken ct = default)
    {
        var env = new VClusterEnvironment(
            Id: Guid.NewGuid().ToString(),
            Name: request.Name,
            Namespace: $"vc-{request.Name}",
            Status: EnvironmentStatus.Queued,
            K8sVersion: request.K8sVersion,
            TtlHours: request.TtlHours,
            CostThresholdGbp: request.CostThresholdGbp,
            CreatedAt: DateTime.UtcNow,
            ReadyAt: null,
            ExpiresAt: request.TtlHours.HasValue
                ? DateTime.UtcNow.AddHours(request.TtlHours.Value)
                : null,
            CreatePipelineRunId: null,
            DeployPipelineRunId: null,
            ErrorMessage: null,
            Labels: request.Labels ?? new Dictionary<string, string>()
        );

        store.Upsert(env);

        // Kick off the long-running orchestration without blocking the HTTP response
        _ = Task.Run(() => OrchestateCreationAsync(env.Id), CancellationToken.None);

        return env;
    }

    // -------------------------------------------------------------------------
    // Delete
    // -------------------------------------------------------------------------

    public async Task DeleteAsync(string environmentId, CancellationToken ct = default)
    {
        var env = store.Get(environmentId)
            ?? throw new KeyNotFoundException($"Environment {environmentId} not found");

        store.Update(environmentId, e => e with { Status = EnvironmentStatus.Deleting });
        Emit(environmentId, ProgressEventType.Info, $"Deleting environment {env.Name}...");

        var runId = await azdo.TriggerPipelineAsync(DeletePipelineId, new Dictionary<string, string>
        {
            ["vclusterName"] = env.Name,
            ["namespace"] = env.Namespace
        }, ct);

        _ = Task.Run(() => WatchDeletePipelineAsync(environmentId, runId), CancellationToken.None);
    }

    // -------------------------------------------------------------------------
    // List / Get
    // -------------------------------------------------------------------------

    public Task<IEnumerable<VClusterSummary>> ListAsync(CancellationToken ct = default)
    {
        var summaries = store.GetAll().Select(e => new VClusterSummary(
            e.Id, e.Name, e.Namespace, e.Status, e.CreatedAt, e.ExpiresAt, null));

        return Task.FromResult(summaries);
    }

    public async Task<VClusterDetail?> GetDetailAsync(string environmentId, CancellationToken ct = default)
    {
        var env = store.Get(environmentId);
        if (env is null) return null;

        VClusterPodStatus[] podStatuses = [];

        try
        {
            var pods = await k8s.CoreV1.ListNamespacedPodAsync(
                env.Namespace,
                labelSelector: $"{AppLabel}={AppLabelValue}",
                cancellationToken: ct);

            podStatuses = pods.Items.Select(p => new VClusterPodStatus(
                p.Metadata.Name,
                p.Status?.Phase ?? "Unknown",
                p.Status?.ContainerStatuses?.All(cs => cs.Ready) ?? false,
                p.Status?.ContainerStatuses?.Sum(cs => cs.RestartCount) ?? 0,
                p.Status?.StartTime
            )).ToArray();
        }
        catch (Exception ex)
        {
            logger.LogWarning(ex, "Could not fetch pods for {Namespace} — cluster may not exist yet", env.Namespace);
        }

        return new VClusterDetail(
            env.Id, env.Name, env.Namespace, env.Status, env.K8sVersion,
            env.CreatedAt, env.ReadyAt, env.ExpiresAt, env.TtlHours,
            env.CostThresholdGbp, null, podStatuses,
            $"vc-{env.Name}", env.ErrorMessage);
    }

    // -------------------------------------------------------------------------
    // Kubeconfig
    // -------------------------------------------------------------------------

    public async Task<VClusterKubeconfig> GetKubeconfigAsync(string environmentId, CancellationToken ct = default)
    {
        var env = store.Get(environmentId)
            ?? throw new KeyNotFoundException($"Environment {environmentId} not found");

        var secretName = $"vc-{env.Name}";

        V1Secret secret;
        try
        {
            secret = await k8s.CoreV1.ReadNamespacedSecretAsync(secretName, env.Namespace, cancellationToken: ct);
        }
        catch (k8s.Autorest.HttpOperationException ex) when (ex.Response.StatusCode == System.Net.HttpStatusCode.NotFound)
        {
            throw new InvalidOperationException(
                $"Kubeconfig secret not found. The vCluster may still be initialising.");
        }

        if (!secret.Data.TryGetValue("config", out var bytes))
            throw new InvalidOperationException("Secret exists but contains no 'config' key.");

        return new VClusterKubeconfig(env.Name, env.Namespace, Encoding.UTF8.GetString(bytes));
    }

    // -------------------------------------------------------------------------
    // Sleep / Wake
    // -------------------------------------------------------------------------

    public async Task SleepAsync(string environmentId, CancellationToken ct = default)
    {
        var env = store.Get(environmentId) ?? throw new KeyNotFoundException();
        await PatchReplicasAsync(env.Name, env.Namespace, 0, ct);
        store.Update(environmentId, e => e with { Status = EnvironmentStatus.Sleeping });
    }

    public async Task WakeAsync(string environmentId, CancellationToken ct = default)
    {
        var env = store.Get(environmentId) ?? throw new KeyNotFoundException();
        await PatchReplicasAsync(env.Name, env.Namespace, 1, ct);
        store.Update(environmentId, e => e with { Status = EnvironmentStatus.Ready });
    }

    // -------------------------------------------------------------------------
    // Orchestration — runs in background after Create returns
    // -------------------------------------------------------------------------

    private async Task OrchestateCreationAsync(string environmentId)
    {
        try
        {
            var env = store.Get(environmentId)!;

            // ── Step 1: Trigger create pipeline ──────────────────────────────
            store.Update(environmentId, e => e with { Status = EnvironmentStatus.CreatingCluster });
            Emit(environmentId, ProgressEventType.PipelineQueued, "Triggering vCluster create pipeline...");

            var createRunId = await azdo.TriggerPipelineAsync(CreatePipelineId, new Dictionary<string, string>
            {
                ["vclusterName"] = env.Name,
                ["namespace"] = env.Namespace,
                ["k8sVersion"] = env.K8sVersion ?? "latest"
            });

            store.Update(environmentId, e => e with { CreatePipelineRunId = createRunId.ToString() });
            Emit(environmentId, ProgressEventType.PipelineStarted, $"Create pipeline running (run #{createRunId})");

            // ── Step 2: Stream pipeline logs until complete ───────────────────
            await foreach (var line in azdo.StreamRunLogsAsync(createRunId))
                Emit(environmentId, ProgressEventType.PipelineLog, line.Text);

            var createRun = await azdo.GetRunAsync(createRunId);
            if (createRun.Result != "succeeded")
            {
                FailEnvironment(environmentId, $"Create pipeline failed: {createRun.Result}");
                return;
            }

            Emit(environmentId, ProgressEventType.PipelineComplete, "Create pipeline succeeded");

            // ── Step 3: Poll K8s until StatefulSet is ready ───────────────────
            store.Update(environmentId, e => e with { Status = EnvironmentStatus.ClusterReady });
            Emit(environmentId, ProgressEventType.Info, "Waiting for vCluster StatefulSet to become ready...");

            var ready = await WaitForClusterReadyAsync(env.Namespace, env.Name);
            if (!ready)
            {
                FailEnvironment(environmentId, "vCluster StatefulSet did not become ready within timeout");
                return;
            }

            Emit(environmentId, ProgressEventType.ClusterReady, "vCluster is ready");

            // ── Step 4: Trigger deploy pipeline ──────────────────────────────
            store.Update(environmentId, e => e with { Status = EnvironmentStatus.DeployingWorkload });
            Emit(environmentId, ProgressEventType.DeployStarted, "Triggering workload deploy pipeline...");

            var deployRunId = await azdo.TriggerPipelineAsync(DeployPipelineId, new Dictionary<string, string>
            {
                ["vclusterName"] = env.Name,
                ["namespace"] = env.Namespace
            });

            store.Update(environmentId, e => e with { DeployPipelineRunId = deployRunId.ToString() });
            Emit(environmentId, ProgressEventType.PipelineStarted, $"Deploy pipeline running (run #{deployRunId})");

            await foreach (var line in azdo.StreamRunLogsAsync(deployRunId))
                Emit(environmentId, ProgressEventType.PipelineLog, line.Text);

            var deployRun = await azdo.GetRunAsync(deployRunId);
            if (deployRun.Result != "succeeded")
            {
                FailEnvironment(environmentId, $"Deploy pipeline failed: {deployRun.Result}");
                return;
            }

            // ── Step 5: Done ──────────────────────────────────────────────────
            store.Update(environmentId, e => e with
            {
                Status = EnvironmentStatus.Ready,
                ReadyAt = DateTime.UtcNow
            });

            Emit(environmentId, ProgressEventType.EnvironmentReady, $"Environment '{env.Name}' is ready");
            progress.Complete(environmentId);
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Unhandled error orchestrating environment {Id}", environmentId);
            FailEnvironment(environmentId, ex.Message);
        }
    }

    private async Task WatchDeletePipelineAsync(string environmentId, int runId)
    {
        try
        {
            await foreach (var line in azdo.StreamRunLogsAsync(runId))
                Emit(environmentId, ProgressEventType.PipelineLog, line.Text);

            var run = await azdo.GetRunAsync(runId);
            if (run.Result == "succeeded")
            {
                store.Update(environmentId, e => e with { Status = EnvironmentStatus.Deleted });
                Emit(environmentId, ProgressEventType.PipelineComplete, "Environment deleted");
            }
            else
            {
                FailEnvironment(environmentId, $"Delete pipeline failed: {run.Result}");
            }
        }
        catch (Exception ex)
        {
            FailEnvironment(environmentId, ex.Message);
        }
        finally
        {
            progress.Complete(environmentId);
        }
    }

    private async Task<bool> WaitForClusterReadyAsync(string namespaceName, string name)
    {
        using var cts = new CancellationTokenSource(ReadinessTimeout);

        while (!cts.Token.IsCancellationRequested)
        {
            try
            {
                var ss = await k8s.AppsV1.ReadNamespacedStatefulSetAsync(name, namespaceName, cancellationToken: cts.Token);
                var ready = ss.Status?.ReadyReplicas ?? 0;
                var desired = ss.Spec?.Replicas ?? 1;

                if (ready >= desired) return true;

                logger.LogDebug("vCluster {Name} not ready yet ({Ready}/{Desired})", name, ready, desired);
            }
            catch (Exception ex)
            {
                logger.LogDebug(ex, "StatefulSet not found yet for {Name}", name);
            }

            await Task.Delay(ReadinessPollInterval, cts.Token);
        }

        return false;
    }

    // -------------------------------------------------------------------------
    // Helpers
    // -------------------------------------------------------------------------

    private void Emit(string environmentId, ProgressEventType type, string message, string? detail = null)
    {
        var evt = new ProgressEvent(environmentId, type, message, DateTime.UtcNow, detail);
        progress.Publish(evt);
        logger.LogInformation("[{Type}] {Message}", type, message);
    }

    private void FailEnvironment(string environmentId, string error)
    {
        store.Update(environmentId, e => e with { Status = EnvironmentStatus.Failed, ErrorMessage = error });
        Emit(environmentId, ProgressEventType.Error, error);
        progress.Complete(environmentId);
    }

    private async Task PatchReplicasAsync(string name, string namespaceName, int replicas, CancellationToken ct)
    {
        var patch = new V1Patch(
            JsonSerializer.Serialize(new { spec = new { replicas } }),
            V1Patch.PatchType.MergePatch);

        await k8s.AppsV1.PatchNamespacedStatefulSetAsync(patch, name, namespaceName, cancellationToken: ct);
    }
}
