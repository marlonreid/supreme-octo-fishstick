using System.Text;
using System.Text.Json;
using Microsoft.AspNetCore.Mvc;
using VClusterApi.Models;
using VClusterApi.Services;

namespace VClusterApi.Controllers;

[ApiController]
[Route("api/environments")]
[Produces("application/json")]
public class EnvironmentsController(
    IVClusterService vcluster,
    ProgressChannel progress,
    ILogger<EnvironmentsController> logger) : ControllerBase
{
    // GET /api/environments
    [HttpGet]
    [ProducesResponseType<ApiResponse<IEnumerable<VClusterSummary>>>(200)]
    public async Task<IActionResult> List(CancellationToken ct)
    {
        var list = await vcluster.ListAsync(ct);
        return Ok(new ApiResponse<IEnumerable<VClusterSummary>>(true, list));
    }

    // GET /api/environments/{id}
    [HttpGet("{id}")]
    [ProducesResponseType<ApiResponse<VClusterDetail>>(200)]
    [ProducesResponseType(404)]
    public async Task<IActionResult> Get(string id, CancellationToken ct)
    {
        var detail = await vcluster.GetDetailAsync(id, ct);
        if (detail is null)
            return NotFound(new ApiResponse<VClusterDetail>(false, null, "Environment not found"));

        return Ok(new ApiResponse<VClusterDetail>(true, detail));
    }

    // POST /api/environments
    [HttpPost]
    [ProducesResponseType<ApiResponse<VClusterEnvironment>>(202)]
    [ProducesResponseType(400)]
    public async Task<IActionResult> Create([FromBody] CreateVClusterRequest request, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(request.Name))
            return BadRequest(new ApiResponse<VClusterEnvironment>(false, null, "Name is required"));

        var env = await vcluster.CreateAsync(request, ct);

        // 202 Accepted — creation is async, client should subscribe to /progress
        return AcceptedAtAction(nameof(Get), new { id = env.Id },
            new ApiResponse<VClusterEnvironment>(true, env));
    }

    // DELETE /api/environments/{id}
    [HttpDelete("{id}")]
    [ProducesResponseType(202)]
    [ProducesResponseType(404)]
    public async Task<IActionResult> Delete(string id, CancellationToken ct)
    {
        try
        {
            await vcluster.DeleteAsync(id, ct);
            return Accepted();
        }
        catch (KeyNotFoundException)
        {
            return NotFound(new ApiResponse<object>(false, null, "Environment not found"));
        }
    }

    // GET /api/environments/{id}/kubeconfig
    [HttpGet("{id}/kubeconfig")]
    [ProducesResponseType<ApiResponse<VClusterKubeconfig>>(200)]
    public async Task<IActionResult> GetKubeconfig(string id, CancellationToken ct)
    {
        try
        {
            var kc = await vcluster.GetKubeconfigAsync(id, ct);
            return Ok(new ApiResponse<VClusterKubeconfig>(true, kc));
        }
        catch (InvalidOperationException ex)
        {
            return NotFound(new ApiResponse<VClusterKubeconfig>(false, null, ex.Message));
        }
    }

    // POST /api/environments/{id}/sleep
    [HttpPost("{id}/sleep")]
    [ProducesResponseType(204)]
    public async Task<IActionResult> Sleep(string id, CancellationToken ct)
    {
        await vcluster.SleepAsync(id, ct);
        return NoContent();
    }

    // POST /api/environments/{id}/wake
    [HttpPost("{id}/wake")]
    [ProducesResponseType(204)]
    public async Task<IActionResult> Wake(string id, CancellationToken ct)
    {
        await vcluster.WakeAsync(id, ct);
        return NoContent();
    }

    // ── SSE progress stream ───────────────────────────────────────────────────
    // GET /api/environments/{id}/progress
    //
    // Returns a text/event-stream. Each event is a JSON-serialised ProgressEvent.
    // The stream closes when the environment reaches a terminal state (ready/failed/deleted).
    // Clients should reconnect with ?lastEventId=<timestamp> to resume after disconnect.
    [HttpGet("{id}/progress")]
    public async Task Progress(string id, CancellationToken ct)
    {
        Response.Headers.Append("Content-Type", "text/event-stream");
        Response.Headers.Append("Cache-Control", "no-cache");
        Response.Headers.Append("X-Accel-Buffering", "no"); // disable nginx buffering

        var (reader, unsubscribe) = progress.Subscribe(id);

        try
        {
            await foreach (var evt in reader.ReadAllAsync(ct))
            {
                var json = JsonSerializer.Serialize(evt, new JsonSerializerOptions
                {
                    PropertyNamingPolicy = JsonNamingPolicy.CamelCase
                });

                var line = $"data: {json}\n\n";
                await Response.WriteAsync(line, Encoding.UTF8, ct);
                await Response.Body.FlushAsync(ct);
            }

            // Signal the browser that the stream is done
            await Response.WriteAsync("data: {\"type\":\"StreamComplete\"}\n\n", ct);
            await Response.Body.FlushAsync(ct);
        }
        catch (OperationCanceledException)
        {
            // Client disconnected — normal
        }
        finally
        {
            unsubscribe.Dispose();
        }
    }
}
