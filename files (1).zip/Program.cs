using k8s;
using VClusterApi.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();
builder.Services.AddOpenApi();

builder.Services.AddCors(options =>
{
    options.AddDefaultPolicy(policy =>
    {
        // In dev, React runs on :5173 (Vite default)
        policy
            .WithOrigins(
                "http://localhost:5173",
                "http://localhost:3000")
            .AllowAnyHeader()
            .AllowAnyMethod();
    });
});

// Kubernetes client — in-cluster on AKS, kubeconfig locally
builder.Services.AddSingleton<IKubernetes>(_ =>
{
    var config = KubernetesClientConfiguration.IsInCluster()
        ? KubernetesClientConfiguration.InClusterConfig()
        : KubernetesClientConfiguration.BuildConfigFromConfigFile();

    return new Kubernetes(config);
});

// Singleton so state survives across requests
builder.Services.AddSingleton<EnvironmentStore>();
builder.Services.AddSingleton<ProgressChannel>();
builder.Services.AddSingleton<IAzdoService, AzdoService>();
builder.Services.AddScoped<IVClusterService, VClusterService>();

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.MapOpenApi();
    app.MapScalarApiReference();
}

app.UseCors();
app.UseHttpsRedirection();
app.UseAuthorization();
app.MapControllers();

app.Run();
