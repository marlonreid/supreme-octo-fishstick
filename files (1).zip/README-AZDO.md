# AzDO Pipeline Setup

## Required pipelines

You need three pipelines in your AzDO project. Once created, put their numeric IDs
in `appsettings.json` under `Pipelines`.

Get the ID from the pipeline URL:
`https://dev.azure.com/your-org/your-project/_build?definitionId=42`
                                                                     ^^

---

### 1. CreateVCluster pipeline

```yaml
# azure-pipelines-create-vcluster.yml
parameters:
  - name: vclusterName
    type: string
  - name: namespace
    type: string
  - name: k8sVersion
    type: string
    default: latest

trigger: none

pool:
  vmImage: ubuntu-latest

steps:
  - task: AzureCLI@2
    displayName: Set AKS context
    inputs:
      azureSubscription: $(SERVICE_CONNECTION)
      scriptType: bash
      scriptLocation: inlineScript
      inlineScript: |
        az aks get-credentials \
          --resource-group $(AKS_RG) \
          --name $(AKS_CLUSTER) \
          --overwrite-existing

  - script: |
      curl -L -o vcluster "https://github.com/loft-sh/vcluster/releases/download/v0.34.1/vcluster-linux-amd64"
      chmod +x vcluster && sudo mv vcluster /usr/local/bin/
    displayName: Install vcluster CLI

  - script: |
      vcluster create ${{ parameters.vclusterName }} \
        --namespace ${{ parameters.namespace }} \
        --connect=false
    displayName: Create vCluster
```

---

### 2. DeployWorkload pipeline

```yaml
# azure-pipelines-deploy-workload.yml
parameters:
  - name: vclusterName
    type: string
  - name: namespace
    type: string

trigger: none

pool:
  vmImage: ubuntu-latest

steps:
  - task: AzureCLI@2
    displayName: Set AKS context
    inputs:
      azureSubscription: $(SERVICE_CONNECTION)
      scriptType: bash
      scriptLocation: inlineScript
      inlineScript: |
        az aks get-credentials \
          --resource-group $(AKS_RG) \
          --name $(AKS_CLUSTER) \
          --overwrite-existing

  - script: |
      curl -L -o vcluster "https://github.com/loft-sh/vcluster/releases/download/v0.34.1/vcluster-linux-amd64"
      chmod +x vcluster && sudo mv vcluster /usr/local/bin/
    displayName: Install vcluster CLI

  - script: |
      vcluster connect ${{ parameters.vclusterName }} \
        --namespace ${{ parameters.namespace }} \
        --update-current=false \
        --kube-config ./vc-kubeconfig.yaml

      export KUBECONFIG=./vc-kubeconfig.yaml
      # Deploy your workload here — helm install, kubectl apply, etc.
      kubectl get nodes
    displayName: Deploy workload
```

---

### 3. DeleteVCluster pipeline

```yaml
# azure-pipelines-delete-vcluster.yml
parameters:
  - name: vclusterName
    type: string
  - name: namespace
    type: string

trigger: none

pool:
  vmImage: ubuntu-latest

steps:
  - task: AzureCLI@2
    displayName: Set AKS context
    inputs:
      azureSubscription: $(SERVICE_CONNECTION)
      scriptType: bash
      scriptLocation: inlineScript
      inlineScript: |
        az aks get-credentials \
          --resource-group $(AKS_RG) \
          --name $(AKS_CLUSTER) \
          --overwrite-existing

  - script: |
      curl -L -o vcluster "https://github.com/loft-sh/vcluster/releases/download/v0.34.1/vcluster-linux-amd64"
      chmod +x vcluster && sudo mv vcluster /usr/local/bin/
    displayName: Install vcluster CLI

  - script: |
      vcluster delete ${{ parameters.vclusterName }} \
        --namespace ${{ parameters.namespace }}
    displayName: Delete vCluster
```

---

## Pipeline variables

Set these as pipeline variables or in a variable group:

| Variable | Description |
|---|---|
| `SERVICE_CONNECTION` | AzDO service connection name for your Azure subscription |
| `AKS_RG` | Resource group containing your AKS cluster |
| `AKS_CLUSTER` | AKS cluster name |

---

## Authentication — PAT vs Managed Identity

**For local dev**: create a PAT at `https://dev.azure.com/your-org/_usersSettings/tokens`
with scope **Pipelines: Read & Execute**. Set via user secrets:

```bash
cd api
dotnet user-secrets set "AzDo:Pat" "your-pat-here"
```

**For production on AKS**: use a Managed Identity with an AzDO service connection.
Remove the PAT config and update `AzdoService` to use `DefaultAzureCredential`
from `Azure.Identity` to acquire an AzDO token.
