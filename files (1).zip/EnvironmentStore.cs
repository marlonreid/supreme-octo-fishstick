using System.Collections.Concurrent;
using VClusterApi.Models;

namespace VClusterApi.Services;

/// <summary>
/// In-memory store for environment state.
/// Survives the request lifecycle but not pod restarts.
/// Replace with a Redis or SQL backend for production.
/// </summary>
public class EnvironmentStore
{
    private readonly ConcurrentDictionary<string, VClusterEnvironment> _environments = new();

    public void Upsert(VClusterEnvironment env) =>
        _environments[env.Id] = env;

    public VClusterEnvironment? Get(string id) =>
        _environments.TryGetValue(id, out var env) ? env : null;

    public VClusterEnvironment? GetByName(string name) =>
        _environments.Values.FirstOrDefault(e => e.Name == name);

    public IEnumerable<VClusterEnvironment> GetAll() =>
        _environments.Values.OrderByDescending(e => e.CreatedAt);

    public VClusterEnvironment Update(string id, Func<VClusterEnvironment, VClusterEnvironment> mutate)
    {
        var current = _environments[id];
        var updated = mutate(current);
        _environments[id] = updated;
        return updated;
    }
}
