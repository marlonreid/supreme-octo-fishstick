# vCluster Platform

Ephemeral Kubernetes environments via vCluster, driven by AzDO pipelines,
with a React UI and SSE progress streaming.

## Architecture

```
React UI (Vite :5173)
  │
  ├── POST /api/environments          → create (returns 202 immediately)
  ├── GET  /api/environments/{id}/progress  → SSE stream of pipeline logs
  ├── GET  /api/environments          → list (polls every 15s)
  └── GET  /api/environments/{id}     → detail + pod status

.NET 10 API (:5000)
  │
  ├── AzdoService     → triggers AzDO pipelines, polls logs
  ├── VClusterService → orchestrates: pipeline → K8s readiness → deploy pipeline
  ├── ProgressChannel → fan-out SSE events to browser clients
  ├── EnvironmentStore → in-memory state (replace with Redis for prod)
  └── KubernetesClient → pod status, kubeconfig secret, sleep/wake

AzDO Pipelines
  ├── CreateVCluster  → vcluster create --connect=false
  ├── DeployWorkload  → vcluster connect + kubectl/helm
  └── DeleteVCluster  → vcluster delete
```

## Quick start

### API

```bash
cd api
dotnet user-secrets set "AzDo:Pat" "your-pat"
dotnet user-secrets set "AzDo:OrgUrl" "https://dev.azure.com/your-org"
dotnet user-secrets set "AzDo:Project" "your-project"

# Set pipeline IDs in appsettings.json → Pipelines section
# See README-AZDO.md for how to find them

dotnet run
# API at http://localhost:5000
# Scalar UI at http://localhost:5000/scalar
```

### Frontend

```bash
cd frontend
npm install
npm run dev
# UI at http://localhost:5173
```

### AzDO setup

See [README-AZDO.md](./README-AZDO.md) for pipeline YAML and variable setup.

## What's not here yet

- **OpenCost integration** — poll OpenCost API per namespace for cost tracking and kill on threshold
- **Velero snapshots** — snapshot namespace before delete, restore on demand  
- **TTL worker** — background `IHostedService` that checks `ExpiresAt` and triggers delete pipeline
- **Persistent store** — swap `EnvironmentStore` for Redis or SQL so state survives pod restarts
- **Auth** — no auth on the API currently; add Azure AD / Entra before exposing beyond localhost
