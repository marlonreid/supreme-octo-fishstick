using System.Text;
using EphemeralConsole.Ui;
using EphemeralConsole.Views;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Spectre.Console;

Console.OutputEncoding = Encoding.UTF8;

var builder = Host.CreateApplicationBuilder(args);

// The default console logger would scribble over the full-screen UI.
builder.Logging.ClearProviders();

builder.Services.AddSingleton(new AppInfo(
    Context: "ephemeral-local",
    Api: "http://localhost:5080",
    Version: "v0.1.0"));

// Registration order matters: the first IResourceView is the one you land on.
// To add a screen, implement IResourceView and add one line here.
builder.Services.AddSingleton<IResourceView, EnvironmentsView>();
builder.Services.AddSingleton<IResourceView, WorkloadsView>();

builder.Services.AddSingleton<ViewRegistry>();
builder.Services.AddSingleton<K9sApp>();

using var host = builder.Build();
var app = host.Services.GetRequiredService<K9sApp>();

// Alternate screen = full-screen like k9s; your terminal is restored on exit.
AnsiConsole.AlternateScreen(app.Run);
