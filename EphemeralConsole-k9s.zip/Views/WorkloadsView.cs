namespace EphemeralConsole.Views;

public sealed class WorkloadsView : IResourceView
{
    private static readonly (string Env, string Name, string Ready, string Status, int Restarts, TimeSpan Age)[] Seed =
    [
        ("pr-1423-checkout", "checkout-api", "2/2", "Running", 0, TimeSpan.FromHours(5.2)),
        ("pr-1423-checkout", "postgres", "1/1", "Running", 0, TimeSpan.FromHours(5.2)),
        ("pr-1431-ledger", "ledger-api", "0/1", "ContainerCreating", 0, TimeSpan.FromMinutes(3)),
        ("demo-keycloak-sso", "keycloak", "1/1", "Running", 1, TimeSpan.FromDays(2.4)),
        ("pr-87-realm-sync", "realm-sync-job", "0/1", "CrashLoopBackOff", 14, TimeSpan.FromHours(20)),
        ("qa-regression", "tests-runner", "1/1", "Running", 0, TimeSpan.FromDays(6)),
        ("sandbox-marlon", "vcluster", "1/1", "Running", 0, TimeSpan.FromMinutes(42)),
    ];

    public IReadOnlyList<string> Names { get; } = ["workloads", "wl"];

    public string Title => "workloads";

    public IReadOnlyList<ColumnDef> Columns { get; } =
    [
        new("ENV", Sorted: true),
        new("NAME"),
        new("READY"),
        new("STATUS"),
        new("RESTARTS", RightAligned: true),
        new("AGE", RightAligned: true),
    ];

    public async Task<IReadOnlyList<ResourceRow>> LoadAsync(CancellationToken ct)
    {
        await Task.Delay(150, ct);

        return Seed
            .OrderBy(s => s.Env).ThenBy(s => s.Name)
            .Select(s => new ResourceRow(s.Env,
            [
                new ResourceCell(s.Env),
                new ResourceCell(s.Name),
                new ResourceCell(s.Ready),
                new ResourceCell(s.Status, ViewFormat.StatusColor(s.Status)),
                new ResourceCell(s.Restarts.ToString(), s.Restarts > 0 ? "yellow" : null),
                new ResourceCell(ViewFormat.Age(s.Age)),
            ]))
            .ToList();
    }
}
