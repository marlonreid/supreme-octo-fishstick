namespace EphemeralConsole.Views;

public sealed class EnvironmentsView : IResourceView
{
    // Fake data. Replace LoadAsync's body with a call to your EnvironmentService
    // and map each EphemeralCommon.Environment to a ResourceRow.
    private static readonly (string Team, string Name, string Status, TimeSpan Age)[] Seed =
    [
        ("team-payments", "pr-1423-checkout", "Running", TimeSpan.FromHours(5.2)),
        ("team-payments", "pr-1431-ledger", "Provisioning", TimeSpan.FromMinutes(3)),
        ("team-identity", "demo-keycloak-sso", "Running", TimeSpan.FromDays(2.4)),
        ("team-identity", "pr-87-realm-sync", "Failed", TimeSpan.FromHours(20)),
        ("team-qa", "qa-regression", "Running", TimeSpan.FromDays(6)),
        ("team-qa", "qa-perf", "Terminating", TimeSpan.FromDays(9)),
        ("default", "sandbox-marlon", "Running", TimeSpan.FromMinutes(42)),
    ];

    public IReadOnlyList<string> Names { get; } = ["environments", "envs", "env"];

    public string Title => "environments";

    public IReadOnlyList<ColumnDef> Columns { get; } =
    [
        new("TEAM", Sorted: true),
        new("NAME"),
        new("STATUS"),
        new("AGE", RightAligned: true),
    ];

    public async Task<IReadOnlyList<ResourceRow>> LoadAsync(CancellationToken ct)
    {
        await Task.Delay(150, ct); // pretend to be an HTTP call

        return Seed
            .OrderBy(s => s.Team).ThenBy(s => s.Name)
            .Select(s => new ResourceRow(s.Team,
            [
                new ResourceCell(s.Team),
                new ResourceCell(s.Name),
                new ResourceCell(s.Status, ViewFormat.StatusColor(s.Status)),
                new ResourceCell(ViewFormat.Age(s.Age)),
            ]))
            .ToList();
    }
}
