namespace EphemeralConsole.Views;

/// <summary>A column header. The UI decides widths; the view only says what the column is.</summary>
public sealed record ColumnDef(string Header, bool RightAligned = false, bool Sorted = false);

/// <summary>One cell of text. Color is a Spectre colour name ("green", "red", "orange1"), or null for default.</summary>
public sealed record ResourceCell(string Text, string? Color = null);

/// <summary>
/// One row. Scope is the optional grouping used for the &lt;0&gt; all / &lt;1&gt; ... shortcuts
/// (a team, an environment, a namespace). Null means this view isn't scoped.
/// </summary>
public sealed record ResourceRow(string? Scope, IReadOnlyList<ResourceCell> Cells);

/// <summary>A key hint shown in the header, e.g. new("&lt;ctrl-d&gt;", "Delete").</summary>
public sealed record KeyHint(string Key, string Description);

/// <summary>
/// Everything the UI needs to show a screen. Implement this once per thing you want to list
/// (environments, workloads, ...). Nothing in here knows about Spectre or the console.
/// </summary>
public interface IResourceView
{
    /// <summary>Command names for ":name". First is canonical, the rest are aliases, e.g. ["environments", "envs"].</summary>
    IReadOnlyList<string> Names { get; }

    /// <summary>Shown in the panel title and the bottom crumb, e.g. "environments".</summary>
    string Title { get; }

    IReadOnlyList<ColumnDef> Columns { get; }

    /// <summary>Return rows already sorted the way you want them shown.</summary>
    Task<IReadOnlyList<ResourceRow>> LoadAsync(CancellationToken ct);

    /// <summary>View-specific key hints. Shown ahead of the built-in ones.</summary>
    IReadOnlyList<KeyHint> Hints => [];
}

/// <summary>Maps command names (":envs") to views.</summary>
public sealed class ViewRegistry(IEnumerable<IResourceView> views)
{
    // DI hands us every registered IResourceView, in registration order.
    private readonly IReadOnlyList<IResourceView> _views = views.ToList();

    /// <summary>Canonical name of each view, for help/error text.</summary>
    public IEnumerable<string> Names => _views.Select(v => v.Names[0]);

    /// <summary>The first registered view is where the app starts.</summary>
    public IResourceView Default => _views[0];

    public bool TryGet(string name, out IResourceView view)
    {
        view = _views.FirstOrDefault(v => v.Names.Contains(name, StringComparer.OrdinalIgnoreCase))!;
        return view is not null;
    }
}

/// <summary>Small formatting helpers views can share.</summary>
public static class ViewFormat
{
    public static string Age(TimeSpan s)
    {
        if (s.TotalDays >= 1) return $"{(int)s.TotalDays}d{s.Hours}h";
        if (s.TotalHours >= 1) return $"{(int)s.TotalHours}h{s.Minutes}m";
        if (s.TotalMinutes >= 1) return $"{(int)s.TotalMinutes}m";
        return $"{(int)s.TotalSeconds}s";
    }

    public static string StatusColor(string status) => status switch
    {
        "Running" => "green",
        "Provisioning" or "Pending" or "ContainerCreating" => "yellow",
        "Failed" or "Error" or "CrashLoopBackOff" => "red",
        "Terminating" => "orange1",
        _ => "grey",
    };
}
