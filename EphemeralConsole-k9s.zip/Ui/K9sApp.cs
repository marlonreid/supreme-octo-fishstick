using EphemeralConsole.Views;
using Spectre.Console;
using Spectre.Console.Rendering;

namespace EphemeralConsole.Ui;

public sealed record AppInfo(string Context, string Api, string Version);

internal enum Mode { Normal, Command, Filter }

/// <summary>
/// The k9s-style shell: header, table panel, command/filter prompt, crumb.
/// It only talks to <see cref="IResourceView"/>, so adding a screen never touches this file.
/// </summary>
public sealed class K9sApp
{
    private const int HeaderHeight = 7;
    private const int MaxScopes = 5;
    private static readonly TimeSpan RefreshInterval = TimeSpan.FromSeconds(2);

    private static readonly KeyHint[] BaseHints =
    [
        new("<j/k>", "Move"),
        new("<g/G>", "Top/Bottom"),
        new("</>", "Filter"),
        new("<:>", "Command"),
        new("<esc>", "Clear filter"),
        new("<q>", "Quit"),
    ];

    private readonly ViewRegistry _views;
    private readonly AppInfo _info;
    private readonly CancellationTokenSource _cts = new();

    private volatile IResourceView _view;
    private volatile IReadOnlyList<ResourceRow> _rows = [];
    private volatile bool _quit, _dirty = true;

    private Mode _mode = Mode.Normal;
    private string _buffer = "", _filter = "", _scope = "all", _flash = "";
    private DateTime _flashUntil;
    private int _selected, _offset;

    public K9sApp(ViewRegistry views, AppInfo info)
    {
        _views = views;
        _info = info;
        _view = views.Default;
    }

    // ───────────── lifecycle ─────────────

    public void Run()
    {
        Splash();
        AnsiConsole.Status().Spinner(Spinner.Known.Dots).Start($"Loading {_view.Title}…", _ =>
        {
            try { _rows = _view.LoadAsync(_cts.Token).GetAwaiter().GetResult(); }
            catch (Exception ex) { Flash($"load failed: {ex.Message}"); }
            Thread.Sleep(500); // let the splash breathe
        });

        _ = Task.Run(async () =>
        {
            using var timer = new PeriodicTimer(RefreshInterval);
            try { while (await timer.WaitForNextTickAsync(_cts.Token)) LoadNow(); }
            catch (OperationCanceledException) { }
        });

        AnsiConsole.Live(Render())
            .AutoClear(true)
            .Overflow(VerticalOverflow.Crop)
            .Cropping(VerticalOverflowCropping.Bottom)
            .Start(ctx =>
            {
                var lastSize = (Console.WindowWidth, Console.WindowHeight);
                while (!_quit)
                {
                    while (Console.KeyAvailable) HandleKey(Console.ReadKey(true));

                    var size = (Console.WindowWidth, Console.WindowHeight);
                    if (size != lastSize) { lastSize = size; _dirty = true; }

                    if (_flash.Length > 0 && DateTime.UtcNow > _flashUntil) { _flash = ""; _dirty = true; }

                    if (_dirty)
                    {
                        _dirty = false;
                        ctx.UpdateTarget(Render());
                        ctx.Refresh();
                    }
                    Thread.Sleep(25);
                }
            });

        _cts.Cancel();
    }

    private static void Splash()
    {
        AnsiConsole.Clear();
        for (var i = 0; i < Math.Max(0, Console.WindowHeight / 2 - 5); i++) AnsiConsole.WriteLine();
        AnsiConsole.Write(new FigletText("Ephemeral").Centered().Color(Color.Orange1));
        AnsiConsole.Write(Align.Center(new Markup("[grey]environments console[/]")));
        AnsiConsole.WriteLine();
    }

    // ───────────── data ─────────────

    private void LoadNow()
    {
        var view = _view;
        _ = Task.Run(async () =>
        {
            try
            {
                var rows = await view.LoadAsync(_cts.Token);
                if (ReferenceEquals(view, _view)) { _rows = rows; _dirty = true; } // ignore stale loads
            }
            catch (OperationCanceledException) { }
            catch (Exception ex) { Flash($"load failed: {ex.Message}"); }
        });
    }

    private void SwitchView(IResourceView view)
    {
        _view = view;
        _rows = [];
        _scope = "all";
        _filter = "";
        ResetSelection();
        LoadNow();
    }

    private List<ResourceRow> Visible() => _rows
        .Where(r => _scope == "all" || r.Scope == _scope)
        .Where(r => _filter.Length == 0 ||
                    r.Cells.Any(c => c.Text.Contains(_filter, StringComparison.OrdinalIgnoreCase)))
        .ToList();

    private List<string> Scopes() =>
        ["all", .. _rows.Select(r => r.Scope).OfType<string>().Distinct().OrderBy(s => s).Take(MaxScopes)];

    private static string Text(ResourceRow r, int col) => col < r.Cells.Count ? r.Cells[col].Text : "";

    private static string ColorOf(ResourceRow r, int col) =>
        col < r.Cells.Count ? r.Cells[col].Color ?? "white" : "white";

    // ───────────── input ─────────────

    private void HandleKey(ConsoleKeyInfo k)
    {
        _dirty = true;
        if (k.Key == ConsoleKey.C && k.Modifiers.HasFlag(ConsoleModifiers.Control)) { _quit = true; return; }
        if (_mode == Mode.Normal) HandleNormal(k); else HandlePrompt(k);
    }

    private void HandleNormal(ConsoleKeyInfo k)
    {
        var count = Visible().Count;
        var page = PageSize();

        switch (k.KeyChar)
        {
            case '/': _mode = Mode.Filter; _buffer = _filter; return;
            case ':': _mode = Mode.Command; _buffer = ""; return;
            case 'q' or 'Q': _quit = true; return;
            case 'j': _selected++; return;
            case 'k': _selected--; return;
            case 'g': _selected = 0; return;
            case 'G': _selected = count - 1; return;
            case >= '0' and <= '9':
                var scopes = Scopes();
                var idx = k.KeyChar - '0';
                if (idx < scopes.Count) { _scope = scopes[idx]; ResetSelection(); }
                return;
        }

        switch (k.Key)
        {
            case ConsoleKey.UpArrow: _selected--; break;
            case ConsoleKey.DownArrow: _selected++; break;
            case ConsoleKey.PageUp: _selected -= page; break;
            case ConsoleKey.PageDown: _selected += page; break;
            case ConsoleKey.Home: _selected = 0; break;
            case ConsoleKey.End: _selected = count - 1; break;
            case ConsoleKey.Escape: _filter = ""; ResetSelection(); break;
        }
    }

    private void HandlePrompt(ConsoleKeyInfo k)
    {
        switch (k.Key)
        {
            case ConsoleKey.Escape:
                if (_mode == Mode.Filter) _filter = "";
                _buffer = ""; _mode = Mode.Normal;
                return;
            case ConsoleKey.Enter:
                var mode = _mode;
                var text = _buffer.Trim();
                _buffer = ""; _mode = Mode.Normal;
                if (mode == Mode.Command) Execute(text);
                return;
            case ConsoleKey.Backspace:
                if (_buffer.Length > 0) _buffer = _buffer[..^1];
                break;
            default:
                if (!char.IsControl(k.KeyChar)) _buffer += k.KeyChar;
                break;
        }

        if (_mode == Mode.Filter) { _filter = _buffer; ResetSelection(); } // live filter
    }

    private void Execute(string cmd)
    {
        var parts = cmd.Split(' ', 2, StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
        if (parts.Length == 0) return;
        var name = parts[0].ToLowerInvariant();

        if (name is "q" or "quit" or "exit") { _quit = true; return; }
        if (name == "all") { _scope = "all"; ResetSelection(); return; }
        if (name == "ns" && parts.Length == 2) { _scope = parts[1]; ResetSelection(); return; }
        if (_views.TryGet(name, out var view)) { SwitchView(view); return; }

        Flash($"unknown command: {cmd}  (views: {string.Join(", ", _views.Names)})");
    }

    private void Flash(string message)
    {
        _flash = message;
        _flashUntil = DateTime.UtcNow.AddSeconds(4);
        _dirty = true;
    }

    private void ResetSelection() { _selected = 0; _offset = 0; }

    // ───────────── layout maths ─────────────

    private int PromptHeight() => _mode != Mode.Normal ? 3 : 0;

    /// <summary>Height of the table panel including its border: whatever the header/prompt/crumb leave.</summary>
    private int BodyHeight() => Math.Max(4, Console.WindowHeight - HeaderHeight - PromptHeight() - 1);

    /// <summary>Data rows that fit: panel minus 2 border lines minus the column header line.</summary>
    private int PageSize() => Math.Max(1, BodyHeight() - 3);

    // ───────────── rendering ─────────────

    private IRenderable Render()
    {
        var rows = Visible();
        _selected = Math.Clamp(_selected, 0, Math.Max(0, rows.Count - 1));

        var page = PageSize();
        if (_selected < _offset) _offset = _selected;
        if (_selected >= _offset + page) _offset = _selected - page + 1;
        _offset = Math.Max(0, Math.Min(_offset, Math.Max(0, rows.Count - page)));

        var layout = new Layout("root").SplitRows(
            new Layout("header").Size(HeaderHeight),
            new Layout("body"),
            new Layout("prompt").Size(3),
            new Layout("crumb").Size(1));

        layout["header"].Update(Header(rows.Count));
        layout["body"].Update(Body(rows, page));
        layout["prompt"].Update(PromptBox());
        layout["prompt"].IsVisible = _mode != Mode.Normal;
        layout["crumb"].Update(Crumb());
        return layout;
    }

    private IRenderable Header(int count)
    {
        static string Kv(string label, string value) =>
            $"[bold orange1]{label,-9}[/] [white]{Markup.Escape(value)}[/]";

        static string Hint(KeyHint h) =>
            $"[dodgerblue1]{Markup.Escape(h.Key),-8}[/] [white]{Markup.Escape(h.Description)}[/]";

        var info = new Markup(string.Join('\n',
            Kv("Context:", _info.Context),
            Kv("API:", _info.Api),
            Kv("User:", System.Environment.UserName), // System. prefix: EphemeralConsole.Environment is a namespace in your project
            Kv("Rev:", _info.Version),
            Kv("Rows:", count.ToString()),
            Kv("Refresh:", $"{RefreshInterval.TotalSeconds:0}s")));

        var scopes = new Markup(string.Join('\n', Scopes().Select((s, i) =>
            $"[fuchsia]<{i}>[/] " + (s == _scope
                ? $"[bold white]{Markup.Escape(s)}[/]"
                : $"[white]{Markup.Escape(s)}[/]"))));

        var hints = new Markup(string.Join('\n', _view.Hints.Concat(BaseHints).Take(6).Select(Hint)));

        var logo = Align.Right(new FigletText("EPH").Color(Color.Orange1));

        var grid = new Grid()
            .AddColumn(new GridColumn().Width(36).NoWrap())
            .AddColumn(new GridColumn().Width(24).NoWrap())
            .AddColumn(new GridColumn().Width(26).NoWrap())
            .AddColumn(new GridColumn());
        grid.AddRow(info, scopes, hints, logo);

        return new Padder(grid, new Padding(1, 0, 1, 0));
    }

    private IRenderable Body(List<ResourceRow> rows, int page)
    {
        var cols = _view.Columns;
        var inner = Math.Max(30, Console.WindowWidth - 4); // 2 borders + 2 padding
        var widths = ColumnWidths(rows, inner);

        var lines = new List<IRenderable>
        {
            Line(string.Concat(cols.Select((c, i) =>
                $"[bold white]{Markup.Escape(Fit(HeaderText(c), widths[i], c.RightAligned))}[/]")))
        };

        for (var i = _offset; i < Math.Min(rows.Count, _offset + page); i++)
        {
            var row = rows[i];

            if (i == _selected)
            {
                // Pad to the full inner width so the highlight bar spans the whole row.
                var plain = string.Concat(cols.Select((c, ci) => Fit(Text(row, ci), widths[ci], c.RightAligned)));
                lines.Add(Line($"[black on aqua]{Markup.Escape(plain.PadRight(inner))}[/]"));
            }
            else
            {
                lines.Add(Line(string.Concat(cols.Select((c, ci) =>
                    $"[{ColorOf(row, ci)}]{Markup.Escape(Fit(Text(row, ci), widths[ci], c.RightAligned))}[/]"))));
            }
        }

        var scoped = _rows.Any(r => r.Scope is not null);
        var title = Markup.Escape(_view.Title);
        var head = scoped
            ? $"[aqua]{title}([bold white]{Markup.Escape(_scope)}[/])[/]"
            : $"[aqua]{title}[/]";
        var filterTag = _filter.Length > 0 ? $"[aqua]</{Markup.Escape(_filter)}>[/]" : "";

        return new Panel(new Rows(lines))
        {
            Header = new PanelHeader($"{head}{filterTag}[aqua][[{rows.Count}]][/]", Justify.Center),
            Border = BoxBorder.Rounded,
            BorderStyle = new Style(Color.Aqua),
            Padding = new Padding(1, 0, 1, 0),
            Expand = true,
            Height = BodyHeight(), // explicit, so the panel fills its region instead of shrinking to its content
        };

        static IRenderable Line(string markup) => new Markup(markup) { Overflow = Overflow.Crop };
    }

    private IRenderable PromptBox()
    {
        var sigil = _mode == Mode.Command ? "[orange1]:[/]" : "[orange1]/[/]";
        return new Panel(new Markup($"{sigil}[white]{Markup.Escape(_buffer)}[/][grey]▌[/]"))
        {
            Border = BoxBorder.Rounded,
            BorderStyle = new Style(Color.DodgerBlue1),
            Expand = true,
        };
    }

    private IRenderable Crumb()
    {
        var text = $"[black on yellow] <{Markup.Escape(_view.Title)}> [/]";
        if (_filter.Length > 0) text += $"[black on aqua] </{Markup.Escape(_filter)}> [/]";
        if (_flash.Length > 0) text += $" [bold red]{Markup.Escape(_flash)}[/]";
        return new Markup(text) { Overflow = Overflow.Crop };
    }

    // ───────────── text fitting ─────────────

    private static string HeaderText(ColumnDef c) => c.Sorted ? c.Header + "↑" : c.Header;

    private int[] ColumnWidths(List<ResourceRow> rows, int inner)
    {
        var cols = _view.Columns;
        var w = new int[cols.Count];

        for (var c = 0; c < w.Length; c++)
        {
            var col = c;
            w[c] = Math.Max(HeaderText(cols[c]).Length,
                       rows.Select(r => Text(r, col).Length).DefaultIfEmpty(0).Max()) + 3;
        }

        if (w.Length > 1) w[^1] = Math.Max(w[^1], inner - w[..^1].Sum()); // last column soaks up the slack
        return w;
    }

    private static string Fit(string s, int width, bool right)
    {
        width = Math.Max(4, width);
        var max = width - 2; // keep a 2-char gutter
        var t = s.Length > max ? s[..(max - 1)] + "…" : s;
        return right ? t.PadLeft(max) + "  " : t.PadRight(width);
    }
}
