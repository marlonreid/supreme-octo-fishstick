using System.Collections.Concurrent;
using VClusterApi.Models;

namespace VClusterApi.Services;

/// <summary>
/// In-memory environment state store.
/// Swap for Redis or SQL before running in production — state is lost on pod restart.
/// </summary>
public class EnvironmentStore
{
    private readonly ConcurrentDictionary<string, VClusterEnvironment> _store = new();

    public void Upsert(VClusterEnvironment env) => _store[env.Id] = env;

    public VClusterEnvironment? Get(string id) =>
        _store.TryGetValue(id, out var e) ? e : null;

    public IEnumerable<VClusterEnvironment> GetAll() =>
        _store.Values.OrderByDescending(e => e.CreatedAt);

    public VClusterEnvironment Update(string id, Func<VClusterEnvironment, VClusterEnvironment> mutate)
    {
        var updated = mutate(_store[id]);
        _store[id] = updated;
        return updated;
    }
}
