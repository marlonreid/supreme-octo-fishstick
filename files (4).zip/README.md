# api

.NET 10 Web API. Manages vCluster environments via AzDO pipeline triggers and KubernetesClient.

## Setup

```bash
# Set secrets locally (never commit the PAT)
dotnet user-secrets set "AzDo:OrgUrl" "https://dev.azure.com/your-org"
dotnet user-secrets set "AzDo:Project" "your-project"
dotnet user-secrets set "AzDo:Pat" "your-pat"

# Set pipeline IDs in appsettings.json → Pipelines section
# Find IDs in the pipeline URL: .../_build?definitionId=42

dotnet run
# API:    http://localhost:5000
# Scalar: http://localhost:5000/scalar
```

## AzDO pipeline YAML

See [../README-AZDO.md](../README-AZDO.md).

## PAT scope required

Pipelines: **Read & Execute**

Create at: `https://dev.azure.com/your-org/_usersSettings/tokens`
