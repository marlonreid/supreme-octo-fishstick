namespace VClusterApi.Models;

// ── Requests ──────────────────────────────────────────────────────────────────

public record CreateVClusterRequest(
    string Name,
    string? K8sVersion = null,
    int? TtlHours = null,
    decimal? CostThresholdGbp = null,
    Dictionary<string, string>? Labels = null
);

// ── Environment state ─────────────────────────────────────────────────────────

public enum EnvironmentStatus
{
    Queued,
    CreatingCluster,
    ClusterReady,
    DeployingWorkload,
    Ready,
    Sleeping,
    Failed,
    Deleting,
    Deleted
}

public record VClusterEnvironment(
    string Id,
    string Name,
    string Namespace,
    EnvironmentStatus Status,
    string? K8sVersion,
    int? TtlHours,
    decimal? CostThresholdGbp,
    DateTime CreatedAt,
    DateTime? ReadyAt,
    DateTime? ExpiresAt,
    string? CreatePipelineRunId,
    string? DeployPipelineRunId,
    string? ErrorMessage,
    Dictionary<string, string> Labels
);

public record VClusterSummary(
    string Id,
    string Name,
    string Namespace,
    EnvironmentStatus Status,
    DateTime CreatedAt,
    DateTime? ExpiresAt,
    decimal? CurrentCostGbp
);

public record VClusterDetail(
    string Id,
    string Name,
    string Namespace,
    EnvironmentStatus Status,
    string? K8sVersion,
    DateTime CreatedAt,
    DateTime? ReadyAt,
    DateTime? ExpiresAt,
    int? TtlHours,
    decimal? CostThresholdGbp,
    decimal? CurrentCostGbp,
    VClusterPodStatus[] Pods,
    string? KubeconfigSecretName,
    string? ErrorMessage
);

public record VClusterPodStatus(
    string Name,
    string Phase,
    bool Ready,
    int RestartCount,
    DateTime? StartedAt
);

public record VClusterKubeconfig(
    string VClusterName,
    string Namespace,
    string Kubeconfig
);

// ── SSE progress events ───────────────────────────────────────────────────────

public enum ProgressEventType
{
    Info,
    PipelineQueued,
    PipelineStarted,
    PipelineLog,
    PipelineComplete,
    PipelineFailed,
    ClusterReady,
    DeployStarted,
    EnvironmentReady,
    Error,
    StreamComplete
}

public record ProgressEvent(
    string EnvironmentId,
    ProgressEventType Type,
    string Message,
    DateTime Timestamp,
    string? Detail = null
);

// ── AzDO internals ────────────────────────────────────────────────────────────

public record AzdoPipelineRun(
    int RunId,
    string State,
    string? Result
);

public record AzdoLogLine(int LineNumber, string Text);

// ── API response envelope ─────────────────────────────────────────────────────

public record ApiResponse<T>(bool Success, T? Data, string? Error = null);
