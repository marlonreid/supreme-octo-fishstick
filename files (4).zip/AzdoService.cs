using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using VClusterApi.Models;

namespace VClusterApi.Services;

public interface IAzdoService
{
    Task<int> TriggerPipelineAsync(int pipelineId, Dictionary<string, string> parameters, CancellationToken ct = default);
    IAsyncEnumerable<AzdoLogLine> StreamRunLogsAsync(int runId, CancellationToken ct = default);
    Task<AzdoPipelineRun> GetRunAsync(int runId, CancellationToken ct = default);
}

/// <summary>
/// Wraps the Azure DevOps Pipelines REST API.
///
/// Config keys (appsettings.json or user-secrets):
///   AzDo:OrgUrl   = https://dev.azure.com/your-org
///   AzDo:Project  = your-project
///   AzDo:Pat      = personal-access-token  (scope: Pipelines Read & Execute)
///
/// See /api/README.md for production Managed Identity setup.
/// </summary>
public class AzdoService : IAzdoService
{
    private readonly HttpClient _http;
    private readonly ILogger<AzdoService> _logger;
    private readonly string _project;
    private static readonly TimeSpan PollInterval = TimeSpan.FromSeconds(3);

    public AzdoService(IConfiguration config, ILogger<AzdoService> logger)
    {
        _logger = logger;

        _project = config["AzDo:Project"]
            ?? throw new InvalidOperationException("AzDo:Project not configured");

        var orgUrl = config["AzDo:OrgUrl"]
            ?? throw new InvalidOperationException("AzDo:OrgUrl not configured");

        var pat = config["AzDo:Pat"]
            ?? throw new InvalidOperationException("AzDo:Pat not configured — use dotnet user-secrets");

        _http = new HttpClient { BaseAddress = new Uri($"{orgUrl.TrimEnd('/')}/") };

        var token = Convert.ToBase64String(Encoding.ASCII.GetBytes($":{pat}"));
        _http.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", token);
        _http.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
    }

    public async Task<int> TriggerPipelineAsync(
        int pipelineId,
        Dictionary<string, string> parameters,
        CancellationToken ct = default)
    {
        var url = $"{_project}/_apis/pipelines/{pipelineId}/runs?api-version=7.1";
        var body = JsonSerializer.Serialize(new { templateParameters = parameters });
        var content = new StringContent(body, Encoding.UTF8, "application/json");

        var response = await _http.PostAsync(url, content, ct);
        response.EnsureSuccessStatusCode();

        var doc = JsonNode.Parse(await response.Content.ReadAsStringAsync(ct))!;
        var runId = doc["id"]!.GetValue<int>();

        _logger.LogInformation("Triggered pipeline {PipelineId} → run {RunId}", pipelineId, runId);
        return runId;
    }

    public async Task<AzdoPipelineRun> GetRunAsync(int runId, CancellationToken ct = default)
    {
        var url = $"{_project}/_apis/build/builds/{runId}?api-version=7.1";
        var response = await _http.GetAsync(url, ct);
        response.EnsureSuccessStatusCode();

        var doc = JsonNode.Parse(await response.Content.ReadAsStringAsync(ct))!;

        return new AzdoPipelineRun(
            runId,
            doc["status"]?.GetValue<string>() ?? "unknown",
            doc["result"]?.GetValue<string>()
        );
    }

    public async IAsyncEnumerable<AzdoLogLine> StreamRunLogsAsync(
        int runId,
        [System.Runtime.CompilerServices.EnumeratorCancellation] CancellationToken ct = default)
    {
        var emitted = new HashSet<string>();

        while (!ct.IsCancellationRequested)
        {
            var run = await GetRunAsync(runId, ct);

            var timelineUrl = $"{_project}/_apis/build/builds/{runId}/timeline?api-version=7.1";
            var timelineResp = await _http.GetAsync(timelineUrl, ct);

            if (timelineResp.IsSuccessStatusCode)
            {
                var doc = JsonNode.Parse(await timelineResp.Content.ReadAsStringAsync(ct));
                var records = doc?["records"]?.AsArray() ?? [];

                foreach (var record in records)
                {
                    var logId = record?["log"]?["id"]?.GetValue<int>();
                    var stepName = record?["name"]?.GetValue<string>() ?? "step";
                    if (logId is null) continue;

                    var logUrl = $"{_project}/_apis/build/builds/{runId}/logs/{logId}?api-version=7.1";
                    var logResp = await _http.GetAsync(logUrl, ct);
                    if (!logResp.IsSuccessStatusCode) continue;

                    var lines = (await logResp.Content.ReadAsStringAsync(ct))
                        .Split('\n', StringSplitOptions.RemoveEmptyEntries);

                    foreach (var (line, idx) in lines.Select((l, i) => (l, i)))
                    {
                        var key = $"{logId}:{idx}";
                        if (!emitted.Add(key)) continue;

                        var trimmed = line.Trim();
                        if (!string.IsNullOrEmpty(trimmed))
                            yield return new AzdoLogLine(idx, $"[{stepName}] {trimmed}");
                    }
                }
            }

            if (run.State is "completed" or "canceling")
                yield break;

            await Task.Delay(PollInterval, ct);
        }
    }
}
