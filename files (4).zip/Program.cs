using k8s;
using VClusterApi.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();
builder.Services.AddOpenApi();

builder.Services.AddCors(o => o.AddDefaultPolicy(p =>
    p.WithOrigins("http://localhost:5173")
     .AllowAnyHeader()
     .AllowAnyMethod()));

builder.Services.AddSingleton<IKubernetes>(_ =>
{
    var cfg = KubernetesClientConfiguration.IsInCluster()
        ? KubernetesClientConfiguration.InClusterConfig()
        : KubernetesClientConfiguration.BuildConfigFromConfigFile();
    return new Kubernetes(cfg);
});

builder.Services.AddSingleton<EnvironmentStore>();
builder.Services.AddSingleton<ProgressChannel>();
builder.Services.AddSingleton<IAzdoService, AzdoService>();
builder.Services.AddScoped<IVClusterService, VClusterService>();

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.MapOpenApi();
    app.MapScalarApiReference();
}

app.UseCors();
app.UseAuthorization();
app.MapControllers();

app.Run();
