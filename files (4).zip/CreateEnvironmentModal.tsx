import { useState } from 'react'
import type { CreateVClusterRequest, VClusterSummary } from '../types/api'
import { api } from '../services/api'

interface Props {
  onCreated: (env: VClusterSummary) => void
  onClose: () => void
}

export function CreateEnvironmentModal({ onCreated, onClose }: Props) {
  const [name, setName] = useState('')
  const [k8sVersion, setK8sVersion] = useState('')
  const [ttlHours, setTtlHours] = useState('')
  const [costLimit, setCostLimit] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const submit = async () => {
    if (!name.trim()) return setError('Name is required')
    setLoading(true)
    setError(null)
    try {
      const payload: CreateVClusterRequest = {
        name: name.trim(),
        ...(k8sVersion && { k8sVersion }),
        ...(ttlHours && { ttlHours: parseInt(ttlHours) }),
        ...(costLimit && { costThresholdGbp: parseFloat(costLimit) })
      }
      const env = await api.createEnvironment(payload)
      onCreated(env)
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to create')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div style={overlay}>
      <div style={modal}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
          <h2 style={{ margin: 0, fontSize: 18, color: '#e2e8f0' }}>New Environment</h2>
          <button onClick={onClose} style={closeBtn}>✕</button>
        </div>

        <Field label="Name *">
          <input style={inp} value={name} onChange={e => setName(e.target.value)} placeholder="my-feature" />
        </Field>

        <Field label="K8s version">
          <input style={inp} value={k8sVersion} onChange={e => setK8sVersion(e.target.value)} placeholder="leave blank for default" />
        </Field>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
          <Field label="TTL (hours)">
            <input style={inp} type="number" value={ttlHours} onChange={e => setTtlHours(e.target.value)} placeholder="e.g. 8" />
          </Field>
          <Field label="Cost limit (£)">
            <input style={inp} type="number" step="0.01" value={costLimit} onChange={e => setCostLimit(e.target.value)} placeholder="e.g. 5.00" />
          </Field>
        </div>

        {error && <div style={{ color: '#fc8181', fontSize: 13, marginTop: 8 }}>{error}</div>}

        <div style={{ display: 'flex', gap: 12, marginTop: 24 }}>
          <button style={primaryBtn} onClick={submit} disabled={loading}>
            {loading ? 'Creating...' : 'Create'}
          </button>
          <button style={secondaryBtn} onClick={onClose} disabled={loading}>Cancel</button>
        </div>
      </div>
    </div>
  )
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div style={{ marginBottom: 16 }}>
      <label style={{ display: 'block', fontSize: 12, color: '#718096', marginBottom: 6, fontWeight: 600 }}>
        {label}
      </label>
      {children}
    </div>
  )
}

const overlay: React.CSSProperties = {
  position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.7)',
  display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 100
}
const modal: React.CSSProperties = {
  background: '#161b22', border: '1px solid #30363d',
  borderRadius: 12, padding: 32, width: 480, maxWidth: '90vw'
}
const inp: React.CSSProperties = {
  width: '100%', background: '#0d1117', border: '1px solid #30363d',
  borderRadius: 6, padding: '8px 12px', color: '#e2e8f0', fontSize: 14, outline: 'none'
}
const primaryBtn: React.CSSProperties = {
  background: '#238636', border: 'none', borderRadius: 6,
  padding: '8px 20px', color: '#fff', fontSize: 14, cursor: 'pointer', fontWeight: 600
}
const secondaryBtn: React.CSSProperties = {
  background: 'transparent', border: '1px solid #30363d',
  borderRadius: 6, padding: '8px 20px', color: '#8b949e', fontSize: 14, cursor: 'pointer'
}
const closeBtn: React.CSSProperties = {
  background: 'none', border: 'none', color: '#8b949e', fontSize: 18, cursor: 'pointer', padding: 4
}
