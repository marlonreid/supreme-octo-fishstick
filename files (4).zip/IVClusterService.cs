using VClusterApi.Models;

namespace VClusterApi.Services;

public interface IVClusterService
{
    Task<VClusterEnvironment> CreateAsync(CreateVClusterRequest request, CancellationToken ct = default);
    Task DeleteAsync(string environmentId, CancellationToken ct = default);
    Task<IEnumerable<VClusterSummary>> ListAsync(CancellationToken ct = default);
    Task<VClusterDetail?> GetDetailAsync(string environmentId, CancellationToken ct = default);
    Task<VClusterKubeconfig> GetKubeconfigAsync(string environmentId, CancellationToken ct = default);
    Task SleepAsync(string environmentId, CancellationToken ct = default);
    Task WakeAsync(string environmentId, CancellationToken ct = default);
}
