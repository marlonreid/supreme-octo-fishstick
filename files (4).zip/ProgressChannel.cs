using System.Collections.Concurrent;
using System.Threading.Channels;
using VClusterApi.Models;

namespace VClusterApi.Services;

/// <summary>
/// Fan-out SSE broadcast channel — multiple browser tabs can subscribe
/// to the same environment simultaneously, each getting its own reader.
/// </summary>
public class ProgressChannel
{
    private readonly ConcurrentDictionary<string, ConcurrentBag<Channel<ProgressEvent>>> _subs = new();

    public (ChannelReader<ProgressEvent> Reader, IDisposable Unsubscribe) Subscribe(string environmentId)
    {
        var ch = Channel.CreateUnbounded<ProgressEvent>(new UnboundedChannelOptions
        {
            SingleReader = true,
            SingleWriter = false
        });

        _subs.GetOrAdd(environmentId, _ => new ConcurrentBag<Channel<ProgressEvent>>()).Add(ch);

        return (ch.Reader, new Disposer(() => ch.Writer.TryComplete()));
    }

    public void Publish(ProgressEvent evt)
    {
        if (!_subs.TryGetValue(evt.EnvironmentId, out var bag)) return;
        foreach (var ch in bag) ch.Writer.TryWrite(evt);
    }

    public void Complete(string environmentId)
    {
        if (!_subs.TryGetValue(environmentId, out var bag)) return;
        foreach (var ch in bag) ch.Writer.TryComplete();
        _subs.TryRemove(environmentId, out _);
    }

    private sealed class Disposer(Action onDispose) : IDisposable
    {
        public void Dispose() => onDispose();
    }
}
