import { useState } from 'react'
import type { EnvironmentStatus, VClusterSummary } from '../types/api'
import { api } from '../services/api'
import { StatusBadge } from './StatusBadge'
import { ProgressLog } from './ProgressLog'
import { useProgress } from '../hooks/useProgress'

const ACTIVE: EnvironmentStatus[] = ['Queued', 'CreatingCluster', 'ClusterReady', 'DeployingWorkload', 'Deleting']

interface Props {
  env: VClusterSummary
  onRefresh: () => void
}

export function EnvironmentCard({ env, onRefresh }: Props) {
  const isActive = ACTIVE.includes(env.status)
  const [showLog, setShowLog] = useState(isActive)
  const [copied, setCopied] = useState(false)

  const { events, complete } = useProgress(isActive ? env.id : null)

  const handleDelete = async () => {
    if (!confirm(`Delete "${env.name}"?`)) return
    await api.deleteEnvironment(env.id)
    onRefresh()
  }

  const handleSleep = async () => { await api.sleepEnvironment(env.id); onRefresh() }
  const handleWake = async () => { await api.wakeEnvironment(env.id); onRefresh() }

  const handleCopyKubeconfig = async () => {
    const kc = await api.getKubeconfig(env.id)
    await navigator.clipboard.writeText(kc)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const expiresIn = env.expiresAt
    ? Math.max(0, Math.round((new Date(env.expiresAt).getTime() - Date.now()) / 3_600_000))
    : null

  const hasLog = isActive || events.length > 0

  return (
    <div style={card}>
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 12 }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 4 }}>
            <span style={{ fontWeight: 700, color: '#e2e8f0', fontSize: 15 }}>{env.name}</span>
            <StatusBadge status={env.status} />
          </div>
          <div style={{ fontSize: 12, color: '#4a5568' }}>
            ns: {env.namespace}
            {expiresIn !== null && (
              <span style={{ marginLeft: 12, color: expiresIn < 2 ? '#fc8181' : '#718096' }}>
                ⏱ {expiresIn}h remaining
              </span>
            )}
            {env.currentCostGbp != null && (
              <span style={{ marginLeft: 12, color: '#f6ad55' }}>£{env.currentCostGbp.toFixed(2)}</span>
            )}
          </div>
        </div>

        <div style={{ display: 'flex', gap: 8, flexShrink: 0 }}>
          {env.status === 'Ready' && <>
            <Btn onClick={handleCopyKubeconfig} label={copied ? '✓ Copied' : 'Kubeconfig'} />
            <Btn onClick={handleSleep} label="Sleep" />
          </>}
          {env.status === 'Sleeping' && <Btn onClick={handleWake} label="Wake" />}
          {hasLog && <Btn onClick={() => setShowLog(v => !v)} label={showLog ? 'Hide log' : 'Log'} />}
          {!['Deleted', 'Deleting'].includes(env.status) && (
            <Btn onClick={handleDelete} label="Delete" danger />
          )}
        </div>
      </div>

      {showLog && hasLog && (
        <div style={{ marginTop: 14 }}>
          <ProgressLog events={events} complete={complete} />
        </div>
      )}
    </div>
  )
}

function Btn({ onClick, label, danger = false }: { onClick: () => void; label: string; danger?: boolean }) {
  return (
    <button onClick={onClick} style={{
      background: danger ? 'rgba(248,81,73,0.1)' : 'rgba(255,255,255,0.05)',
      border: `1px solid ${danger ? 'rgba(248,81,73,0.4)' : '#30363d'}`,
      borderRadius: 6, padding: '4px 12px',
      color: danger ? '#f85149' : '#8b949e',
      fontSize: 12, cursor: 'pointer'
    }}>
      {label}
    </button>
  )
}

const card: React.CSSProperties = {
  background: '#161b22', border: '1px solid #21262d',
  borderRadius: 10, padding: '16px 20px', marginBottom: 12
}
