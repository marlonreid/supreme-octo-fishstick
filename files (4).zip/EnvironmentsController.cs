using System.Text;
using System.Text.Json;
using Microsoft.AspNetCore.Mvc;
using VClusterApi.Models;
using VClusterApi.Services;

namespace VClusterApi.Controllers;

[ApiController]
[Route("api/environments")]
[Produces("application/json")]
public class EnvironmentsController(
    IVClusterService vcluster,
    ProgressChannel progress) : ControllerBase
{
    // GET /api/environments
    [HttpGet]
    public async Task<IActionResult> List(CancellationToken ct)
    {
        var list = await vcluster.ListAsync(ct);
        return Ok(new ApiResponse<IEnumerable<VClusterSummary>>(true, list));
    }

    // GET /api/environments/{id}
    [HttpGet("{id}")]
    public async Task<IActionResult> Get(string id, CancellationToken ct)
    {
        var detail = await vcluster.GetDetailAsync(id, ct);
        return detail is null
            ? NotFound(new ApiResponse<VClusterDetail>(false, null, "Not found"))
            : Ok(new ApiResponse<VClusterDetail>(true, detail));
    }

    // POST /api/environments
    [HttpPost]
    public async Task<IActionResult> Create([FromBody] CreateVClusterRequest request, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(request.Name))
            return BadRequest(new ApiResponse<VClusterEnvironment>(false, null, "Name is required"));

        var env = await vcluster.CreateAsync(request, ct);
        return AcceptedAtAction(nameof(Get), new { id = env.Id },
            new ApiResponse<VClusterEnvironment>(true, env));
    }

    // DELETE /api/environments/{id}
    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(string id, CancellationToken ct)
    {
        try { await vcluster.DeleteAsync(id, ct); return Accepted(); }
        catch (KeyNotFoundException) { return NotFound(); }
    }

    // GET /api/environments/{id}/kubeconfig
    [HttpGet("{id}/kubeconfig")]
    public async Task<IActionResult> GetKubeconfig(string id, CancellationToken ct)
    {
        try
        {
            var kc = await vcluster.GetKubeconfigAsync(id, ct);
            return Ok(new ApiResponse<VClusterKubeconfig>(true, kc));
        }
        catch (InvalidOperationException ex)
        {
            return NotFound(new ApiResponse<VClusterKubeconfig>(false, null, ex.Message));
        }
    }

    // POST /api/environments/{id}/sleep
    [HttpPost("{id}/sleep")]
    public async Task<IActionResult> Sleep(string id, CancellationToken ct)
    {
        await vcluster.SleepAsync(id, ct);
        return NoContent();
    }

    // POST /api/environments/{id}/wake
    [HttpPost("{id}/wake")]
    public async Task<IActionResult> Wake(string id, CancellationToken ct)
    {
        await vcluster.WakeAsync(id, ct);
        return NoContent();
    }

    // GET /api/environments/{id}/progress
    // SSE stream — closes when environment reaches a terminal state
    [HttpGet("{id}/progress")]
    public async Task Progress(string id, CancellationToken ct)
    {
        Response.Headers.Append("Content-Type", "text/event-stream");
        Response.Headers.Append("Cache-Control", "no-cache");
        Response.Headers.Append("X-Accel-Buffering", "no");

        var (reader, unsubscribe) = progress.Subscribe(id);

        try
        {
            var jsonOptions = new JsonSerializerOptions { PropertyNamingPolicy = JsonNamingPolicy.CamelCase };

            await foreach (var evt in reader.ReadAllAsync(ct))
            {
                await Response.WriteAsync($"data: {JsonSerializer.Serialize(evt, jsonOptions)}\n\n", Encoding.UTF8, ct);
                await Response.Body.FlushAsync(ct);
            }

            await Response.WriteAsync("data: {\"type\":\"StreamComplete\"}\n\n", ct);
            await Response.Body.FlushAsync(ct);
        }
        catch (OperationCanceledException) { /* client disconnected */ }
        finally { unsubscribe.Dispose(); }
    }
}
