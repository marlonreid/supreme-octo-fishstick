using k8s;
using k8s.Models;
using System.Text;
using System.Text.Json;
using VClusterApi.Models;

namespace VClusterApi.Services;

public class VClusterService(
    IKubernetes k8s,
    IAzdoService azdo,
    EnvironmentStore store,
    ProgressChannel progress,
    IConfiguration config,
    ILogger<VClusterService> logger) : IVClusterService
{
    private int CreatePipelineId => config.GetValue<int>("Pipelines:CreateVCluster");
    private int DeployPipelineId => config.GetValue<int>("Pipelines:DeployWorkload");
    private int DeletePipelineId => config.GetValue<int>("Pipelines:DeleteVCluster");

    private static readonly TimeSpan ReadinessPoll = TimeSpan.FromSeconds(5);
    private static readonly TimeSpan ReadinessTimeout = TimeSpan.FromMinutes(10);

    // ── Create ────────────────────────────────────────────────────────────────

    public async Task<VClusterEnvironment> CreateAsync(CreateVClusterRequest request, CancellationToken ct = default)
    {
        var env = new VClusterEnvironment(
            Id: Guid.NewGuid().ToString(),
            Name: request.Name,
            Namespace: $"vc-{request.Name}",
            Status: EnvironmentStatus.Queued,
            K8sVersion: request.K8sVersion,
            TtlHours: request.TtlHours,
            CostThresholdGbp: request.CostThresholdGbp,
            CreatedAt: DateTime.UtcNow,
            ReadyAt: null,
            ExpiresAt: request.TtlHours.HasValue ? DateTime.UtcNow.AddHours(request.TtlHours.Value) : null,
            CreatePipelineRunId: null,
            DeployPipelineRunId: null,
            ErrorMessage: null,
            Labels: request.Labels ?? []
        );

        store.Upsert(env);

        // Returns immediately — orchestration runs in background
        _ = Task.Run(() => OrchestrateCreationAsync(env.Id), CancellationToken.None);

        return env;
    }

    // ── Delete ────────────────────────────────────────────────────────────────

    public async Task DeleteAsync(string environmentId, CancellationToken ct = default)
    {
        var env = store.Get(environmentId) ?? throw new KeyNotFoundException($"Environment {environmentId} not found");

        store.Update(environmentId, e => e with { Status = EnvironmentStatus.Deleting });
        Emit(environmentId, ProgressEventType.Info, $"Deleting environment '{env.Name}'...");

        var runId = await azdo.TriggerPipelineAsync(DeletePipelineId, new Dictionary<string, string>
        {
            ["vclusterName"] = env.Name,
            ["namespace"] = env.Namespace
        }, ct);

        _ = Task.Run(() => WatchDeleteAsync(environmentId, runId), CancellationToken.None);
    }

    // ── List / Get ────────────────────────────────────────────────────────────

    public Task<IEnumerable<VClusterSummary>> ListAsync(CancellationToken ct = default) =>
        Task.FromResult(store.GetAll().Select(e =>
            new VClusterSummary(e.Id, e.Name, e.Namespace, e.Status, e.CreatedAt, e.ExpiresAt, null)));

    public async Task<VClusterDetail?> GetDetailAsync(string environmentId, CancellationToken ct = default)
    {
        var env = store.Get(environmentId);
        if (env is null) return null;

        VClusterPodStatus[] pods = [];

        try
        {
            var podList = await k8s.CoreV1.ListNamespacedPodAsync(
                env.Namespace, labelSelector: "app=vcluster", cancellationToken: ct);

            pods = podList.Items.Select(p => new VClusterPodStatus(
                p.Metadata.Name,
                p.Status?.Phase ?? "Unknown",
                p.Status?.ContainerStatuses?.All(cs => cs.Ready) ?? false,
                p.Status?.ContainerStatuses?.Sum(cs => cs.RestartCount) ?? 0,
                p.Status?.StartTime
            )).ToArray();
        }
        catch (Exception ex)
        {
            logger.LogWarning(ex, "Could not fetch pods for {Namespace}", env.Namespace);
        }

        return new VClusterDetail(
            env.Id, env.Name, env.Namespace, env.Status, env.K8sVersion,
            env.CreatedAt, env.ReadyAt, env.ExpiresAt, env.TtlHours,
            env.CostThresholdGbp, null, pods, $"vc-{env.Name}", env.ErrorMessage);
    }

    // ── Kubeconfig ────────────────────────────────────────────────────────────

    public async Task<VClusterKubeconfig> GetKubeconfigAsync(string environmentId, CancellationToken ct = default)
    {
        var env = store.Get(environmentId) ?? throw new KeyNotFoundException($"Environment {environmentId} not found");
        var secretName = $"vc-{env.Name}";

        V1Secret secret;
        try
        {
            secret = await k8s.CoreV1.ReadNamespacedSecretAsync(secretName, env.Namespace, cancellationToken: ct);
        }
        catch (k8s.Autorest.HttpOperationException ex) when (ex.Response.StatusCode == System.Net.HttpStatusCode.NotFound)
        {
            throw new InvalidOperationException("Kubeconfig secret not found — vCluster may still be initialising.");
        }

        if (!secret.Data.TryGetValue("config", out var bytes))
            throw new InvalidOperationException("Secret exists but has no 'config' key.");

        return new VClusterKubeconfig(env.Name, env.Namespace, Encoding.UTF8.GetString(bytes));
    }

    // ── Sleep / Wake ──────────────────────────────────────────────────────────

    public async Task SleepAsync(string environmentId, CancellationToken ct = default)
    {
        var env = store.Get(environmentId) ?? throw new KeyNotFoundException();
        await PatchReplicasAsync(env.Name, env.Namespace, 0, ct);
        store.Update(environmentId, e => e with { Status = EnvironmentStatus.Sleeping });
    }

    public async Task WakeAsync(string environmentId, CancellationToken ct = default)
    {
        var env = store.Get(environmentId) ?? throw new KeyNotFoundException();
        await PatchReplicasAsync(env.Name, env.Namespace, 1, ct);
        store.Update(environmentId, e => e with { Status = EnvironmentStatus.Ready });
    }

    // ── Orchestration (background) ────────────────────────────────────────────

    private async Task OrchestrateCreationAsync(string environmentId)
    {
        try
        {
            var env = store.Get(environmentId)!;

            // 1. Trigger create pipeline
            store.Update(environmentId, e => e with { Status = EnvironmentStatus.CreatingCluster });
            Emit(environmentId, ProgressEventType.PipelineQueued, "Triggering vCluster create pipeline...");

            var createRunId = await azdo.TriggerPipelineAsync(CreatePipelineId, new Dictionary<string, string>
            {
                ["vclusterName"] = env.Name,
                ["namespace"] = env.Namespace,
                ["k8sVersion"] = env.K8sVersion ?? "latest"
            });

            store.Update(environmentId, e => e with { CreatePipelineRunId = createRunId.ToString() });
            Emit(environmentId, ProgressEventType.PipelineStarted, $"Create pipeline started (run #{createRunId})");

            // 2. Stream create pipeline logs
            await foreach (var line in azdo.StreamRunLogsAsync(createRunId))
                Emit(environmentId, ProgressEventType.PipelineLog, line.Text);

            var createRun = await azdo.GetRunAsync(createRunId);
            if (createRun.Result != "succeeded")
            {
                Fail(environmentId, $"Create pipeline {createRun.Result}");
                return;
            }

            Emit(environmentId, ProgressEventType.PipelineComplete, "Create pipeline succeeded");

            // 3. Poll K8s until StatefulSet is ready
            store.Update(environmentId, e => e with { Status = EnvironmentStatus.ClusterReady });
            Emit(environmentId, ProgressEventType.Info, "Waiting for vCluster to become ready...");

            if (!await WaitForReadyAsync(env.Namespace, env.Name))
            {
                Fail(environmentId, "vCluster did not become ready within 10 minutes");
                return;
            }

            Emit(environmentId, ProgressEventType.ClusterReady, "vCluster is ready");

            // 4. Trigger deploy pipeline
            store.Update(environmentId, e => e with { Status = EnvironmentStatus.DeployingWorkload });
            Emit(environmentId, ProgressEventType.DeployStarted, "Triggering workload deploy pipeline...");

            var deployRunId = await azdo.TriggerPipelineAsync(DeployPipelineId, new Dictionary<string, string>
            {
                ["vclusterName"] = env.Name,
                ["namespace"] = env.Namespace
            });

            store.Update(environmentId, e => e with { DeployPipelineRunId = deployRunId.ToString() });
            Emit(environmentId, ProgressEventType.PipelineStarted, $"Deploy pipeline started (run #{deployRunId})");

            await foreach (var line in azdo.StreamRunLogsAsync(deployRunId))
                Emit(environmentId, ProgressEventType.PipelineLog, line.Text);

            var deployRun = await azdo.GetRunAsync(deployRunId);
            if (deployRun.Result != "succeeded")
            {
                Fail(environmentId, $"Deploy pipeline {deployRun.Result}");
                return;
            }

            // 5. Done
            store.Update(environmentId, e => e with { Status = EnvironmentStatus.Ready, ReadyAt = DateTime.UtcNow });
            Emit(environmentId, ProgressEventType.EnvironmentReady, $"Environment '{env.Name}' is ready");
            progress.Complete(environmentId);
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Unhandled error orchestrating {Id}", environmentId);
            Fail(environmentId, ex.Message);
        }
    }

    private async Task WatchDeleteAsync(string environmentId, int runId)
    {
        try
        {
            await foreach (var line in azdo.StreamRunLogsAsync(runId))
                Emit(environmentId, ProgressEventType.PipelineLog, line.Text);

            var run = await azdo.GetRunAsync(runId);
            if (run.Result == "succeeded")
            {
                store.Update(environmentId, e => e with { Status = EnvironmentStatus.Deleted });
                Emit(environmentId, ProgressEventType.PipelineComplete, "Environment deleted");
            }
            else
            {
                Fail(environmentId, $"Delete pipeline {run.Result}");
            }
        }
        catch (Exception ex) { Fail(environmentId, ex.Message); }
        finally { progress.Complete(environmentId); }
    }

    private async Task<bool> WaitForReadyAsync(string ns, string name)
    {
        using var cts = new CancellationTokenSource(ReadinessTimeout);
        while (!cts.Token.IsCancellationRequested)
        {
            try
            {
                var ss = await k8s.AppsV1.ReadNamespacedStatefulSetAsync(name, ns, cancellationToken: cts.Token);
                if ((ss.Status?.ReadyReplicas ?? 0) >= (ss.Spec?.Replicas ?? 1)) return true;
            }
            catch { /* not created yet */ }

            await Task.Delay(ReadinessPoll, cts.Token);
        }
        return false;
    }

    private async Task PatchReplicasAsync(string name, string ns, int replicas, CancellationToken ct)
    {
        var patch = new V1Patch(
            JsonSerializer.Serialize(new { spec = new { replicas } }),
            V1Patch.PatchType.MergePatch);
        await k8s.AppsV1.PatchNamespacedStatefulSetAsync(patch, name, ns, cancellationToken: ct);
    }

    private void Emit(string id, ProgressEventType type, string message) =>
        progress.Publish(new ProgressEvent(id, type, message, DateTime.UtcNow));

    private void Fail(string id, string error)
    {
        store.Update(id, e => e with { Status = EnvironmentStatus.Failed, ErrorMessage = error });
        Emit(id, ProgressEventType.Error, error);
        progress.Complete(id);
    }
}
