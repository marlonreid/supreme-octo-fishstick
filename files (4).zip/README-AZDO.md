# AzDO Pipeline Setup

Three pipelines are required. Create each in AzDO, then put the numeric pipeline IDs
in `api/appsettings.json` under `Pipelines`.

Find an ID from the pipeline URL: `.../_build?definitionId=42`

---

## Pipeline variables (shared)

Set these in a variable group or per-pipeline:

| Variable | Description |
|---|---|
| `SERVICE_CONNECTION` | AzDO service connection to your Azure subscription |
| `AKS_RG` | Resource group of your AKS cluster |
| `AKS_CLUSTER` | AKS cluster name |

---

## 1. CreateVCluster

```yaml
# azure-pipelines-create-vcluster.yml
parameters:
  - name: vclusterName
    type: string
  - name: namespace
    type: string
  - name: k8sVersion
    type: string
    default: latest

trigger: none

pool:
  vmImage: ubuntu-latest

steps:
  - task: AzureCLI@2
    displayName: AKS context
    inputs:
      azureSubscription: $(SERVICE_CONNECTION)
      scriptType: bash
      scriptLocation: inlineScript
      inlineScript: |
        az aks get-credentials \
          --resource-group $(AKS_RG) \
          --name $(AKS_CLUSTER) \
          --overwrite-existing

  - script: |
      curl -L -o vcluster \
        https://github.com/loft-sh/vcluster/releases/download/v0.34.1/vcluster-linux-amd64
      chmod +x vcluster && sudo mv vcluster /usr/local/bin/
    displayName: Install vcluster CLI

  - script: |
      vcluster create ${{ parameters.vclusterName }} \
        --namespace ${{ parameters.namespace }} \
        --connect=false
    displayName: Create vCluster
```

---

## 2. DeployWorkload

```yaml
# azure-pipelines-deploy-workload.yml
parameters:
  - name: vclusterName
    type: string
  - name: namespace
    type: string

trigger: none

pool:
  vmImage: ubuntu-latest

steps:
  - task: AzureCLI@2
    displayName: AKS context
    inputs:
      azureSubscription: $(SERVICE_CONNECTION)
      scriptType: bash
      scriptLocation: inlineScript
      inlineScript: |
        az aks get-credentials \
          --resource-group $(AKS_RG) \
          --name $(AKS_CLUSTER) \
          --overwrite-existing

  - script: |
      curl -L -o vcluster \
        https://github.com/loft-sh/vcluster/releases/download/v0.34.1/vcluster-linux-amd64
      chmod +x vcluster && sudo mv vcluster /usr/local/bin/
    displayName: Install vcluster CLI

  - script: |
      vcluster connect ${{ parameters.vclusterName }} \
        --namespace ${{ parameters.namespace }} \
        --update-current=false \
        --kube-config ./vc-kubeconfig.yaml

      export KUBECONFIG=./vc-kubeconfig.yaml
      # Add your workload deployment here — helm install, kubectl apply, etc.
      kubectl get nodes
    displayName: Deploy workload
```

---

## 3. DeleteVCluster

```yaml
# azure-pipelines-delete-vcluster.yml
parameters:
  - name: vclusterName
    type: string
  - name: namespace
    type: string

trigger: none

pool:
  vmImage: ubuntu-latest

steps:
  - task: AzureCLI@2
    displayName: AKS context
    inputs:
      azureSubscription: $(SERVICE_CONNECTION)
      scriptType: bash
      scriptLocation: inlineScript
      inlineScript: |
        az aks get-credentials \
          --resource-group $(AKS_RG) \
          --name $(AKS_CLUSTER) \
          --overwrite-existing

  - script: |
      curl -L -o vcluster \
        https://github.com/loft-sh/vcluster/releases/download/v0.34.1/vcluster-linux-amd64
      chmod +x vcluster && sudo mv vcluster /usr/local/bin/
    displayName: Install vcluster CLI

  - script: |
      vcluster delete ${{ parameters.vclusterName }} \
        --namespace ${{ parameters.namespace }}
    displayName: Delete vCluster
```

---

## PAT setup (local dev)

```bash
cd api
dotnet user-secrets set "AzDo:OrgUrl" "https://dev.azure.com/your-org"
dotnet user-secrets set "AzDo:Project" "your-project"
dotnet user-secrets set "AzDo:Pat" "your-pat"
```

PAT scope needed: **Pipelines → Read & Execute**

Create at: `https://dev.azure.com/your-org/_usersSettings/tokens`
