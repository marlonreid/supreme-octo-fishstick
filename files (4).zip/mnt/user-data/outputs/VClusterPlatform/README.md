# vCluster Platform

```
platform/
├── api/   .NET 10 Web API
└── ui/    React + TypeScript + Vite
```

## Start both

```bash
# Terminal 1
cd api
dotnet user-secrets set "AzDo:Pat" "your-pat"
dotnet run

# Terminal 2
cd ui
npm install && npm run dev
```

- API: http://localhost:5000
- UI:  http://localhost:5173
- Scalar (API docs): http://localhost:5000/scalar

## Next steps not yet built
- OpenCost polling per namespace → cost enforcement worker
- Velero snapshot before delete
- TTL `IHostedService` background worker
- Auth (Entra / Azure AD)
- Swap `EnvironmentStore` for Redis (state lost on pod restart)
