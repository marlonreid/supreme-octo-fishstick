# Security & Governance

## Identity & RBAC
- App pipeline uses a **service connection** bound to a **custom role** (see `pe/azure/roles/pe.storageAccountDeployer.json`) granting only:
  - Read RG, create/update Storage Accounts, set diag settings, set tags, configure network rules.
- **Subscriptions** and **regions** are resolved inside modules; developers do not provide them.
- **Key Vault** stores secrets. Pipelines read via linked variable groups / Key Vault task.

## Policy Gates
- **OPA Conftest** checks Terraform plan JSON against:
  - Required tags present and **normalized**.
  - Storage accounts must have HTTPS only, min TLS 1.2, public blob access disabled, default action Deny.
  - Allowed SKUs only.
- **Azure Policy** (out-of-band) ensures runtime drift is blocked.

## Data Protection
- Storage accounts:
  - Encryption with MS-managed keys (or CMK if enabled centrally).
  - Private endpoints / selected networks only.
  - Blob versioning & soft-delete (configurable centrally).

## Supply Chain
- Terraform & providers pinned in `versions.tf`.
- Module sources pinned by ref; pipeline caches providers/plugins.
- Plan → apply uses the **same commit SHA**.
