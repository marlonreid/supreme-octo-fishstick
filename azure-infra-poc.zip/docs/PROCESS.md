# Process: Proposals → Critiques → Unified Plan

## Individual proposals

### 1) Developer (DX-first)
- **One pipeline** for app+infra per repo.
- Dev supplies *only*: `environment`, `customer`, `project`, `workload_name`.
- Infra is created by calling **PE-owned Terraform modules**; no raw resources.
- Preview infra changes on **PR** (plan), auto-apply on **main** with approval.
- Module outputs are fed to app deploy (e.g., connection strings from Key Vault).

### 2) Platform Engineer (cost & consistency)
- **PE owns shared infra** (AKS, DB servers, global event hubs) in separate repos/subscriptions.
- **PE publishes versioned Terraform modules** (e.g., `pe/storage-account`) with hard-coded guardrails:
  - Allowed SKUs/tiers, location mapping per environment, naming rules, diagnostics, encryption, network rules.
  - **Subscriptions and tags are *resolved internally*** from `platform.json`.
- **RBAC**: app pipeline uses a **least-privilege** service connection scoped to allowed resource types & RGs.
- **OPA/Conftest** and Terraform validation run on every change.

### 3) Security (secure by default)
- Modules enforce:
  - TLS 1.2+, public access disabled, HTTPS only, key rotation, default deny networking + allow-lists.
  - Diagnostic settings to a central Log Analytics workspace.
  - **Tag normalization** & allowlist for `customer` / `project` (no typos: “Acme co” → “Acme Corp”).
- Azure Policy + custom role definitions to ensure drift can’t introduce risky settings.
- Secrets never in pipeline logs; use **Key Vault** and managed identities.

### 4) Technical Manager (speed & cost-of-dev)
- **No handoffs**: app teams self-serve infra via PE modules.
- **One pipeline** reduces coordination overhead.
- Guardrails ensure cost/correctness without blocking delivery.
- Lifecycle: PR checks (plan + policy), main deploy (apply + app deploy), clear rollback via `terraform destroy` for ephemeral envs.

## Group critiques (highlights)
- Dev: OK with module-only approach if inputs are minimal & docs/examples provided.
- PE: Needs strict control of location/subscription/SKU/tags → solved by embedded `platform.json` and validations.
- Security: Wants Azure Policy/OPA gates, and least-privilege service connection → included.
- Manager: Accepts small overhead for policy gates; insists pipeline remains single and fast → cached providers, prebuilt steps/templates.

## Unified design

- **PE publishes** modules in this repo’s `pe/terraform/modules/*` (or a separate registry). They include:
  - `platform.json` mapping `environment → subscription, region, diagnostics` (PE-controlled).
  - `customers.json` canonical names & aliases for tag normalization (PE-controlled).
  - Validation for allowed SKUs + enforced tags.
- **Developers use** a tiny root module under `app/<app>/infra` to call PE modules with *only* minimal vars.
- **Azure DevOps single pipeline** runs:
  1. Validate & `terraform plan` on PR (with OPA Conftest gate).
  2. `terraform apply` + app deploy on main, using a **restricted** service connection & Key Vault.
- **Security/PE** augment controls with Azure Policy & custom roles.
- **Efficiency** maintained: single pipeline, reusable templates, and fast feedback.

See `docs/SECURITY.md` for control details and `app/sample-app/pipelines/azure-pipelines.yml`.
