# Unified App+Infra Delivery POC (Azure DevOps + Terraform)

This repo demonstrates a single-pipeline app+infra process that keeps **Platform Engineering (PE)** in control of
shared/critical decisions while letting **Developers** provision per-app resources (like Storage Accounts) *during the app deployment*.

- Terraform **module(s) owned by PE** enforce security/cost/tag rules.
- Developers pass **only minimal inputs** (environment, customer, project, workload).
- **Subscriptions/regions/tiers/tags** are centrally controlled by PE inside the module/config.
- **OPA Conftest** validates plans for policy compliance.
- **Azure DevOps** single pipeline handles validate → plan (PR) and apply → deploy (main).

Read `docs/PROCESS.md` for the roles' proposals, critiques, final design, and how this POC satisfies each requirement.
