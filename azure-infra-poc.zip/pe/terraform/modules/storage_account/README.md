# pe/storage_account module

- **PE-controlled**: subscriptions, locations, SKUs, tags, diagnostics.
- **Dev inputs**: `environment`, `customer`, `project`, `workload_name`.
- Tag normalization based on `customers.json` to avoid typos.
- Security defaults: HTTPS only, TLS1.2+, public access disabled, deny by default networking.
