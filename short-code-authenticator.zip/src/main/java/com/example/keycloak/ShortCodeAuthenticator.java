
package com.example.keycloak;

import org.keycloak.authentication.AuthenticationFlowContext;
import org.keycloak.authentication.Authenticator;
import org.keycloak.models.UserModel;
import jakarta.ws.rs.core.Response;

public class ShortCodeAuthenticator implements Authenticator {

    @Override
    public void authenticate(AuthenticationFlowContext context) {
        Response challenge = context.form()
            .createForm("short-code-login.ftl");
        context.challenge(challenge);
    }

    @Override
    public void action(AuthenticationFlowContext context) {
        String code = context.getHttpRequest().getDecodedFormParameters().getFirst("code");
        UserModel user = context.getSession().users().getUserByUsername(context.getRealm(), code);

        if (user != null) {
            context.setUser(user);
            context.success();
        } else {
            Response challenge = context.form()
                .setError("Invalid code")
                .createForm("short-code-login.ftl");
            context.failureChallenge(org.keycloak.authentication.AuthenticationFlowError.INVALID_CREDENTIALS, challenge);
        }
    }

    @Override public void close() {}
    @Override public void requireUpdate() {}
    @Override public boolean requiresUser() { return false; }
    @Override public boolean configuredFor(org.keycloak.models.KeycloakSession session, org.keycloak.models.RealmModel realm, UserModel user) { return true; }
    @Override public void setRequiredActions(org.keycloak.models.KeycloakSession session, org.keycloak.models.RealmModel realm, UserModel user) {}
}
