using EphemeralConsole.Ui;

namespace EphemeralConsole.Views;

/// <summary>Scopes: all, static, temporary. Actions: d describe. No add/delete here: that's the point.</summary>
public sealed class WorkloadsView : IResourceView
{
    private sealed record WorkloadItem(
        string Env, string Name, string Kind, string Ready, string Status, int Restarts, TimeSpan Age);

    private static readonly WorkloadItem[] Seed =
    [
        new("pr-1423-checkout", "checkout-api", "temporary", "2/2", "Running", 0, TimeSpan.FromHours(5.2)),
        new("pr-1423-checkout", "postgres", "static", "1/1", "Running", 0, TimeSpan.FromHours(5.2)),
        new("pr-1431-ledger", "ledger-api", "temporary", "0/1", "ContainerCreating", 0, TimeSpan.FromMinutes(3)),
        new("demo-keycloak-sso", "keycloak", "static", "1/1", "Running", 1, TimeSpan.FromDays(2.4)),
        new("pr-87-realm-sync", "realm-sync-job", "temporary", "0/1", "CrashLoopBackOff", 14, TimeSpan.FromHours(20)),
        new("qa-regression", "tests-runner", "static", "1/1", "Running", 0, TimeSpan.FromDays(6)),
        new("sandbox", "vcluster", "static", "1/1", "Running", 0, TimeSpan.FromMinutes(42)),
    ];

    public WorkloadsView()
    {
        Scopes =
        [
            ScopeDef.All,
            new ScopeDef("static", r => Item(r).Kind == "static"),
            new ScopeDef("temporary", r => Item(r).Kind == "temporary"),
        ];

        Actions = [new ViewAction(new KeyChord(ConsoleKey.D), "Describe", DescribeAsync)];
    }

    public IReadOnlyList<string> Names { get; } = ["workloads", "wl"];

    public string Title => "workloads";

    public IReadOnlyList<ColumnDef> Columns { get; } =
    [
        new("ENV", Sorted: true),
        new("NAME"),
        new("KIND"),
        new("READY"),
        new("STATUS"),
        new("RESTARTS", RightAligned: true),
        new("AGE", RightAligned: true),
    ];

    public IReadOnlyList<ScopeDef> Scopes { get; }

    public IReadOnlyList<ViewAction> Actions { get; }

    public async Task<IReadOnlyList<ResourceRow>> LoadAsync(CancellationToken ct)
    {
        await Task.Delay(150, ct); // pretend to be an HTTP call

        return Seed
            .OrderBy(s => s.Env).ThenBy(s => s.Name)
            .Select(s => new ResourceRow(
            [
                new ResourceCell(s.Env),
                new ResourceCell(s.Name),
                new ResourceCell(s.Kind),
                new ResourceCell(s.Ready),
                new ResourceCell(s.Status, ViewFormat.StatusColor(s.Status)),
                new ResourceCell(s.Restarts.ToString(), s.Restarts > 0 ? "yellow" : null),
                new ResourceCell(ViewFormat.Age(s.Age)),
            ], s))
            .ToList();
    }

    private Task DescribeAsync(ActionContext ctx)
    {
        var w = Item(ctx.Selected!);

        ctx.Host.ShowText($"describe({w.Name})",
            $"""
             Name:         {w.Name}
             Environment:  {w.Env}
             Kind:         {w.Kind}
             Ready:        {w.Ready}
             Status:       {w.Status}
             Restarts:     {w.Restarts}
             Age:          {ViewFormat.Age(w.Age)}
             """);

        return Task.CompletedTask;
    }

    private static WorkloadItem Item(ResourceRow row) => (WorkloadItem)row.Data!;
}
