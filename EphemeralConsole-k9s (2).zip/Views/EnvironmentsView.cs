using EphemeralConsole.Ui;

namespace EphemeralConsole.Views;

/// <summary>
/// Scopes: all, and "yours". Actions: ctrl-a add (opens a form screen), ctrl-d delete (confirm popup),
/// d describe (text screen). Everything here is the view's decision; the shell just renders it.
/// </summary>
public sealed class EnvironmentsView : IResourceView
{
    private readonly IEnvironmentStore _store;
    private readonly string _user;

    public EnvironmentsView(IEnvironmentStore store)
    {
        _store = store;
        _user = System.Environment.UserName; // System. prefix: EphemeralConsole.Environment is a namespace in your project

        Scopes =
        [
            ScopeDef.All,
            new ScopeDef(_user, r => Item(r).Owner.Equals(_user, StringComparison.OrdinalIgnoreCase)),
        ];

        Actions =
        [
            new ViewAction(new KeyChord(ConsoleKey.A, ConsoleModifiers.Control), "Add", AddAsync, RequiresSelection: false),
            new ViewAction(new KeyChord(ConsoleKey.D, ConsoleModifiers.Control), "Delete", DeleteAsync),
            new ViewAction(new KeyChord(ConsoleKey.D), "Describe", DescribeAsync),
        ];
    }

    public IReadOnlyList<string> Names { get; } = ["environments", "envs", "env"];

    public string Title => "environments";

    public IReadOnlyList<ColumnDef> Columns { get; } =
    [
        new("NAME", Sorted: true),
        new("OWNER"),
        new("STATUS"),
        new("AGE", RightAligned: true),
    ];

    public IReadOnlyList<ScopeDef> Scopes { get; }

    public IReadOnlyList<ViewAction> Actions { get; }

    public async Task<IReadOnlyList<ResourceRow>> LoadAsync(CancellationToken ct)
    {
        var now = DateTimeOffset.UtcNow;
        var items = await _store.ListAsync(ct);

        return items
            .OrderBy(i => i.Name, StringComparer.OrdinalIgnoreCase)
            .Select(i => new ResourceRow(
            [
                new ResourceCell(i.Name),
                new ResourceCell(i.Owner),
                new ResourceCell(i.Status, ViewFormat.StatusColor(i.Status)),
                new ResourceCell(ViewFormat.Age(now - i.Created)),
            ], i))
            .ToList();
    }

    // ───────────── actions ─────────────

    private Task AddAsync(ActionContext ctx)
    {
        // Opens a new screen. Submitting closes it, runs the call in the background, then reloads the table.
        ctx.Host.ShowForm(
            "new environment",
            [new FormField("Name"), new FormField("Owner", _user)],
            values => _store.CreateAsync(values["Name"].Trim(), values["Owner"].Trim(), CancellationToken.None),
            successMessage: "environment requested");

        return Task.CompletedTask;
    }

    private Task DeleteAsync(ActionContext ctx)
    {
        var item = Item(ctx.Selected!);

        // Opens a modal popup. Nothing happens unless the user picks Yes.
        ctx.Host.Confirm(
            "delete environment",
            $"Delete '{item.Name}'?\nThis can't be undone.",
            () => _store.DeleteAsync(item.Name, CancellationToken.None),
            successMessage: $"deleted {item.Name}");

        return Task.CompletedTask;
    }

    private Task DescribeAsync(ActionContext ctx)
    {
        var item = Item(ctx.Selected!);
        var age = DateTimeOffset.UtcNow - item.Created;

        // A screen with no table at all, just text.
        ctx.Host.ShowText($"describe({item.Name})",
            $"""
             Name:      {item.Name}
             Owner:     {item.Owner}
             Status:    {item.Status}
             Created:   {item.Created.ToLocalTime():yyyy-MM-dd HH:mm:ss}
             Age:       {ViewFormat.Age(age)}
             """);

        return Task.CompletedTask;
    }

    private static EnvironmentItem Item(ResourceRow row) => (EnvironmentItem)row.Data!;
}
