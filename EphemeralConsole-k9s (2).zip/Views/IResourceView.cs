using EphemeralConsole.Ui;

namespace EphemeralConsole.Views;

/// <summary>A column header. The UI decides widths; the view only says what the column is.</summary>
public sealed record ColumnDef(string Header, bool RightAligned = false, bool Sorted = false);

/// <summary>One cell of text. Color is a Spectre colour name ("green", "red", "orange1"), or null for default.</summary>
public sealed record ResourceCell(string Text, string? Color = null);

/// <summary>
/// One table row. Data is whatever your view wants back when the row is selected or tested against a scope
/// (typically the underlying model object).
/// </summary>
public sealed record ResourceRow(IReadOnlyList<ResourceCell> Cells, object? Data = null);

/// <summary>A named subset of rows, selected with the number keys. The view decides what each one means.</summary>
public sealed record ScopeDef(string Name, Func<ResourceRow, bool> Matches)
{
    public static ScopeDef All { get; } = new("all", _ => true);
}

/// <summary>What an action receives. Selected is null only when the table is empty (and the action allows that).</summary>
public sealed record ActionContext(ResourceRow? Selected, IScreenHost Host);

/// <summary>
/// A key bound to something the view does. Execute can open screens, show popups or call an API via the host.
/// Set RequiresSelection to false for actions like "add" that don't need a row.
/// </summary>
public sealed record ViewAction(
    KeyChord Key,
    string Description,
    Func<ActionContext, Task> Execute,
    bool RequiresSelection = true);

/// <summary>
/// Everything the shell needs to show a table screen. Implement once per thing you want to list.
/// Nothing in here knows about Spectre or rendering.
/// </summary>
public interface IResourceView
{
    /// <summary>Command names for ":name". First is canonical, the rest are aliases.</summary>
    IReadOnlyList<string> Names { get; }

    /// <summary>Shown in the panel title and the crumb, e.g. "environments".</summary>
    string Title { get; }

    IReadOnlyList<ColumnDef> Columns { get; }

    /// <summary>Scopes for the number keys (0, 1, 2...). The first one is selected initially.</summary>
    IReadOnlyList<ScopeDef> Scopes { get; }

    /// <summary>Extra keys this view responds to. "/" and ":" are reserved by the shell.</summary>
    IReadOnlyList<ViewAction> Actions => [];

    /// <summary>Return rows already sorted the way you want them shown.</summary>
    Task<IReadOnlyList<ResourceRow>> LoadAsync(CancellationToken ct);
}

/// <summary>Maps command names (":envs") to views. DI hands it every registered view.</summary>
public sealed class ViewRegistry(IEnumerable<IResourceView> views)
{
    private readonly IReadOnlyList<IResourceView> _views = views.ToList();

    /// <summary>Canonical name of each view, for help/error text.</summary>
    public IEnumerable<string> Names => _views.Select(v => v.Names[0]);

    /// <summary>The first registered view is where the app starts.</summary>
    public IResourceView Default => _views[0];

    public bool TryGet(string name, out IResourceView view)
    {
        view = _views.FirstOrDefault(v => v.Names.Contains(name, StringComparer.OrdinalIgnoreCase))!;
        return view is not null;
    }
}

/// <summary>Small formatting helpers views can share.</summary>
public static class ViewFormat
{
    public static string Age(TimeSpan s)
    {
        if (s.TotalDays >= 1) return $"{(int)s.TotalDays}d{s.Hours}h";
        if (s.TotalHours >= 1) return $"{(int)s.TotalHours}h{s.Minutes}m";
        if (s.TotalMinutes >= 1) return $"{(int)s.TotalMinutes}m";
        return $"{(int)s.TotalSeconds}s";
    }

    public static string StatusColor(string status) => status switch
    {
        "Running" => "green",
        "Provisioning" or "Pending" or "ContainerCreating" => "yellow",
        "Failed" or "Error" or "CrashLoopBackOff" => "red",
        "Terminating" => "orange1",
        _ => "grey",
    };
}
