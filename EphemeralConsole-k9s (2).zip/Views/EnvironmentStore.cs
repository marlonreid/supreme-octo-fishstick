namespace EphemeralConsole.Views;

public sealed record EnvironmentItem(string Name, string Owner, string Status, DateTimeOffset Created);

/// <summary>
/// What the environments view needs from the backend. Implement this over your EnvironmentService
/// (HttpClient calls to ephemeral-api) and swap the registration in Program.cs.
/// </summary>
public interface IEnvironmentStore
{
    Task<IReadOnlyList<EnvironmentItem>> ListAsync(CancellationToken ct);
    Task CreateAsync(string name, string owner, CancellationToken ct);
    Task DeleteAsync(string name, CancellationToken ct);
}

/// <summary>Fake backend so the UI works without the API. New environments go Provisioning, then Running after 6s.</summary>
public sealed class InMemoryEnvironmentStore : IEnvironmentStore
{
    private readonly object _gate = new();
    private readonly List<EnvironmentItem> _items;

    public InMemoryEnvironmentStore()
    {
        var me = System.Environment.UserName; // System. prefix: EphemeralConsole.Environment is a namespace in your project
        var now = DateTimeOffset.UtcNow;
        _items =
        [
            new("pr-1423-checkout", "alice", "Running", now - TimeSpan.FromHours(5.2)),
            new("pr-1431-ledger", "bob", "Running", now - TimeSpan.FromHours(1.5)),
            new("demo-keycloak-sso", "alice", "Running", now - TimeSpan.FromDays(2.4)),
            new("pr-87-realm-sync", "bob", "Failed", now - TimeSpan.FromHours(20)),
            new("qa-regression", "carol", "Running", now - TimeSpan.FromDays(6)),
            new("sandbox", me, "Running", now - TimeSpan.FromMinutes(42)),
            new("vcluster-poc", me, "Running", now - TimeSpan.FromDays(3)),
        ];
    }

    public async Task<IReadOnlyList<EnvironmentItem>> ListAsync(CancellationToken ct)
    {
        await Task.Delay(150, ct); // pretend to be an HTTP call
        var now = DateTimeOffset.UtcNow;

        lock (_gate)
        {
            return _items
                .Select(i => i.Status == "Provisioning" && now - i.Created > TimeSpan.FromSeconds(6)
                    ? i with { Status = "Running" }
                    : i)
                .ToList();
        }
    }

    public async Task CreateAsync(string name, string owner, CancellationToken ct)
    {
        await Task.Delay(400, ct);

        lock (_gate)
        {
            if (_items.Any(i => i.Name.Equals(name, StringComparison.OrdinalIgnoreCase)))
                throw new InvalidOperationException($"'{name}' already exists");

            _items.Add(new EnvironmentItem(name, owner, "Provisioning", DateTimeOffset.UtcNow));
        }
    }

    public async Task DeleteAsync(string name, CancellationToken ct)
    {
        await Task.Delay(400, ct);

        lock (_gate)
        {
            _items.RemoveAll(i => i.Name.Equals(name, StringComparison.OrdinalIgnoreCase));
        }
    }
}
