using System.Collections.Concurrent;
using EphemeralConsole.Views;
using Spectre.Console;
using Spectre.Console.Rendering;

namespace EphemeralConsole.Ui;

public sealed record AppInfo(string Context, string Api, string Version);

internal enum Mode { Normal, Command, Filter }

/// <summary>
/// The k9s-style shell: header, body, prompt and crumb around a stack of screens.
/// It knows nothing about environments or workloads; it asks the top screen to draw and handle keys.
/// </summary>
public sealed class K9sApp : IScreenHost
{
    private const int HeaderHeight = 8;
    private const int HeaderLines = 7;
    private static readonly TimeSpan RefreshInterval = TimeSpan.FromSeconds(2);

    private readonly ViewRegistry _views;
    private readonly AppInfo _info;
    private readonly CancellationTokenSource _cts = new();

    // Everything that changes the screen stack goes through this queue and is applied on the UI thread,
    // so views can call the host from background continuations safely.
    private readonly ConcurrentQueue<Action> _pending = new();
    private readonly Stack<IScreen> _stack = new();

    private volatile bool _quit, _dirty = true;
    private int _refreshing;

    private Mode _mode = Mode.Normal;
    private string _buffer = "";

    private volatile string _flash = "";
    private volatile bool _flashError;
    private DateTime _flashUntil;

    public K9sApp(ViewRegistry views, AppInfo info)
    {
        _views = views;
        _info = info;
        _stack.Push(new ResourceScreen(views.Default));
    }

    // ───────────── IScreenHost ─────────────

    public void Push(IScreen screen) => Post(() => PushNow(screen));

    public void Pop() => Post(PopNow);

    public void Reload() => Post(() => RefreshTop());

    public void Flash(string message, bool error = false)
    {
        _flash = message;
        _flashError = error;
        _flashUntil = DateTime.UtcNow.AddSeconds(4);
        _dirty = true;
    }

    public void RunInBackground(Func<Task> work, string? successMessage = null)
    {
        _ = Task.Run(async () =>
        {
            try
            {
                await work();
                if (successMessage is not null) Flash(successMessage);
                Reload();
            }
            catch (Exception ex)
            {
                Flash(ex.Message, error: true);
            }
        });
    }

    private void Post(Action action)
    {
        _pending.Enqueue(action);
        _dirty = true;
    }

    private void Drain()
    {
        while (_pending.TryDequeue(out var action)) action();
    }

    private void PushNow(IScreen screen)
    {
        _stack.Push(screen);
        _mode = Mode.Normal;
        _buffer = "";
        RefreshTop();
    }

    private void PopNow()
    {
        if (_stack.Count <= 1) return;
        _stack.Pop();
        RefreshTop(); // whatever we land on should show fresh data (e.g. after a form closes)
    }

    // ───────────── lifecycle ─────────────

    public void Run()
    {
        Splash();
        AnsiConsole.Status().Spinner(Spinner.Known.Dots).Start($"Loading {_stack.Peek().Title}…", _ =>
        {
            try { _stack.Peek().RefreshAsync(_cts.Token).GetAwaiter().GetResult(); }
            catch (Exception ex) { Flash($"load failed: {ex.Message}", error: true); }
            Thread.Sleep(500); // let the splash breathe
        });

        _ = Task.Run(async () =>
        {
            using var timer = new PeriodicTimer(RefreshInterval);
            try { while (await timer.WaitForNextTickAsync(_cts.Token)) Post(() => RefreshTop(force: false)); }
            catch (OperationCanceledException) { }
        });

        AnsiConsole.Live(Render())
            .AutoClear(true)
            .Overflow(VerticalOverflow.Crop)
            .Cropping(VerticalOverflowCropping.Bottom)
            .Start(ctx =>
            {
                var lastSize = (Console.WindowWidth, Console.WindowHeight);
                while (!_quit)
                {
                    Drain();
                    while (Console.KeyAvailable) HandleKey(Console.ReadKey(true));
                    Drain(); // apply whatever those keys posted in the same frame

                    var size = (Console.WindowWidth, Console.WindowHeight);
                    if (size != lastSize) { lastSize = size; _dirty = true; }

                    if (_flash.Length > 0 && DateTime.UtcNow > _flashUntil) { _flash = ""; _dirty = true; }

                    if (_dirty)
                    {
                        _dirty = false;
                        ctx.UpdateTarget(Render());
                        ctx.Refresh();
                    }
                    Thread.Sleep(25);
                }
            });

        _cts.Cancel();
    }

    private static void Splash()
    {
        AnsiConsole.Clear();
        for (var i = 0; i < Math.Max(0, Console.WindowHeight / 2 - 5); i++) AnsiConsole.WriteLine();
        AnsiConsole.Write(new FigletText("Ephemeral").Centered().Color(Color.Orange1));
        AnsiConsole.Write(Align.Center(new Markup("[grey]environments console[/]")));
        AnsiConsole.WriteLine();
    }

    /// <summary>Reload the top screen in the background. Timer ticks (force: false) skip if a reload is still running.</summary>
    private void RefreshTop(bool force = true)
    {
        if (!force && Interlocked.CompareExchange(ref _refreshing, 1, 0) != 0) return;

        var screen = _stack.Peek();
        _ = Task.Run(async () =>
        {
            try
            {
                await screen.RefreshAsync(_cts.Token);
                _dirty = true;
            }
            catch (OperationCanceledException) { }
            catch (Exception ex) { Flash($"refresh failed: {ex.Message}", error: true); }
            finally
            {
                if (!force) Interlocked.Exchange(ref _refreshing, 0);
            }
        });
    }

    // ───────────── input ─────────────

    private void HandleKey(ConsoleKeyInfo k)
    {
        _dirty = true;
        if (k.Key == ConsoleKey.C && k.Modifiers.HasFlag(ConsoleModifiers.Control)) { _quit = true; return; }
        if (_mode != Mode.Normal) { HandlePrompt(k); return; }

        var screen = _stack.Peek();
        if (screen.HandleKey(k, this)) return;

        // Keys the screen didn't want belong to the shell.
        switch (k.KeyChar)
        {
            case ':': _mode = Mode.Command; _buffer = ""; return;
            case '/' when screen is IFilterable f: _mode = Mode.Filter; _buffer = f.Filter; return;
            case 'q' or 'Q': BackOrQuit(); return;
        }

        if (k.Key == ConsoleKey.Escape) BackOrQuit(quit: false);
    }

    private void BackOrQuit(bool quit = true)
    {
        if (_stack.Count > 1) PopNow();
        else if (quit) _quit = true;
    }

    private void HandlePrompt(ConsoleKeyInfo k)
    {
        var filterable = _stack.Peek() as IFilterable;

        switch (k.Key)
        {
            case ConsoleKey.Escape:
                if (_mode == Mode.Filter && filterable is not null) filterable.Filter = "";
                _buffer = ""; _mode = Mode.Normal;
                return;
            case ConsoleKey.Enter:
                var mode = _mode;
                var text = _buffer.Trim();
                _buffer = ""; _mode = Mode.Normal;
                if (mode == Mode.Command) Execute(text);
                return;
            case ConsoleKey.Backspace:
                if (_buffer.Length > 0) _buffer = _buffer[..^1];
                break;
            default:
                if (!char.IsControl(k.KeyChar)) _buffer += k.KeyChar;
                break;
        }

        if (_mode == Mode.Filter && filterable is not null) filterable.Filter = _buffer; // live filter
    }

    private void Execute(string cmd)
    {
        var name = cmd.Split(' ', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
            .FirstOrDefault()?.ToLowerInvariant();
        if (name is null) return;

        if (name is "q" or "quit" or "exit") { _quit = true; return; }
        if (_views.TryGet(name, out var view)) { PushNow(new ResourceScreen(view)); return; }

        Flash($"unknown command: {cmd}  (views: {string.Join(", ", _views.Names)})", error: true);
    }

    // ───────────── rendering ─────────────

    private int BodyHeight() =>
        Math.Max(4, Console.WindowHeight - HeaderHeight - (_mode != Mode.Normal ? 3 : 0) - 1);

    private IRenderable Render()
    {
        var screen = _stack.Peek();
        var area = new RenderArea(Math.Max(20, Console.WindowWidth), BodyHeight());

        var layout = new Layout("root").SplitRows(
            new Layout("header").Size(HeaderHeight),
            new Layout("body"),
            new Layout("prompt").Size(3),
            new Layout("crumb").Size(1));

        layout["header"].Update(Header(screen));
        layout["body"].Update(screen.Render(area));
        layout["prompt"].Update(PromptBox());
        layout["prompt"].IsVisible = _mode != Mode.Normal;
        layout["crumb"].Update(Crumb());
        return layout;
    }

    private IRenderable Header(IScreen screen)
    {
        static string Kv(string label, string value) =>
            $"[bold orange1]{label,-9}[/] [white]{Markup.Escape(value)}[/]";

        var info = new Markup(string.Join('\n',
            Kv("Context:", _info.Context),
            Kv("API:", _info.Api),
            Kv("User:", System.Environment.UserName), // System. prefix: EphemeralConsole.Environment is a namespace in your project
            Kv("Rev:", _info.Version),
            Kv("Refresh:", $"{RefreshInterval.TotalSeconds:0}s")));

        var menu = new Markup(string.Join('\n', screen.Menu.Take(HeaderLines).Select(m =>
            $"[fuchsia]{Markup.Escape(m.Key),-5}[/] " + (m.Active
                ? $"[bold white]{Markup.Escape(m.Description)}[/]"
                : $"[white]{Markup.Escape(m.Description)}[/]"))));

        var hints = new Markup(string.Join('\n', screen.Hints.Take(HeaderLines).Select(h =>
            $"[dodgerblue1]{Markup.Escape(h.Key),-9}[/] [white]{Markup.Escape(h.Description)}[/]")));

        var logo = Align.Right(new FigletText("EPH").Color(Color.Orange1));

        var grid = new Grid()
            .AddColumn(new GridColumn().Width(36).NoWrap())
            .AddColumn(new GridColumn().Width(24).NoWrap())
            .AddColumn(new GridColumn().Width(28).NoWrap())
            .AddColumn(new GridColumn());
        grid.AddRow(info, menu, hints, logo);

        return new Padder(grid, new Padding(1, 0, 1, 0));
    }

    private IRenderable PromptBox()
    {
        var sigil = _mode == Mode.Command ? "[orange1]:[/]" : "[orange1]/[/]";
        return new Panel(new Markup($"{sigil}[white]{Markup.Escape(_buffer)}[/][grey]▌[/]"))
        {
            Border = BoxBorder.Rounded,
            BorderStyle = new Style(Color.DodgerBlue1),
            Expand = true,
        };
    }

    private IRenderable Crumb()
    {
        var text = string.Concat(_stack.Reverse().Select(s => $"[black on yellow] <{Markup.Escape(s.Title)}> [/] "));

        if (_stack.Peek() is IFilterable { Filter.Length: > 0 } f)
            text += $"[black on aqua] </{Markup.Escape(f.Filter)}> [/] ";

        if (_flash.Length > 0)
            text += _flashError
                ? $"[bold red]{Markup.Escape(_flash)}[/]"
                : $"[bold green]{Markup.Escape(_flash)}[/]";

        return new Markup(text) { Overflow = Overflow.Crop };
    }
}
