using Spectre.Console.Rendering;

namespace EphemeralConsole.Ui;

/// <summary>The space a screen may draw in (the body region, between header and crumb).</summary>
public readonly record struct RenderArea(int Width, int Height);

/// <summary>A key + description pair shown in the header. Active highlights it (e.g. the current scope).</summary>
public sealed record KeyHint(string Key, string Description, bool Active = false);

/// <summary>A key combination, e.g. new(ConsoleKey.D, ConsoleModifiers.Control) for ctrl-d.</summary>
public readonly record struct KeyChord(ConsoleKey Key, ConsoleModifiers Modifiers = 0)
{
    public bool Matches(ConsoleKeyInfo k) => k.Key == Key && k.Modifiers == Modifiers;

    public string Label
    {
        get
        {
            var mods = (Modifiers.HasFlag(ConsoleModifiers.Control) ? "ctrl-" : "")
                     + (Modifiers.HasFlag(ConsoleModifiers.Alt) ? "alt-" : "")
                     + (Modifiers.HasFlag(ConsoleModifiers.Shift) ? "shift-" : "");
            return $"<{mods}{Key.ToString().ToLowerInvariant()}>";
        }
    }
}

/// <summary>
/// Anything that can sit on the screen stack: a table, a text page, a form, a popup.
/// The shell owns the header, prompt and crumb; a screen owns only the body.
/// </summary>
public interface IScreen
{
    /// <summary>Shown in the crumb, e.g. "environments" or "describe(pr-12)".</summary>
    string Title { get; }

    /// <summary>Header middle column (scope shortcuts for tables). Empty for most screens.</summary>
    IReadOnlyList<KeyHint> Menu => [];

    /// <summary>Header right column: the keys this screen responds to.</summary>
    IReadOnlyList<KeyHint> Hints => [];

    IRenderable Render(RenderArea area);

    /// <summary>Return true if the key was used. Unused keys fall through to the shell (":" command, "q"/esc back).</summary>
    bool HandleKey(ConsoleKeyInfo key, IScreenHost host);

    /// <summary>Called on a timer and after actions. Screens with nothing to refresh can ignore it.</summary>
    Task RefreshAsync(CancellationToken ct) => Task.CompletedTask;
}

/// <summary>A screen that supports the "/" filter.</summary>
public interface IFilterable
{
    string Filter { get; set; }
}

/// <summary>
/// What screens and view actions can ask the shell to do. All members are safe to call from any thread;
/// changes are applied on the UI thread.
/// </summary>
public interface IScreenHost
{
    void Push(IScreen screen);
    void Pop();

    /// <summary>Re-load the screen currently on top.</summary>
    void Reload();

    void Flash(string message, bool error = false);

    /// <summary>
    /// Run slow work (an API call) off the UI thread. On success the optional message is flashed and the
    /// current screen reloads; on failure the exception message is flashed as an error.
    /// </summary>
    void RunInBackground(Func<Task> work, string? successMessage = null);
}

/// <summary>Convenience wrappers so views don't need to construct screens themselves.</summary>
public static class ScreenHostExtensions
{
    public static void ShowText(this IScreenHost host, string title, string text) =>
        host.Push(new TextScreen(title, text));

    /// <summary>Modal yes/no popup. onYes runs in the background if the user confirms. Defaults to "No".</summary>
    public static void Confirm(this IScreenHost host, string title, string message,
        Func<Task> onYes, string? successMessage = null) =>
        host.Push(new ConfirmScreen(title, message, onYes, successMessage));

    /// <summary>Full form screen. onSubmit receives values keyed by field name and runs in the background.</summary>
    public static void ShowForm(this IScreenHost host, string title, IReadOnlyList<FormField> fields,
        Func<IReadOnlyDictionary<string, string>, Task> onSubmit, string? successMessage = null) =>
        host.Push(new FormScreen(title, fields, onSubmit, successMessage));
}
