using Spectre.Console;
using Spectre.Console.Rendering;

namespace EphemeralConsole.Ui;

/// <summary>
/// Modal yes/no popup, centred in the body. Defaults to "No" so a stray Enter can't delete anything.
/// It swallows every key while open.
/// </summary>
public sealed class ConfirmScreen(string title, string message, Func<Task> onYes, string? successMessage) : IScreen
{
    private bool _yes;

    public string Title => title;

    public IReadOnlyList<KeyHint> Hints { get; } =
    [
        new("<y>", "Yes"),
        new("<n>", "No"),
        new("<tab>", "Toggle"),
        new("<enter>", "Select"),
        new("<esc>", "Cancel"),
    ];

    public IRenderable Render(RenderArea area)
    {
        var buttons = $"{Button("Yes", _yes)}    {Button("No", !_yes)}";

        var panel = new Panel(new Rows(
            Align.Center(new Markup($"[white]{Markup.Escape(message)}[/]")),
            new Markup(" "),
            Align.Center(new Markup(buttons))))
        {
            Header = new PanelHeader($"[orange1]{Markup.Escape(title)}[/]", Justify.Center),
            Border = BoxBorder.Double,
            BorderStyle = new Style(Color.Orange1),
            Padding = new Padding(3, 1, 3, 1),
            Width = Math.Clamp(area.Width - 4, 20, 60),
        };

        var top = Math.Max(0, (area.Height - 9) / 2); // roughly vertical centre
        return new Padder(Align.Center(panel), new Padding(0, top, 0, 0));
    }

    public bool HandleKey(ConsoleKeyInfo k, IScreenHost host)
    {
        switch (k.Key)
        {
            case ConsoleKey.Escape: host.Pop(); break;
            case ConsoleKey.Enter: Choose(_yes, host); break;
            case ConsoleKey.Tab or ConsoleKey.LeftArrow or ConsoleKey.RightArrow: _yes = !_yes; break;
            default:
                switch (char.ToLowerInvariant(k.KeyChar))
                {
                    case 'y': Choose(true, host); break;
                    case 'n': Choose(false, host); break;
                }
                break;
        }

        return true; // modal: nothing falls through to the screen underneath
    }

    private void Choose(bool yes, IScreenHost host)
    {
        host.Pop();
        if (yes) host.RunInBackground(onYes, successMessage);
    }

    private static string Button(string label, bool active) =>
        active ? $"[black on orange1] {label} [/]" : $"[white on grey23] {label} [/]";
}
