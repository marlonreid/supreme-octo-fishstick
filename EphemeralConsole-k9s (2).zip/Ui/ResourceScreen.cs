using EphemeralConsole.Views;
using Spectre.Console;
using Spectre.Console.Rendering;

namespace EphemeralConsole.Ui;

/// <summary>
/// Renders any <see cref="IResourceView"/> as a k9s-style table and routes keys to the view's actions.
/// It never mentions a specific resource.
/// </summary>
public sealed class ResourceScreen(IResourceView view) : IScreen, IFilterable
{
    private static readonly KeyHint[] BaseHints =
    [
        new("</>", "Filter"),
        new("<:>", "Command"),
        new("<esc>", "Back"),
        new("<j/k>", "Move"),
        new("<g/G>", "Top/Bottom"),
    ];

    private volatile IReadOnlyList<ResourceRow> _rows = [];
    private string _filter = "";
    private int _scope, _selected, _offset, _page = 10;

    public string Title => view.Title;

    public string Filter
    {
        get => _filter;
        set { _filter = value; _selected = 0; _offset = 0; }
    }

    public IReadOnlyList<KeyHint> Menu => view.Scopes
        .Take(10)
        .Select((s, i) => new KeyHint($"<{i}>", s.Name, i == _scope))
        .ToList();

    public IReadOnlyList<KeyHint> Hints => view.Actions
        .Select(a => new KeyHint(a.Key.Label, a.Description))
        .Concat(BaseHints)
        .ToList();

    public async Task RefreshAsync(CancellationToken ct) => _rows = await view.LoadAsync(ct);

    // ───────────── data ─────────────

    private ScopeDef CurrentScope => view.Scopes[Math.Clamp(_scope, 0, view.Scopes.Count - 1)];

    private List<ResourceRow> Visible() => _rows
        .Where(CurrentScope.Matches)
        .Where(r => _filter.Length == 0 ||
                    r.Cells.Any(c => c.Text.Contains(_filter, StringComparison.OrdinalIgnoreCase)))
        .ToList();

    private static string CellText(ResourceRow r, int col) => col < r.Cells.Count ? r.Cells[col].Text : "";

    private static string CellColor(ResourceRow r, int col) =>
        col < r.Cells.Count ? r.Cells[col].Color ?? "white" : "white";

    // ───────────── input ─────────────

    public bool HandleKey(ConsoleKeyInfo k, IScreenHost host)
    {
        if (k.Key == ConsoleKey.Escape)
        {
            if (_filter.Length == 0) return false; // nothing to clear: let the shell go back
            Filter = "";
            return true;
        }

        var rows = Visible();

        // The view's own actions win over built-in keys (except the shell's "/" and ":").
        foreach (var action in view.Actions)
        {
            if (!action.Key.Matches(k)) continue;

            var selected = rows.Count == 0 ? null : rows[Math.Clamp(_selected, 0, rows.Count - 1)];
            if (selected is null && action.RequiresSelection)
            {
                host.Flash("nothing selected", error: true);
                return true;
            }

            _ = RunAction(action, new ActionContext(selected, host), host);
            return true;
        }

        switch (k.KeyChar)
        {
            case 'j': _selected++; return true;
            case 'k': _selected--; return true;
            case 'g': _selected = 0; return true;
            case 'G': _selected = rows.Count - 1; return true;
            case >= '0' and <= '9':
                var idx = k.KeyChar - '0';
                if (idx < view.Scopes.Count) { _scope = idx; _selected = 0; _offset = 0; }
                return true;
        }

        switch (k.Key)
        {
            case ConsoleKey.UpArrow: _selected--; return true;
            case ConsoleKey.DownArrow: _selected++; return true;
            case ConsoleKey.PageUp: _selected -= _page; return true;
            case ConsoleKey.PageDown: _selected += _page; return true;
            case ConsoleKey.Home: _selected = 0; return true;
            case ConsoleKey.End: _selected = rows.Count - 1; return true;
        }

        return false;
    }

    private static async Task RunAction(ViewAction action, ActionContext ctx, IScreenHost host)
    {
        try { await action.Execute(ctx); }
        catch (Exception ex) { host.Flash(ex.Message, error: true); }
    }

    // ───────────── rendering ─────────────

    public IRenderable Render(RenderArea area)
    {
        var rows = Visible();
        _selected = Math.Clamp(_selected, 0, Math.Max(0, rows.Count - 1));

        _page = Math.Max(1, area.Height - 3); // panel borders (2) + column header line (1)
        if (_selected < _offset) _offset = _selected;
        if (_selected >= _offset + _page) _offset = _selected - _page + 1;
        _offset = Math.Max(0, Math.Min(_offset, Math.Max(0, rows.Count - _page)));

        var cols = view.Columns;
        var inner = Math.Max(30, area.Width - 4); // 2 borders + 2 padding
        var widths = ColumnWidths(rows, inner);

        var lines = new List<IRenderable>
        {
            Line(string.Concat(cols.Select((c, i) =>
                $"[bold white]{Markup.Escape(Fit(HeaderText(c), widths[i], c.RightAligned))}[/]")))
        };

        for (var i = _offset; i < Math.Min(rows.Count, _offset + _page); i++)
        {
            var row = rows[i];

            if (i == _selected)
            {
                // Pad to the full inner width so the highlight bar spans the whole row.
                var plain = string.Concat(cols.Select((c, ci) => Fit(CellText(row, ci), widths[ci], c.RightAligned)));
                lines.Add(Line($"[black on aqua]{Markup.Escape(plain.PadRight(inner))}[/]"));
            }
            else
            {
                lines.Add(Line(string.Concat(cols.Select((c, ci) =>
                    $"[{CellColor(row, ci)}]{Markup.Escape(Fit(CellText(row, ci), widths[ci], c.RightAligned))}[/]"))));
            }
        }

        var title = $"[aqua]{Markup.Escape(view.Title)}([bold white]{Markup.Escape(CurrentScope.Name)}[/])[/]";
        var filterTag = _filter.Length > 0 ? $"[aqua]</{Markup.Escape(_filter)}>[/]" : "";

        return new Panel(new Rows(lines))
        {
            Header = new PanelHeader($"{title}{filterTag}[aqua][[{rows.Count}]][/]", Justify.Center),
            Border = BoxBorder.Rounded,
            BorderStyle = new Style(Color.Aqua),
            Padding = new Padding(1, 0, 1, 0),
            Expand = true,
            Height = area.Height, // explicit, so the panel fills its region instead of shrinking to its content
        };

        static IRenderable Line(string markup) => new Markup(markup) { Overflow = Overflow.Crop };
    }

    // ───────────── text fitting ─────────────

    // "^" rather than "↑": some terminal/font combinations draw the arrow wider than Spectre expects and break the border.
    private static string HeaderText(ColumnDef c) => c.Sorted ? c.Header + "^" : c.Header;

    private int[] ColumnWidths(List<ResourceRow> rows, int inner)
    {
        var cols = view.Columns;
        var w = new int[cols.Count];

        for (var c = 0; c < w.Length; c++)
        {
            var col = c;
            w[c] = Math.Max(HeaderText(cols[c]).Length,
                       rows.Select(r => CellText(r, col).Length).DefaultIfEmpty(0).Max()) + 3;
        }

        if (w.Length > 1) w[^1] = Math.Max(w[^1], inner - w[..^1].Sum()); // last column soaks up the slack
        return w;
    }

    private static string Fit(string s, int width, bool right)
    {
        width = Math.Max(4, width);
        var max = width - 2; // keep a 2-char gutter
        var t = s.Length > max ? s[..(max - 1)] + "…" : s;
        return right ? t.PadLeft(max) + "  " : t.PadRight(width);
    }
}
