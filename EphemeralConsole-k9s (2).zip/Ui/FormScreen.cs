using Spectre.Console;
using Spectre.Console.Rendering;

namespace EphemeralConsole.Ui;

/// <summary>One text input. Name is both the label and the key in the submitted values.</summary>
public sealed record FormField(string Name, string Value = "", bool Required = true);

/// <summary>
/// A simple full-screen form: Tab/arrows move between fields, Enter submits, Esc cancels.
/// Submitting closes the form and runs onSubmit in the background. It swallows every key while open.
/// </summary>
public sealed class FormScreen(
    string title,
    IReadOnlyList<FormField> fields,
    Func<IReadOnlyDictionary<string, string>, Task> onSubmit,
    string? successMessage) : IScreen
{
    private const int InputWidth = 36;

    private readonly string[] _values = fields.Select(f => f.Value).ToArray();
    private int _focus;

    public string Title => title;

    public IReadOnlyList<KeyHint> Hints { get; } =
    [
        new("<tab>", "Next field"),
        new("<enter>", "Submit"),
        new("<esc>", "Cancel"),
    ];

    public IRenderable Render(RenderArea area)
    {
        var labelWidth = fields.Max(f => f.Name.Length) + 3;
        var rows = new List<IRenderable>();

        for (var i = 0; i < fields.Count; i++)
        {
            if (i > 0) rows.Add(new Markup(" "));

            var focused = i == _focus;
            var label = (fields[i].Name + (fields[i].Required ? "*" : "")).PadRight(labelWidth);

            var shown = _values[i] + (focused ? "▌" : "");
            if (shown.Length > InputWidth) shown = shown[^InputWidth..]; // keep the end visible while typing
            var box = focused
                ? $"[black on aqua] {Markup.Escape(shown.PadRight(InputWidth))} [/]"
                : $"[white on grey23] {Markup.Escape(shown.PadRight(InputWidth))} [/]";

            rows.Add(new Markup($"[orange1]{Markup.Escape(label)}[/]{box}"));
        }

        var panel = new Panel(new Rows(rows))
        {
            Header = new PanelHeader($"[aqua]{Markup.Escape(title)}[/]", Justify.Center),
            Border = BoxBorder.Rounded,
            BorderStyle = new Style(Color.Aqua),
            Padding = new Padding(3, 1, 3, 1),
            Width = Math.Min(area.Width - 2, labelWidth + InputWidth + 2 + 8),
        };

        var panelHeight = fields.Count * 2 - 1 + 2 + 2; // field lines + gaps, padding, borders
        var top = Math.Max(0, (area.Height - panelHeight) / 2);
        return new Padder(Align.Center(panel), new Padding(0, top, 0, 0));
    }

    public bool HandleKey(ConsoleKeyInfo k, IScreenHost host)
    {
        switch (k.Key)
        {
            case ConsoleKey.Escape:
                host.Pop();
                break;

            case ConsoleKey.Enter:
                Submit(host);
                break;

            case ConsoleKey.Tab when k.Modifiers.HasFlag(ConsoleModifiers.Shift):
            case ConsoleKey.UpArrow:
                _focus = (_focus - 1 + fields.Count) % fields.Count;
                break;

            case ConsoleKey.Tab:
            case ConsoleKey.DownArrow:
                _focus = (_focus + 1) % fields.Count;
                break;

            case ConsoleKey.Backspace:
                if (_values[_focus].Length > 0) _values[_focus] = _values[_focus][..^1];
                break;

            default:
                if (!char.IsControl(k.KeyChar)) _values[_focus] += k.KeyChar;
                break;
        }

        return true; // modal: ":" etc. are typed into the field, not treated as commands
    }

    private void Submit(IScreenHost host)
    {
        for (var i = 0; i < fields.Count; i++)
        {
            if (fields[i].Required && string.IsNullOrWhiteSpace(_values[i]))
            {
                _focus = i;
                host.Flash($"{fields[i].Name} is required", error: true);
                return;
            }
        }

        var values = fields
            .Select((f, i) => (f.Name, Value: _values[i]))
            .ToDictionary(x => x.Name, x => x.Value);

        host.Pop();
        host.RunInBackground(() => onSubmit(values), successMessage);
    }
}
