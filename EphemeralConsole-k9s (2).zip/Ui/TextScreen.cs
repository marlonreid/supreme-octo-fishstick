using Spectre.Console;
using Spectre.Console.Rendering;

namespace EphemeralConsole.Ui;

/// <summary>A scrollable page of text with no headers or table, like k9s' describe view.</summary>
public sealed class TextScreen(string title, string text) : IScreen
{
    private readonly string[] _lines = text.ReplaceLineEndings("\n").Split('\n');
    private int _offset, _page = 10;

    public string Title => title;

    public IReadOnlyList<KeyHint> Hints { get; } =
    [
        new("<j/k>", "Scroll"),
        new("<g/G>", "Top/Bottom"),
        new("<esc>", "Back"),
    ];

    public IRenderable Render(RenderArea area)
    {
        _page = Math.Max(1, area.Height - 2); // panel borders
        _offset = Math.Clamp(_offset, 0, Math.Max(0, _lines.Length - _page));

        return new Panel(new Rows(_lines.Skip(_offset).Take(_page).Select(Colour)))
        {
            Header = new PanelHeader($"[aqua]{Markup.Escape(title)}[/]", Justify.Center),
            Border = BoxBorder.Rounded,
            BorderStyle = new Style(Color.Aqua),
            Padding = new Padding(1, 0, 1, 0),
            Expand = true,
            Height = area.Height,
        };
    }

    public bool HandleKey(ConsoleKeyInfo k, IScreenHost host)
    {
        switch (k.KeyChar)
        {
            case 'j': _offset++; return true;
            case 'k': _offset--; return true;
            case 'g': _offset = 0; return true;
            case 'G': _offset = _lines.Length; return true; // clamped on render
            case 'q' or 'Q': host.Pop(); return true;
        }

        switch (k.Key)
        {
            case ConsoleKey.UpArrow: _offset--; return true;
            case ConsoleKey.DownArrow: _offset++; return true;
            case ConsoleKey.PageUp: _offset -= _page; return true;
            case ConsoleKey.PageDown: _offset += _page; return true;
            case ConsoleKey.Home: _offset = 0; return true;
            case ConsoleKey.End: _offset = _lines.Length; return true;
            case ConsoleKey.Escape: host.Pop(); return true;
        }

        return false; // let ":" through to the shell
    }

    /// <summary>"Key: value" lines get a coloured key, like YAML in k9s.</summary>
    private static IRenderable Colour(string line)
    {
        var i = line.IndexOf(':');
        var markup = i > 0
            ? $"[orange1]{Markup.Escape(line[..(i + 1)])}[/][white]{Markup.Escape(line[(i + 1)..])}[/]"
            : $"[white]{Markup.Escape(line)}[/]";

        return new Markup(markup) { Overflow = Overflow.Crop };
    }
}
