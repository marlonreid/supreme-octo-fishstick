# KeycloakPoc — Blazor + EF Core In-Memory + Keycloak

Minimal POC showing:
- Blazor Web App (Interactive Server) on .NET 10
- EF Core in-memory Users table (seeded with 4 dummy users)
- Keycloak OIDC authentication (code flow + cookies)
- `/claims` page — shows your JWT claims alongside your matching DB record
- `/users` page — lists all users in the in-memory DB
- `/api/me` — raw JSON endpoint (claims + DB user), requires auth
- Configurable background/header colour per instance via `appsettings.json`

---

## Prerequisites

- [.NET 10 SDK](https://dotnet.microsoft.com/download) (use `--prerelease` if 10.x is still preview)
- A running Keycloak instance

---

## Keycloak Setup

1. Create a **Realm** — e.g. `poc`
2. Create a **Client** — e.g. `blazor-poc`
   - Client authentication: **ON** (confidential)
   - Valid redirect URIs: `https://localhost:5001/*` and `http://localhost:5000/*`
   - Valid post-logout redirect URIs: same
3. Copy the **Client Secret** from the Credentials tab
4. Create a **test user** whose username matches one of the seeded names:
   `alice`, `bob`, `charlie`, or `diana`

---

## Configuration

Edit `appsettings.json`:

```json
{
  "Keycloak": {
    "Authority": "http://localhost:8080/realms/poc",
    "ClientId": "blazor-poc",
    "ClientSecret": "your-secret-here",
    "RequireHttps": "false"
  },
  "UiSettings": {
    "AppName": "App Instance A",
    "BackgroundColor": "#e8f4fd",
    "HeaderColor": "#1565c0"
  }
}
```

### Running multiple instances with different colours

Copy the project or override via env vars / a separate `appsettings.InstanceB.json`:

```bash
# Instance A (blue)
dotnet run --urls "https://localhost:5001"

# Instance B (green) — override via env vars
UiSettings__BackgroundColor="#e8f5e9" \
UiSettings__HeaderColor="#2e7d32" \
UiSettings__AppName="App Instance B" \
dotnet run --urls "https://localhost:5003"
```

---

## Running

```bash
cd KeycloakPoc
dotnet restore
dotnet run
```

Then visit `https://localhost:5001` (or whatever port .NET assigns).

---

## Package Notes

EF Core and OpenIdConnect packages are pinned to `9.*` in the `.csproj` — these are
fully compatible with .NET 10. If you want the .NET 10 native packages, change to
`10.*` and run `dotnet restore --prerelease` if they are still in preview.

---

## Endpoints

| Route        | Description                                      |
|--------------|--------------------------------------------------|
| `/`          | Home — auth status + links                       |
| `/login`     | Triggers Keycloak OIDC challenge                 |
| `/logout`    | Signs out of cookie + Keycloak session           |
| `/claims`    | JWT claims + matching DB user (auth required)    |
| `/users`     | All seeded DB users (auth required)              |
| `/api/me`    | JSON: claims + dbUser (auth required)            |

---

## Seeded Users

| Username | Email                  | Role  | Department  |
|----------|------------------------|-------|-------------|
| alice    | alice@example.com      | Admin | Engineering |
| bob      | bob@example.com        | User  | Marketing   |
| charlie  | charlie@example.com    | User  | Support     |
| diana    | diana@example.com      | Admin | Engineering |

The `/claims` page matches `preferred_username` from your Keycloak token against
the `Username` column in the in-memory DB.
