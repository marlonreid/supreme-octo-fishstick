using KeycloakPoc.Components;
using KeycloakPoc.Data;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.OpenIdConnect;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Protocols.OpenIdConnect;

var builder = WebApplication.CreateBuilder(args);

// ── Blazor ────────────────────────────────────────────────────────────────────
builder.Services.AddRazorComponents()
    .AddInteractiveServerComponents();

builder.Services.AddCascadingAuthenticationState();
builder.Services.AddHttpContextAccessor();

// ── EF Core in-memory ─────────────────────────────────────────────────────────
builder.Services.AddDbContext<AppDbContext>(opt =>
    opt.UseInMemoryDatabase("PocDb"));

// ── Keycloak OIDC ─────────────────────────────────────────────────────────────
var kc = builder.Configuration.GetSection("Keycloak");

builder.Services.AddAuthentication(opt =>
{
    opt.DefaultScheme = CookieAuthenticationDefaults.AuthenticationScheme;
    opt.DefaultChallengeScheme = OpenIdConnectDefaults.AuthenticationScheme;
})
.AddCookie(opt =>
{
    opt.Cookie.Name = "keycloak_poc";
    opt.LoginPath = "/login";
})
.AddOpenIdConnect(opt =>
{
    opt.Authority = kc["Authority"];   // e.g. http://localhost:8080/realms/poc
    opt.ClientId = kc["ClientId"];
    opt.ClientSecret = kc["ClientSecret"];
    opt.ResponseType = OpenIdConnectResponseType.Code;
    opt.SaveTokens = true;
    opt.GetClaimsFromUserInfoEndpoint = true;
    opt.RequireHttpsMetadata = bool.Parse(kc["RequireHttps"] ?? "true");

    opt.Scope.Clear();
    opt.Scope.Add("openid");
    opt.Scope.Add("profile");
    opt.Scope.Add("email");

    // Map Keycloak's preferred_username → ClaimTypes.Name
    opt.TokenValidationParameters.NameClaimType = "preferred_username";
});

builder.Services.AddAuthorization();

var app = builder.Build();

// ── Seed ──────────────────────────────────────────────────────────────────────
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
    db.Users.AddRange(
        new AppUser { Id = 1, Username = "alice",   Email = "alice@example.com",   Role = "Admin", Department = "Engineering" },
        new AppUser { Id = 2, Username = "bob",     Email = "bob@example.com",     Role = "User",  Department = "Marketing"   },
        new AppUser { Id = 3, Username = "charlie", Email = "charlie@example.com", Role = "User",  Department = "Support"     },
        new AppUser { Id = 4, Username = "diana",   Email = "diana@example.com",   Role = "Admin", Department = "Engineering" }
    );
    db.SaveChanges();
}

// ── Middleware ─────────────────────────────────────────────────────────────────
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();
app.UseAuthentication();
app.UseAuthorization();
app.UseAntiforgery();

// ── Auth endpoints ────────────────────────────────────────────────────────────
app.MapGet("/login", () =>
    TypedResults.Challenge(
        new AuthenticationProperties { RedirectUri = "/" },
        [OpenIdConnectDefaults.AuthenticationScheme]));

app.MapGet("/logout", async (HttpContext ctx) =>
{
    await ctx.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
    await ctx.SignOutAsync(OpenIdConnectDefaults.AuthenticationScheme,
        new AuthenticationProperties { RedirectUri = "/" });
});

// ── /api/me — claims + DB user ────────────────────────────────────────────────
app.MapGet("/api/me", async (HttpContext ctx, AppDbContext db) =>
{
    if (ctx.User.Identity?.IsAuthenticated != true)
        return Results.Unauthorized();

    var claims = ctx.User.Claims
        .Select(c => new { c.Type, c.Value })
        .OrderBy(c => c.Type)
        .ToList();

    var username = ctx.User.Identity.Name
                   ?? ctx.User.FindFirst("preferred_username")?.Value;

    var dbUser = username is not null
        ? await db.Users.FirstOrDefaultAsync(u => u.Username == username)
        : null;

    return Results.Ok(new
    {
        authenticated = true,
        identityName = ctx.User.Identity.Name,
        claims,
        dbUser
    });
}).RequireAuthorization();

// ── Blazor ────────────────────────────────────────────────────────────────────
app.MapRazorComponents<App>()
    .AddInteractiveServerRenderMode();

app.Run();
