# Velero + Kopia — vCluster Backup & Restore
# PowerShell Core (pwsh) on Windows
# Backs up an entire vCluster namespace (control plane + PVCs) to Azure Blob Storage
# Restores into a new named environment

---

## What This Does

Velero backs up the **host namespace** for a vCluster — e.g. `vcluster-sleepy-cat`.
That namespace contains:
- The vCluster control plane StatefulSet (virtual etcd = all k8s state inside the vCluster)
- The synced PVCs (your Postgres data)
- All other host-side resources Velero synced up

Kopia handles PVC data as file-level backup — no CSI snapshots needed, works with local-path provisioner.

Restore target is a **new namespace** — so `sleepy-cat` → `banana-jam` without touching the original.

---

## Prerequisites

- PowerShell Core (`pwsh`) installed
- `kubectl` available and pointed at your Rancher Desktop cluster
- `helm` installed
- Azure CLI (`az`) installed: https://learn.microsoft.com/en-us/cli/azure/install-azure-cli-windows
- Velero CLI installed (step 1 below)

---

## Step 1 — Install the Velero CLI

```powershell
# Download the latest Velero CLI for Windows
$veleroVersion = "1.13.2"
$url = "https://github.com/vmware-tanzu/velero/releases/download/v$veleroVersion/velero-v$veleroVersion-windows-amd64.zip"
$zipPath = "$env:TEMP\velero.zip"

Invoke-WebRequest -Uri $url -OutFile $zipPath
Expand-Archive -Path $zipPath -DestinationPath "$env:TEMP\velero-extract" -Force

# Copy to somewhere on your PATH — adjust if you prefer a different location
Copy-Item "$env:TEMP\velero-extract\velero-v$veleroVersion-windows-amd64\velero.exe" `
    -Destination "C:\Windows\System32\velero.exe"

# Confirm
velero version --client-only
```

---

## Step 2 — Create Azure Storage Account

```powershell
# Set these to your preference
$RESOURCE_GROUP   = "rg-velero-poc"
$LOCATION         = "uksouth"
$STORAGE_ACCOUNT  = "veleropocstorage"   # Must be globally unique, 3-24 lowercase alphanumeric
$BLOB_CONTAINER   = "velero-backups"
$SUBSCRIPTION_ID  = (az account show --query id -o tsv)

# Login if not already
az login

# Create resource group
az group create `
    --name $RESOURCE_GROUP `
    --location $LOCATION

# Create storage account
# Standard_LRS is cheapest — fine for a POC
az storage account create `
    --name $STORAGE_ACCOUNT `
    --resource-group $RESOURCE_GROUP `
    --location $LOCATION `
    --sku Standard_LRS `
    --kind StorageV2 `
    --access-tier Hot

# Create the blob container
az storage container create `
    --name $BLOB_CONTAINER `
    --account-name $STORAGE_ACCOUNT

# Get the storage account key
$STORAGE_KEY = (az storage account keys list `
    --account-name $STORAGE_ACCOUNT `
    --resource-group $RESOURCE_GROUP `
    --query "[0].value" -o tsv)

Write-Host "Storage Account : $STORAGE_ACCOUNT"
Write-Host "Container       : $BLOB_CONTAINER"
Write-Host "Key             : $STORAGE_KEY"
# Keep this key — you need it in Step 4
```

---

## Step 3 — Create the Velero Credentials File

Velero needs a credentials file for Azure Blob access.
We use the storage account key directly — no Azure AD, no managed identity, no fuss.

```powershell
# Set your values from Step 2
$STORAGE_ACCOUNT = "veleropocstorage"
$STORAGE_KEY     = "YOUR_KEY_FROM_STEP_2"   # paste the key here

$credsContent = @"
AZURE_STORAGE_ACCOUNT_ACCESS_KEY=$STORAGE_KEY
AZURE_CLOUD_NAME=AzurePublicCloud
"@

$credsContent | Out-File -FilePath "$env:TEMP\velero-credentials.txt" -Encoding ascii -NoNewline

Write-Host "Credentials written to $env:TEMP\velero-credentials.txt"
```

---

## Step 4 — Install Velero into the Host Cluster

```powershell
$STORAGE_ACCOUNT = "veleropocstorage"
$BLOB_CONTAINER  = "velero-backups"
$SUBSCRIPTION_ID = (az account show --query id -o tsv)

velero install `
    --provider azure `
    --plugins velero/velero-plugin-for-microsoft-azure:v1.10.1 `
    --bucket $BLOB_CONTAINER `
    --secret-file "$env:TEMP\velero-credentials.txt" `
    --backup-location-config "storageAccount=$STORAGE_ACCOUNT,subscriptionId=$SUBSCRIPTION_ID,storageAccountKeyEnvVar=AZURE_STORAGE_ACCOUNT_ACCESS_KEY" `
    --snapshot-location-config "apiTimeout=5m" `
    --use-node-agent `
    --default-volumes-to-fs-backup `
    --uploader-type kopia

# Wait for Velero to be ready
kubectl rollout status deployment/velero -n velero

# Confirm backup storage location is available
velero backup-location get
# Status should show "Available"
```

**What those flags do:**
- `--use-node-agent` — deploys a DaemonSet that Kopia uses to access node-level volume mounts
- `--default-volumes-to-fs-backup` — tells Velero to use Kopia file-level backup for ALL PVCs automatically (no annotation needed)
- `--uploader-type kopia` — uses Kopia instead of the older Restic engine

---

## Step 5 — Annotate the vCluster Namespace

Velero needs to know which namespaces to include PVC backups for.
The vCluster StatefulSet PVC is in the **host** namespace.

```powershell
# This is done once per environment when you create it
# Replace "sleepy-cat" with your environment name

$ENV_NAME  = "sleepy-cat"
$NAMESPACE = "vcluster-$ENV_NAME"

kubectl annotate namespace $NAMESPACE `
    velero.io/exclude-from-backup="false" --overwrite

Write-Host "Namespace $NAMESPACE is included in Velero backups"
```

> Note: By default Velero backs up all namespaces unless excluded.
> The annotation above is a no-op but makes intent explicit.
> You can exclude namespaces you don't care about instead.

---

## Step 6 — Back Up an Environment (Put It On Ice)

```powershell
# Freeze sleepy-cat — scales down the vCluster so data is quiesced before backup

$ENV_NAME  = "sleepy-cat"
$NAMESPACE = "vcluster-$ENV_NAME"
$TIMESTAMP = (Get-Date -Format "yyyyMMdd-HHmmss")
$BACKUP_NAME = "$ENV_NAME-$TIMESTAMP"

Write-Host "==> Pausing vCluster '$ENV_NAME'"
vcluster pause $ENV_NAME --namespace $NAMESPACE

Write-Host "==> Waiting for vCluster StatefulSet to scale to 0"
kubectl rollout status statefulset/$ENV_NAME -n $NAMESPACE --timeout=60s 2>$null
# It won't reach "complete" because it's scaling to 0 — just wait a moment
Start-Sleep -Seconds 10

Write-Host "==> Creating backup: $BACKUP_NAME"
velero backup create $BACKUP_NAME `
    --include-namespaces $NAMESPACE `
    --default-volumes-to-fs-backup `
    --wait

Write-Host "==> Backup status"
velero backup describe $BACKUP_NAME --details

Write-Host ""
Write-Host "==> Resuming vCluster '$ENV_NAME'"
vcluster resume $ENV_NAME --namespace $NAMESPACE

Write-Host ""
Write-Host "Backup '$BACKUP_NAME' complete."
Write-Host "The environment is back online. Original is untouched."
```

---

## Step 7 — Restore Into a New Environment

This restores `sleepy-cat`'s backup into a new namespace `vcluster-banana-jam`.
The original `sleepy-cat` is untouched.

```powershell
$SOURCE_ENV   = "sleepy-cat"
$TARGET_ENV   = "banana-jam"
$BACKUP_NAME  = "sleepy-cat-20240617-143022"   # replace with your actual backup name

$SOURCE_NS = "vcluster-$SOURCE_ENV"
$TARGET_NS = "vcluster-$TARGET_ENV"

# List available backups if you need to find the name
# velero backup get

Write-Host "==> Creating target namespace: $TARGET_NS"
kubectl create namespace $TARGET_NS --dry-run=client -o yaml | kubectl apply -f -

Write-Host "==> Restoring '$BACKUP_NAME' into namespace '$TARGET_NS'"
velero restore create "$TARGET_ENV-restore" `
    --from-backup $BACKUP_NAME `
    --namespace-mappings "${SOURCE_NS}:${TARGET_NS}" `
    --wait

Write-Host "==> Restore status"
velero restore describe "$TARGET_ENV-restore" --details

Write-Host ""
Write-Host "==> Waiting for vCluster pods to come up in $TARGET_NS"
kubectl rollout status statefulset/$SOURCE_ENV -n $TARGET_NS --timeout=120s

# The StatefulSet name inside the restored namespace will still be the original name.
# Rename the vcluster context to match the target environment:
Write-Host ""
Write-Host "==> Connecting to restored vCluster"
vcluster connect $TARGET_ENV --namespace $TARGET_NS
```

> **Note on StatefulSet name:** Velero restores the StatefulSet with its original name (`sleepy-cat`).
> The vCluster CLI uses the StatefulSet name to connect. So after restore you connect with:
> `vcluster connect sleepy-cat --namespace vcluster-banana-jam`
> See the helper script in Step 9 — it handles this for you.

---

## Step 8 — Verify the Restore

```powershell
$TARGET_ENV = "banana-jam"
$TARGET_NS  = "vcluster-$TARGET_ENV"

# Connect into the restored vCluster (StatefulSet name is still the source name)
vcluster connect sleepy-cat --namespace $TARGET_NS

# In a new terminal or after connect modifies context:
kubectl get pods        # Should see postgres + weatherapi
kubectl get pvc         # Should see the Postgres PVC

# Test the API via the restored environment's ingress
# (you'll need a hosts entry for banana-jam.vpoc.local first)
curl http://banana-jam.vpoc.local/weather/statuses
```

Add the hosts entry:
```powershell
# Run as Administrator
Add-Content -Path "C:\Windows\System32\drivers\etc\hosts" -Value "127.0.0.1  banana-jam.vpoc.local"
```

---

## Step 9 — Helper Scripts

Save these as `.ps1` files for repeatable demo use.

### backup-env.ps1

```powershell
param(
    [Parameter(Mandatory)][string]$EnvName
)

$namespace   = "vcluster-$EnvName"
$timestamp   = (Get-Date -Format "yyyyMMdd-HHmmss")
$backupName  = "$EnvName-$timestamp"

Write-Host "==> Pausing vCluster '$EnvName'"
vcluster pause $EnvName --namespace $namespace
Start-Sleep -Seconds 10

Write-Host "==> Creating backup: $backupName"
velero backup create $backupName `
    --include-namespaces $namespace `
    --default-volumes-to-fs-backup `
    --wait

velero backup describe $backupName

Write-Host "==> Resuming vCluster '$EnvName'"
vcluster resume $EnvName --namespace $namespace

Write-Host ""
Write-Host "✅ Backup complete: $backupName"
```

### restore-env.ps1

```powershell
param(
    [Parameter(Mandatory)][string]$BackupName,
    [Parameter(Mandatory)][string]$TargetEnv
)

# Infer source env name from backup name (everything before the timestamp)
$sourceEnv  = $BackupName -replace "-\d{8}-\d{6}$", ""
$sourceNS   = "vcluster-$sourceEnv"
$targetNS   = "vcluster-$TargetEnv"

Write-Host "==> Restoring '$BackupName' → '$TargetEnv'"
Write-Host "    Source namespace : $sourceNS"
Write-Host "    Target namespace : $targetNS"

kubectl create namespace $targetNS --dry-run=client -o yaml | kubectl apply -f -

velero restore create "$TargetEnv-restore" `
    --from-backup $BackupName `
    --namespace-mappings "${sourceNS}:${targetNS}" `
    --wait

velero restore describe "$TargetEnv-restore"

Write-Host ""
Write-Host "==> Connecting to restored environment"
Write-Host "    StatefulSet name is '$sourceEnv' inside namespace '$targetNS'"
vcluster connect $sourceEnv --namespace $targetNS

Write-Host ""
Write-Host "✅ Restore complete."
Write-Host "   Add hosts entry if needed:"
Write-Host "   127.0.0.1  $TargetEnv.vpoc.local"
```

Usage:
```powershell
# Backup
.\backup-env.ps1 -EnvName sleepy-cat

# Restore to new environment
.\restore-env.ps1 -BackupName "sleepy-cat-20240617-143022" -TargetEnv banana-jam

# List backups
velero backup get
```

---

## Useful Commands

```powershell
# List all backups
velero backup get

# Inspect a backup (shows what was included)
velero backup describe <backup-name> --details

# List restores
velero restore get

# Check Velero logs if something goes wrong
kubectl logs deployment/velero -n velero

# Check node-agent (Kopia) logs
kubectl logs daemonset/node-agent -n velero

# Check backup storage is reachable
velero backup-location get

# Delete a backup (also removes from blob storage)
velero backup delete <backup-name>
```

---

## Troubleshooting

**`backup-location` shows `Unavailable`**
- Check the storage key is correct in the Velero secret:
  ```powershell
  kubectl get secret cloud-credentials -n velero -o jsonpath='{.data.cloud}' | `
      [System.Text.Encoding]::UTF8.GetString([System.Convert]::FromBase64String($_))
  ```
- Confirm the container exists in Azure Portal

**PVC data not included in backup**
- Confirm `--default-volumes-to-fs-backup` was passed at install time
- Check node-agent DaemonSet is running: `kubectl get ds -n velero`

**Restore pods stuck in Pending after restore**
- The PVC may have a `volumeName` binding to the old PV. Delete the PVC and let the restored pod recreate it:
  ```powershell
  kubectl delete pvc <pvc-name> -n vcluster-banana-jam
  ```

**StatefulSet name mismatch after restore**
- The restored StatefulSet keeps the original name. Use:
  ```powershell
  vcluster connect sleepy-cat --namespace vcluster-banana-jam
  ```
  not `vcluster connect banana-jam`.
