# vCluster POC — Demo Script

**Theme:** One host cluster. Many isolated environments. Full lifecycle: create, use, snapshot, destroy, restore.

---

## Setup (before the audience arrives)

```bash
# 1. Build and load the image — do this once
./scripts/build-and-load.sh

# 2. Add hosts entries
echo "127.0.0.1  dev.vpoc.local staging.vpoc.local restored.vpoc.local" | sudo tee -a /etc/hosts

# 3. Confirm Traefik is running on the host
kubectl get pods -n kube-system | grep traefik

# 4. Have two terminal windows open:
#    Terminal A — host cluster view
#    Terminal B — active demo commands
```

---

## Act 1 — The Problem (60 seconds)

**Say:** "Every team wants their own environment. But shared clusters are a mess — one team's bad deployment takes out another's database, namespaces give you soft isolation at best, and you can't give teams real cluster-admin without risking the whole thing."

Show the host cluster (Terminal A):

```bash
kubectl get namespaces
kubectl get nodes
```

**Say:** "One node. One cluster. We're going to create fully isolated Kubernetes environments on top of it, each with their own control plane, their own networking, their own storage."

---

## Act 2 — Create the Dev Environment (3 minutes)

```bash
./scripts/create-env.sh dev
```

While it runs, narrate:
- vCluster is spinning up a **virtual k3s control plane** inside a host namespace
- The host sees it as a StatefulSet — not a VM, not a node
- Postgres will get a **real PVC** synced from the virtual cluster to the host storage provisioner
- The Ingress object will be synced **up** to host Traefik automatically

Once done:

```bash
# Host view — what does the host actually see?
kubectl get all -n vcluster-dev
kubectl get pvc -n vcluster-dev
kubectl get ingress -n vcluster-dev
```

**Say:** "The host sees one StatefulSet for the vCluster control plane, the synced PVC, and the synced Ingress. It knows nothing about the pods inside."

```bash
# Now connect to the vCluster and see the full picture inside
./scripts/connect-env.sh dev
kubectl get pods
kubectl get pvc
kubectl get ingress
```

**Say:** "Inside the vCluster, we have a real Postgres pod with a PVC, a WeatherApi pod, and a proper Ingress. Full Kubernetes API. Teams can do whatever they want here."

Disconnect:
```bash
# Ctrl+C or exit
```

---

## Act 3 — The App Works, End to End (2 minutes)

```bash
# Default statuses seeded from DB migration
curl http://dev.vpoc.local/weather/statuses | jq

# Get a forecast — statuses come from Postgres
curl http://dev.vpoc.local/weather/getforecast | jq
```

**Say:** "Traefik on the host is routing `dev.vpoc.local` to our app inside the vCluster — no port-forwarding, no NodePort. Just the synced Ingress."

Now mutate the data:

```bash
# Add a dramatic status
curl -X POST http://dev.vpoc.local/weather/statuses \
  -H "Content-Type: application/json" \
  -d '{"summary": "Apocalyptic"}' | jq

# Add another
curl -X POST http://dev.vpoc.local/weather/statuses \
  -H "Content-Type: application/json" \
  -d '{"summary": "Scorching"}' | jq

# Confirm they appear in forecasts
curl http://dev.vpoc.local/weather/getforecast | jq
```

```bash
# Show the current state of the DB
curl http://dev.vpoc.local/weather/statuses | jq
```

**Say:** "We now have 7 statuses. This data lives in Postgres, on a PVC, inside the vCluster. Remember this — it matters in a moment."

---

## Act 4 — Snapshot (2 minutes)

**Say:** "This is the killer feature. We're going to snapshot the entire environment — control plane state AND persistent data — in one operation."

```bash
./scripts/snapshot-env.sh dev before-chaos
```

**Say:** "The snapshot captures etcd and the PVC. The environment is paused for a few seconds, then resumed. The whole thing takes under a minute."

Confirm it worked:

```bash
vcluster snapshot list --namespace vcluster-dev
```

---

## Act 5 — Break Something (1 minute)

**Say:** "Now let's simulate a destructive change. Maybe a junior dev ran a bad migration. Maybe a test suite wiped the table."

```bash
# Delete all statuses
curl http://dev.vpoc.local/weather/statuses | jq  # see them
curl -X DELETE http://dev.vpoc.local/weather/statuses/1
curl -X DELETE http://dev.vpoc.local/weather/statuses/2
curl -X DELETE http://dev.vpoc.local/weather/statuses/3
curl -X DELETE http://dev.vpoc.local/weather/statuses/4
curl -X DELETE http://dev.vpoc.local/weather/statuses/5
curl -X DELETE http://dev.vpoc.local/weather/statuses/6
curl -X DELETE http://dev.vpoc.local/weather/statuses/7

# API still works but returns empty
curl http://dev.vpoc.local/weather/statuses | jq  # []
curl http://dev.vpoc.local/weather/getforecast | jq  # empty forecasts
```

**Say:** "Database is empty. Environment is broken. In a shared cluster, this is a support ticket and a rollback conversation. Here..."

---

## Act 6 — Restore (2 minutes)

```bash
./scripts/restore-env.sh dev before-chaos
```

Wait ~30 seconds, then:

```bash
# Data is back
curl http://dev.vpoc.local/weather/statuses | jq

# Forecasts work again
curl http://dev.vpoc.local/weather/getforecast | jq
```

**Say:** "Full restore. Control plane state, Kubernetes objects, Postgres data. One command. Under a minute. No ticket required."

---

## Act 7 — Parallel Environments (2 minutes)

**Say:** "Now the real point. Let's spin up a second environment, completely isolated."

```bash
./scripts/create-env.sh staging
```

While it provisions, show the host:

```bash
kubectl get namespaces
kubectl get statefulsets -A | grep vcluster
kubectl get pvc -A | grep vcluster
```

**Say:** "Two vClusters. Two control planes. Two Postgres instances. Two PVCs. All on one node."

Once staging is up:

```bash
# Add a staging-specific status
curl -X POST http://staging.vpoc.local/weather/statuses \
  -H "Content-Type: application/json" \
  -d '{"summary": "Staging Only"}' | jq

# Dev and staging are isolated
echo "DEV:"
curl http://dev.vpoc.local/weather/statuses | jq

echo "STAGING:"
curl http://staging.vpoc.local/weather/statuses | jq
```

**Say:** "Completely isolated. Staging has its own data, its own Kubernetes API, its own RBAC. You could give a contractor cluster-admin on staging and they cannot touch dev."

---

## Act 8 — Teardown (1 minute)

**Say:** "Cleanup is just as clean."

```bash
./scripts/delete-env.sh staging
```

```bash
# Host is back to just one vCluster
kubectl get namespaces | grep vcluster
```

**Say:** "The namespace is gone, the PVC is gone, the Ingress is gone. The host cluster is no messier than before."

---

## Closing Points

- **Cost:** vClusters are lightweight. A vCluster control plane uses ~200MB RAM idle. You can run 20+ on a single node.
- **Isolation:** Real Kubernetes API isolation. Not namespaces. Teams can deploy CRDs, mess with RBAC, install operators — none of it leaks.
- **Snapshots:** Full environment snapshots including persistent data. Clone a prod snapshot into a new environment for debugging in under 5 minutes.
- **Traefik integration:** Ingress sync means zero host cluster configuration per environment. The routing just works.
- **IDP fit:** A platform team can expose a simple API (`POST /environments`) backed by a vCluster create call. Developers never touch kubectl.

---

## Cheat Sheet (keep this open during the demo)

```bash
# Create
./scripts/create-env.sh <name>

# Connect / inspect inside
./scripts/connect-env.sh <name>

# Snapshot
./scripts/snapshot-env.sh <name> <snapshot-label>

# Restore
./scripts/restore-env.sh <name> <snapshot-label>

# List snapshots
vcluster snapshot list --namespace vcluster-<name>

# Delete
./scripts/delete-env.sh <name>

# API
curl http://<name>.vpoc.local/weather/getforecast
curl http://<name>.vpoc.local/weather/statuses
curl -X POST http://<name>.vpoc.local/weather/statuses -H "Content-Type: application/json" -d '{"summary":"X"}'
curl -X DELETE http://<name>.vpoc.local/weather/statuses/<id>
```
