# vCluster POC — WeatherApi

A self-contained demo showcasing vCluster's core value proposition: isolated, ephemeral Kubernetes environments running on a single host cluster, with persistent data, snapshots, and restore.

---

## Architecture

```
Host Cluster (Rancher Desktop / k3s)
├── traefik              ← host ingress controller
│
├── vcluster-dev/        ← host namespace for "dev" environment
│   └── vCluster (k3s)
│       ├── postgres     ← Postgres + PVC (synced to host for storage)
│       └── weatherapi   ← .NET 9 minimal API
│           └── Ingress  ← synced UP to host Traefik
│
├── vcluster-staging/    ← completely isolated "staging" environment
│   └── vCluster (k3s)
│       ├── postgres     ← its own Postgres, its own PVC, its own data
│       └── weatherapi
│           └── Ingress
│
└── ... more environments, same pattern
```

**Routing:** `{env}.vpoc.local/weather/{endpoint}`

- `dev.vpoc.local/weather/getforecast`
- `staging.vpoc.local/weather/getforecast`
- `dev.vpoc.local/weather/statuses`

---

## Prerequisites

| Tool | Version | Notes |
|------|---------|-------|
| Rancher Desktop | Latest | Use `containerd` runtime |
| kubectl | 1.28+ | Bundled with Rancher Desktop |
| helm | 3.x | `brew install helm` |
| vcluster CLI | 0.20+ | `brew install loft-sh/tap/vcluster` |
| Docker | Any | For building the image |

### Install vCluster CLI

```bash
# macOS / Linux
curl -L -o vcluster "https://github.com/loft-sh/vcluster/releases/latest/download/vcluster-linux-amd64"
chmod +x vcluster && sudo mv vcluster /usr/local/bin

# Or via brew
brew install loft-sh/tap/vcluster
```

---

## Quick Start

### 1. Build and load the image

```bash
./scripts/build-and-load.sh
```

This builds `weatherapi:latest` and imports it directly into k3s's containerd runtime (bypassing Docker). The Helm chart uses `imagePullPolicy: Never` so k3s doesn't try to pull from a registry.

### 2. Add /etc/hosts entries

```bash
# Add one line per environment you intend to create
echo "127.0.0.1  dev.vpoc.local staging.vpoc.local" | sudo tee -a /etc/hosts
```

### 3. Create your first environment

```bash
./scripts/create-env.sh dev
```

This will:
- Create the host namespace `vcluster-dev`
- Spin up a vCluster inside it
- Deploy Postgres (with PVC) inside the vCluster
- Deploy WeatherApi inside the vCluster
- Sync the Ingress object up to host Traefik

### 4. Hit the API

```bash
# Get forecasts (reads from DB)
curl http://dev.vpoc.local/weather/getforecast

# List statuses
curl http://dev.vpoc.local/weather/statuses

# Add a new status
curl -X POST http://dev.vpoc.local/weather/statuses \
  -H "Content-Type: application/json" \
  -d '{"summary": "Apocalyptic"}'

# Delete a status
curl -X DELETE http://dev.vpoc.local/weather/statuses/1
```

---

## API Reference

| Method | Path | Description |
|--------|------|-------------|
| GET | `/weather/getforecast` | Returns 5 random forecasts using statuses from DB |
| GET | `/weather/statuses` | Lists all weather statuses |
| POST | `/weather/statuses` | Adds a new status `{"summary": "..."}` |
| DELETE | `/weather/statuses/{id}` | Deletes a status by id |
| GET | `/swagger` | Swagger UI |

---

## Snapshot & Restore

### Take a snapshot

```bash
./scripts/snapshot-env.sh dev
# Or with a named snapshot:
./scripts/snapshot-env.sh dev before-chaos
```

The snapshot captures the entire vCluster etcd state — all Kubernetes objects and the Postgres PVC data together.

### Restore from a snapshot

```bash
# List available snapshots
vcluster snapshot list --namespace vcluster-dev

# Restore
./scripts/restore-env.sh dev before-chaos
```

---

## Managing Multiple Environments

```bash
# Create a staging environment
./scripts/create-env.sh staging

# Each environment is completely isolated
curl http://dev.vpoc.local/weather/statuses     # dev data
curl http://staging.vpoc.local/weather/statuses  # staging data — separate DB

# Connect kubectl to a specific vCluster for debugging
./scripts/connect-env.sh dev
kubectl get pods   # ← pods inside the dev vCluster
# Ctrl+C to return to host context

# Delete an environment
./scripts/delete-env.sh staging
```

---

## Project Structure

```
vcluster-poc/
├── weatherapi/
│   ├── Dockerfile
│   └── src/WeatherApi/
│       ├── WeatherApi.csproj       (.NET 9, Npgsql EF Core)
│       ├── Program.cs
│       ├── Data/AppDbContext.cs
│       ├── Models/
│       │   ├── WeatherForecast.cs
│       │   └── WeatherStatus.cs
│       ├── Endpoints/
│       │   └── WeatherEndpoints.cs
│       └── Migrations/
├── helm/
│   ├── postgres/                   Helm chart: Postgres + PVC
│   └── weatherapi/                 Helm chart: WeatherApi + Ingress
├── vcluster-config/
│   └── vcluster-values.yaml        vCluster configuration (ingress sync, PVC sync)
├── scripts/
│   ├── build-and-load.sh
│   ├── create-env.sh
│   ├── delete-env.sh
│   ├── connect-env.sh
│   ├── snapshot-env.sh
│   └── restore-env.sh
├── DEMO.md                         Step-by-step demo script
└── README.md
```

---

## Traefik & Ingress Sync Explained

Traefik runs on the **host** cluster. Each vCluster has ingress sync enabled (`sync.toHost.ingresses: true`), which means any `Ingress` object created inside a vCluster is **automatically mirrored** to the host namespace with a prefixed name. Host Traefik picks it up and routes traffic based on the hostname rule (`{env}.vpoc.local`).

The traffic path is:

```
Browser → host Traefik → (via synced Ingress) → vCluster's weatherapi-svc → weatherapi pod
```

No NodePort, no LoadBalancer, no port-forwarding needed during the demo.

---

## Troubleshooting

**Image pull errors (ErrImagePull / ImagePullBackOff)**
```bash
# Confirm image is loaded in k3s containerd
sudo k3s ctr images list | grep weatherapi
# If missing, re-run:
./scripts/build-and-load.sh
```

**Ingress not routing (404 from Traefik)**
```bash
# Check host cluster sees the synced ingress
kubectl get ingress -A | grep weatherapi
# Check vCluster ingress
./scripts/connect-env.sh dev
kubectl get ingress
```

**Postgres not ready**
```bash
./scripts/connect-env.sh dev
kubectl get pods
kubectl logs deploy/postgres
```

**vCluster snapshot command not found**
Ensure you have vCluster CLI 0.20+:
```bash
vcluster version
```
