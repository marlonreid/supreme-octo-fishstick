namespace WeatherApi.Models;

public class WeatherStatus
{
    public int Id { get; set; }
    public string Summary { get; set; } = string.Empty;
}
