using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using WeatherApi.Data;

#nullable disable

namespace WeatherApi.Migrations;

[DbContext(typeof(AppDbContext))]
partial class AppDbContextModelSnapshot : ModelSnapshot
{
    protected override void BuildModel(ModelBuilder modelBuilder)
    {
#pragma warning disable 612, 618
        modelBuilder
            .HasAnnotation("ProductVersion", "9.0.4")
            .HasAnnotation("Relational:MaxIdentifierLength", 63);

        NpgsqlModelBuilderExtensions.UseIdentityByDefaultColumns(modelBuilder);

        modelBuilder.Entity("WeatherApi.Models.WeatherStatus", b =>
        {
            b.Property<int>("Id")
                .ValueGeneratedOnAdd()
                .HasColumnType("integer");

            NpgsqlPropertyBuilderExtensions.UseIdentityByDefaultColumn(b.Property<int>("Id"));

            b.Property<string>("Summary")
                .IsRequired()
                .HasColumnType("text");

            b.HasKey("Id");
            b.ToTable("WeatherStatuses");

            b.HasData(
                new { Id = 1, Summary = "Freezing" },
                new { Id = 2, Summary = "Bracing" },
                new { Id = 3, Summary = "Chilly" },
                new { Id = 4, Summary = "Cool" },
                new { Id = 5, Summary = "Mild" }
            );
        });
#pragma warning restore 612, 618
    }
}
