using Microsoft.EntityFrameworkCore;
using WeatherApi.Data;
using WeatherApi.Models;

namespace WeatherApi.Endpoints;

public static class WeatherEndpoints
{
    public static void MapWeatherEndpoints(this WebApplication app)
    {
        var group = app.MapGroup("/weather");

        // GET /weather/getforecast
        group.MapGet("/getforecast", async (AppDbContext db) =>
        {
            var statuses = await db.WeatherStatuses.ToListAsync();

            if (statuses.Count == 0)
                return Results.Ok(Array.Empty<WeatherForecast>());

            var forecasts = Enumerable.Range(1, 5).Select(index =>
            {
                var status = statuses[Random.Shared.Next(statuses.Count)];
                return new WeatherForecast(
                    DateOnly.FromDateTime(DateTime.Now.AddDays(index)),
                    Random.Shared.Next(-20, 55),
                    status.Summary
                );
            });

            return Results.Ok(forecasts);
        })
        .WithName("GetWeatherForecast")
        .WithOpenApi();

        // GET /weather/statuses
        group.MapGet("/statuses", async (AppDbContext db) =>
        {
            var statuses = await db.WeatherStatuses.ToListAsync();
            return Results.Ok(statuses);
        })
        .WithName("GetStatuses")
        .WithOpenApi();

        // POST /weather/statuses
        group.MapPost("/statuses", async (AppDbContext db, WeatherStatus status) =>
        {
            db.WeatherStatuses.Add(status);
            await db.SaveChangesAsync();
            return Results.Created($"/weather/statuses/{status.Id}", status);
        })
        .WithName("AddStatus")
        .WithOpenApi();

        // DELETE /weather/statuses/{id}
        group.MapDelete("/statuses/{id:int}", async (AppDbContext db, int id) =>
        {
            var status = await db.WeatherStatuses.FindAsync(id);
            if (status is null) return Results.NotFound();
            db.WeatherStatuses.Remove(status);
            await db.SaveChangesAsync();
            return Results.NoContent();
        })
        .WithName("DeleteStatus")
        .WithOpenApi();
    }
}
