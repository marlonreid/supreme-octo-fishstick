using Microsoft.EntityFrameworkCore;
using WeatherApi.Models;

namespace WeatherApi.Data;

public class AppDbContext(DbContextOptions<AppDbContext> options) : DbContext(options)
{
    public DbSet<WeatherStatus> WeatherStatuses => Set<WeatherStatus>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<WeatherStatus>().HasData(
            new WeatherStatus { Id = 1, Summary = "Freezing" },
            new WeatherStatus { Id = 2, Summary = "Bracing" },
            new WeatherStatus { Id = 3, Summary = "Chilly" },
            new WeatherStatus { Id = 4, Summary = "Cool" },
            new WeatherStatus { Id = 5, Summary = "Mild" }
        );
    }
}
