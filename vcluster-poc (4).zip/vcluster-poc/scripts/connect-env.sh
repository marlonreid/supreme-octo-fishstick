#!/usr/bin/env bash
# Usage: ./connect-env.sh <env-name>
# Opens a shell with kubectl pointed at the named vCluster.
# Ctrl+C or exit to disconnect.
set -euo pipefail

ENV_NAME="${1:?Usage: $0 <env-name>}"
NAMESPACE="vcluster-${ENV_NAME}"

echo "==> Connecting to vCluster '${ENV_NAME}' — kubectl now targets vCluster"
echo "    Press Ctrl+C to disconnect"
vcluster connect "${ENV_NAME}" --namespace "${NAMESPACE}"
