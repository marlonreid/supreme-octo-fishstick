# fix-node-agent.ps1
# Patches the Velero node-agent DaemonSet to remove the bindOptions that cause
# "invalid mount config for type volume: field bindOptions must not be specified"
# on Rancher Desktop / k3s on Windows.

Write-Host "==> Fetching current node-agent DaemonSet"
$ds = kubectl get daemonset node-agent -n velero -o json | ConvertFrom-Json

# Find and remove mountPropagation from all volumeMounts in all containers
foreach ($container in $ds.spec.template.spec.containers) {
    foreach ($mount in $container.volumeMounts) {
        if ($mount.PSObject.Properties['mountPropagation']) {
            Write-Host "    Removing mountPropagation '$($mount.mountPropagation)' from mount '$($mount.name)' in container '$($container.name)'"
            $mount.PSObject.Properties.Remove('mountPropagation')
        }
    }
}

# Also remove mountPropagation from initContainers if any
foreach ($container in $ds.spec.template.spec.initContainers) {
    foreach ($mount in $container.volumeMounts) {
        if ($mount.PSObject.Properties['mountPropagation']) {
            Write-Host "    Removing mountPropagation from initContainer '$($container.name)' mount '$($mount.name)'"
            $mount.PSObject.Properties.Remove('mountPropagation')
        }
    }
}

Write-Host "==> Applying patched DaemonSet"
$ds | ConvertTo-Json -Depth 20 | kubectl apply -f -

Write-Host "==> Restarting node-agent pods"
kubectl rollout restart daemonset/node-agent -n velero

Write-Host "==> Waiting for node-agent to be ready"
kubectl rollout status daemonset/node-agent -n velero --timeout=90s

Write-Host ""
Write-Host "==> Node-agent pod status"
kubectl get pods -n velero -l name=node-agent

Write-Host ""
Write-Host "✅ Done. Run a test backup to confirm Kopia can access volumes."
