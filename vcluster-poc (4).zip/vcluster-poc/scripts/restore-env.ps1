param(
    [Parameter(Mandatory)][string]$BackupName,
    [Parameter(Mandatory)][string]$TargetEnv
)

# Derive the source environment name by stripping the timestamp suffix
$sourceEnv = $BackupName -replace "-\d{8}-\d{6}$", ""
$sourceNS  = "vcluster-$sourceEnv"
$targetNS  = "vcluster-$TargetEnv"

Write-Host "==> Restore plan"
Write-Host "    Backup          : $BackupName"
Write-Host "    Source env      : $sourceEnv  (namespace: $sourceNS)"
Write-Host "    Target env      : $TargetEnv  (namespace: $targetNS)"
Write-Host ""

Write-Host "==> Creating target namespace: $targetNS"
kubectl create namespace $targetNS --dry-run=client -o yaml | kubectl apply -f -

Write-Host "==> Running restore"
velero restore create "$TargetEnv-restore" `
    --from-backup $BackupName `
    --namespace-mappings "${sourceNS}:${targetNS}" `
    --wait

Write-Host ""
velero restore describe "$TargetEnv-restore" --details

Write-Host ""
Write-Host "==> Waiting for vCluster StatefulSet to become ready in $targetNS"
# StatefulSet retains source name after restore
kubectl rollout status statefulset/$sourceEnv -n $targetNS --timeout=120s

Write-Host ""
Write-Host "✅ Restore complete."
Write-Host ""
Write-Host "   Connect with:"
Write-Host "   vcluster connect $sourceEnv --namespace $targetNS"
Write-Host ""
Write-Host "   Add a hosts entry if needed (run pwsh as Administrator):"
Write-Host "   Add-Content -Path 'C:\Windows\System32\drivers\etc\hosts' -Value '127.0.0.1  $TargetEnv.vpoc.local'"
