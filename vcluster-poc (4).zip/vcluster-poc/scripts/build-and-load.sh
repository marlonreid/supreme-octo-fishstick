#!/usr/bin/env bash
# Build the WeatherApi image and load it into the local Rancher Desktop containerd.
# Rancher Desktop uses containerd (nerdctl), NOT the Docker daemon.
set -euo pipefail

IMAGE_NAME="weatherapi"
IMAGE_TAG="latest"
FULL_IMAGE="${IMAGE_NAME}:${IMAGE_TAG}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(dirname "${SCRIPT_DIR}")"

echo "==> Building ${FULL_IMAGE}"
docker build -t "${FULL_IMAGE}" "${REPO_ROOT}/weatherapi"

echo "==> Exporting image to tar"
docker save "${FULL_IMAGE}" -o /tmp/weatherapi.tar

echo "==> Importing into Rancher Desktop containerd (k3s)"
# Rancher Desktop exposes k3s containerd via the k3s CLI
sudo k3s ctr images import /tmp/weatherapi.tar

echo "==> Done. Image available as ${FULL_IMAGE}"
echo "    Confirm with: sudo k3s ctr images list | grep weatherapi"
