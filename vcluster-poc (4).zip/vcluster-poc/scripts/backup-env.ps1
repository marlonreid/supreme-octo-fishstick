param(
    [Parameter(Mandatory)][string]$EnvName
)

$namespace  = "vcluster-$EnvName"
$timestamp  = (Get-Date -Format "yyyyMMdd-HHmmss")
$backupName = "$EnvName-$timestamp"

Write-Host "==> Pausing vCluster '$EnvName' (quiesces writes before backup)"
vcluster pause $EnvName --namespace $namespace

Write-Host "==> Waiting 10s for StatefulSet to settle"
Start-Sleep -Seconds 10

Write-Host "==> Creating Velero backup: $backupName"
velero backup create $backupName `
    --include-namespaces $namespace `
    --default-volumes-to-fs-backup `
    --wait

Write-Host ""
velero backup describe $backupName

Write-Host "==> Resuming vCluster '$EnvName'"
vcluster resume $EnvName --namespace $namespace

Write-Host ""
Write-Host "✅ Backup complete: $backupName"
Write-Host "   Restore with: .\restore-env.ps1 -BackupName $backupName -TargetEnv <new-name>"
