#!/usr/bin/env bash
# Usage: ./snapshot-env.sh <env-name> [snapshot-name]
# Creates a vCluster snapshot stored as a Kubernetes Secret in the host namespace.
set -euo pipefail

ENV_NAME="${1:?Usage: $0 <env-name> [snapshot-name]}"
SNAPSHOT_NAME="${2:-${ENV_NAME}-snap-$(date +%Y%m%d%H%M%S)}"
NAMESPACE="vcluster-${ENV_NAME}"

echo "==> Pausing vCluster '${ENV_NAME}' before snapshot"
vcluster pause "${ENV_NAME}" --namespace "${NAMESPACE}"

echo "==> Creating snapshot: ${SNAPSHOT_NAME}"
vcluster snapshot save "${ENV_NAME}" \
  --namespace "${NAMESPACE}" \
  --name "${SNAPSHOT_NAME}"

echo "==> Resuming vCluster '${ENV_NAME}'"
vcluster resume "${ENV_NAME}" --namespace "${NAMESPACE}"

echo ""
echo "✅  Snapshot '${SNAPSHOT_NAME}' created for environment '${ENV_NAME}'."
echo "    List snapshots with: vcluster snapshot list --namespace ${NAMESPACE}"
