#!/usr/bin/env bash
# Usage: ./delete-env.sh <env-name>
set -euo pipefail

ENV_NAME="${1:?Usage: $0 <env-name>}"
NAMESPACE="vcluster-${ENV_NAME}"

echo "==> Deleting vCluster: ${ENV_NAME}"
vcluster delete "${ENV_NAME}" --namespace "${NAMESPACE}"

echo "==> Deleting namespace: ${NAMESPACE}"
kubectl delete namespace "${NAMESPACE}" --ignore-not-found

echo "✅  Environment '${ENV_NAME}' deleted."
