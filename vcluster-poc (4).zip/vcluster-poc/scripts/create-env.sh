#!/usr/bin/env bash
# Usage: ./create-env.sh <env-name>
# Example: ./create-env.sh dev
set -euo pipefail

ENV_NAME="${1:?Usage: $0 <env-name>}"
NAMESPACE="vcluster-${ENV_NAME}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
HELM_DIR="${SCRIPT_DIR}/../helm"
VCLUSTER_CONFIG="${SCRIPT_DIR}/../vcluster-config/vcluster-values.yaml"

echo "==> Creating namespace: ${NAMESPACE}"
kubectl create namespace "${NAMESPACE}" --dry-run=client -o yaml | kubectl apply -f -

echo "==> Creating vCluster: ${ENV_NAME} in namespace ${NAMESPACE}"
vcluster create "${ENV_NAME}" \
  --namespace "${NAMESPACE}" \
  --values "${VCLUSTER_CONFIG}" \
  --connect=false

echo "==> Connecting to vCluster context"
vcluster connect "${ENV_NAME}" --namespace "${NAMESPACE}" --background-proxy &
PROXY_PID=$!
sleep 5

# Switch to the vCluster kube context
VCLUSTER_CONTEXT="vcluster_${ENV_NAME}_${NAMESPACE}_$(kubectl config current-context | sed 's/.*@//')"
# Simpler: vcluster connect sets context automatically
CURRENT_CTX=$(kubectl config current-context)

echo "==> Deploying Postgres into vCluster (context: ${CURRENT_CTX})"
helm upgrade --install postgres "${HELM_DIR}/postgres" \
  --namespace default \
  --wait

echo "==> Deploying WeatherApi into vCluster"
helm upgrade --install weatherapi "${HELM_DIR}/weatherapi" \
  --namespace default \
  --set ingress.environmentName="${ENV_NAME}" \
  --wait

echo "==> Disconnecting vCluster proxy"
kill "${PROXY_PID}" 2>/dev/null || true

echo ""
echo "✅  Environment '${ENV_NAME}' is ready."
echo "    URL: http://${ENV_NAME}.vpoc.local/weather/getforecast"
echo ""
echo "    Add to /etc/hosts if not already present:"
echo "    127.0.0.1  ${ENV_NAME}.vpoc.local"
