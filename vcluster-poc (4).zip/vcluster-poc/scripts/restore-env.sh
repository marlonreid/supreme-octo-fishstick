#!/usr/bin/env bash
# Usage: ./restore-env.sh <env-name> <snapshot-name>
# Restores a vCluster from a snapshot.
set -euo pipefail

ENV_NAME="${1:?Usage: $0 <env-name> <snapshot-name>}"
SNAPSHOT_NAME="${2:?Usage: $0 <env-name> <snapshot-name>}"
NAMESPACE="vcluster-${ENV_NAME}"

echo "==> Pausing vCluster '${ENV_NAME}'"
vcluster pause "${ENV_NAME}" --namespace "${NAMESPACE}"

echo "==> Restoring from snapshot: ${SNAPSHOT_NAME}"
vcluster snapshot restore "${ENV_NAME}" \
  --namespace "${NAMESPACE}" \
  --name "${SNAPSHOT_NAME}"

echo "==> Resuming vCluster '${ENV_NAME}'"
vcluster resume "${ENV_NAME}" --namespace "${NAMESPACE}"

echo ""
echo "✅  Environment '${ENV_NAME}' restored from snapshot '${SNAPSHOT_NAME}'."
echo "    URL: http://${ENV_NAME}.vpoc.local/weather/getforecast"
