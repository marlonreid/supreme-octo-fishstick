using System.Net;
using System.Text.Json;
using LegacyOidc.Infrastructure.Legacy;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Shouldly;
using Xunit;

namespace LegacyOidc.Tests;

/// <summary>
/// Boots the API end-to-end (replacing the legacy Postgres context with an
/// in-memory one) and verifies the OpenIddict discovery surface — including
/// that the PAR endpoint is advertised.
/// </summary>
public sealed class DiscoveryEndpointTests : IClassFixture<DiscoveryEndpointTests.TestFactory>
{
    private readonly TestFactory _factory;

    public DiscoveryEndpointTests(TestFactory factory) => _factory = factory;

    [Fact]
    public async Task DiscoveryDocument_AdvertisesPushedAuthorizationEndpoint()
    {
        var client = _factory.CreateClient();

        var response = await client.GetAsync("/.well-known/openid-configuration");

        response.StatusCode.ShouldBe(HttpStatusCode.OK);

        var json = await response.Content.ReadAsStringAsync();
        using var doc = JsonDocument.Parse(json);

        doc.RootElement.TryGetProperty("pushed_authorization_request_endpoint", out var par)
            .ShouldBeTrue("PAR support is a hard requirement of this service");
        par.GetString().ShouldContain("/connect/par");
    }

    [Fact]
    public async Task DiscoveryDocument_AdvertisesAuthorizationCodeFlowWithPkce()
    {
        var client = _factory.CreateClient();

        var response = await client.GetAsync("/.well-known/openid-configuration");
        var json = await response.Content.ReadAsStringAsync();
        using var doc = JsonDocument.Parse(json);

        var grantTypes = doc.RootElement.GetProperty("grant_types_supported")
            .EnumerateArray().Select(e => e.GetString()).ToArray();

        grantTypes.ShouldContain("authorization_code");
        grantTypes.ShouldContain("refresh_token");

        var codeChallengeMethods = doc.RootElement.GetProperty("code_challenge_methods_supported")
            .EnumerateArray().Select(e => e.GetString()).ToArray();

        codeChallengeMethods.ShouldContain("S256");
    }

    public sealed class TestFactory : WebApplicationFactory<Program>
    {
        protected override void ConfigureWebHost(IWebHostBuilder builder)
        {
            builder.UseEnvironment("Development");

            builder.ConfigureServices(services =>
            {
                // Replace the Npgsql-backed legacy context with an in-memory one
                // so the test factory boots without a real Postgres dependency.
                var descriptor = services.Single(s => s.ServiceType == typeof(DbContextOptions<LegacyUserDbContext>));
                services.Remove(descriptor);

                services.AddDbContext<LegacyUserDbContext>(o => o.UseInMemoryDatabase("legacy-users-tests"));
            });
        }
    }
}
