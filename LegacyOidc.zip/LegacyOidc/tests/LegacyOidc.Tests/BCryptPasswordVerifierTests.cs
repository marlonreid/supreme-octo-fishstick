using LegacyOidc.Api.Services;
using Shouldly;
using Xunit;

namespace LegacyOidc.Tests;

public sealed class BCryptPasswordVerifierTests
{
    private readonly BCryptPasswordVerifier _sut = new();

    [Fact]
    public void Verify_ReturnsTrue_ForMatchingPasswordAndHash()
    {
        var hash = BCrypt.Net.BCrypt.HashPassword("hunter2", workFactor: 4);

        _sut.Verify("hunter2", hash).ShouldBeTrue();
    }

    [Fact]
    public void Verify_ReturnsFalse_ForNonMatchingPassword()
    {
        var hash = BCrypt.Net.BCrypt.HashPassword("hunter2", workFactor: 4);

        _sut.Verify("hunter3", hash).ShouldBeFalse();
    }

    [Theory]
    [InlineData("", "$2a$04$abcdefghijklmnopqrstuv")]
    [InlineData("password", "")]
    [InlineData(null!, "$2a$04$abcdefghijklmnopqrstuv")]
    [InlineData("password", null!)]
    public void Verify_ReturnsFalse_ForEmptyOrNullInputs(string password, string hash)
    {
        _sut.Verify(password, hash).ShouldBeFalse();
    }

    [Fact]
    public void Verify_ReturnsFalse_ForMalformedHash()
    {
        // Should not throw — malformed hash treated as a verification failure.
        _sut.Verify("any-password", "this-is-not-a-bcrypt-hash").ShouldBeFalse();
    }
}
