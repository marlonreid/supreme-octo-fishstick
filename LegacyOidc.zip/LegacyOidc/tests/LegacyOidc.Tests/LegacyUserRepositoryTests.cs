using LegacyOidc.Infrastructure.Legacy;
using Microsoft.EntityFrameworkCore;
using Shouldly;
using Xunit;

namespace LegacyOidc.Tests;

public sealed class LegacyUserDbContextTests
{
    private static LegacyUserDbContext NewContext(string dbName)
    {
        var options = new DbContextOptionsBuilder<LegacyUserDbContext>()
            .UseInMemoryDatabase(dbName)
            .Options;

        return new LegacyUserDbContext(options);
    }

    [Fact]
    public void SaveChanges_Throws()
    {
        using var ctx = NewContext(nameof(SaveChanges_Throws));

        var ex = Should.Throw<InvalidOperationException>(() => ctx.SaveChanges());
        ex.Message.ShouldContain("read-only");
    }

    [Fact]
    public async Task SaveChangesAsync_Throws()
    {
        using var ctx = NewContext(nameof(SaveChangesAsync_Throws));

        var ex = await Should.ThrowAsync<InvalidOperationException>(
            async () => await ctx.SaveChangesAsync());
        ex.Message.ShouldContain("read-only");
    }

    [Fact]
    public void QueryTrackingBehavior_IsNoTracking()
    {
        using var ctx = NewContext(nameof(QueryTrackingBehavior_IsNoTracking));

        ctx.ChangeTracker.QueryTrackingBehavior.ShouldBe(QueryTrackingBehavior.NoTracking);
    }
}

public sealed class LegacyUserRepositoryTests
{
    /// <summary>
    /// Seeds the EF Core in-memory store using a sibling write-capable DbContext
    /// pointing at the same store name. The production
    /// <see cref="LegacyUserDbContext"/> stays untouched in its read-only contract.
    /// </summary>
    private sealed class WritableSeedContext : DbContext
    {
        public WritableSeedContext(string storeName)
            : base(new DbContextOptionsBuilder<WritableSeedContext>()
                .UseInMemoryDatabase(storeName)
                .Options)
        { }

        public DbSet<LegacyUser> Users => Set<LegacyUser>();

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<LegacyUser>(b =>
            {
                b.ToTable("users");
                b.HasKey(u => u.Id);
            });
        }
    }

    private static LegacyUserDbContext SeededContext(string storeName, params LegacyUser[] users)
    {
        using (var seed = new WritableSeedContext(storeName))
        {
            seed.Users.AddRange(users);
            seed.SaveChanges();
        }

        var options = new DbContextOptionsBuilder<LegacyUserDbContext>()
            .UseInMemoryDatabase(storeName)
            .Options;

        return new LegacyUserDbContext(options);
    }

    [Fact]
    public async Task FindByUsernameAsync_ReturnsUser_WhenPresent()
    {
        using var ctx = SeededContext(
            nameof(FindByUsernameAsync_ReturnsUser_WhenPresent),
            new LegacyUser { Id = 1, Username = "alice", PasswordHash = "h" });

        var repo = new LegacyUserRepository(ctx);

        var result = await repo.FindByUsernameAsync("alice", CancellationToken.None);

        result.ShouldNotBeNull();
        result.Id.ShouldBe(1);
    }

    [Fact]
    public async Task FindByUsernameAsync_ReturnsNull_WhenAbsent()
    {
        using var ctx = SeededContext(nameof(FindByUsernameAsync_ReturnsNull_WhenAbsent));

        var repo = new LegacyUserRepository(ctx);

        var result = await repo.FindByUsernameAsync("ghost", CancellationToken.None);

        result.ShouldBeNull();
    }

    [Fact]
    public async Task FindByIdAsync_ReturnsUser_WhenPresent()
    {
        using var ctx = SeededContext(
            nameof(FindByIdAsync_ReturnsUser_WhenPresent),
            new LegacyUser { Id = 99, Username = "bob", PasswordHash = "h" });

        var repo = new LegacyUserRepository(ctx);

        var result = await repo.FindByIdAsync(99, CancellationToken.None);

        result.ShouldNotBeNull();
        result.Username.ShouldBe("bob");
    }
}
