using LegacyOidc.Api.Services;
using LegacyOidc.Infrastructure.Legacy;
using Microsoft.Extensions.Logging.Abstractions;
using NSubstitute;
using Shouldly;
using Xunit;

namespace LegacyOidc.Tests;

public sealed class UserAuthenticatorTests
{
    private readonly ILegacyUserRepository _repository = Substitute.For<ILegacyUserRepository>();
    private readonly IPasswordVerifier _verifier = Substitute.For<IPasswordVerifier>();
    private readonly UserAuthenticator _sut;

    public UserAuthenticatorTests()
    {
        _sut = new UserAuthenticator(_repository, _verifier, NullLogger<UserAuthenticator>.Instance);
    }

    [Fact]
    public async Task AuthenticateAsync_ReturnsUser_OnValidCredentials()
    {
        var user = new LegacyUser { Id = 42, Username = "alice", PasswordHash = "$2a$..." };
        _repository.FindByUsernameAsync("alice", Arg.Any<CancellationToken>()).Returns(user);
        _verifier.Verify("hunter2", "$2a$...").Returns(true);

        var result = await _sut.AuthenticateAsync("alice", "hunter2", CancellationToken.None);

        result.ShouldBeSameAs(user);
    }

    [Fact]
    public async Task AuthenticateAsync_ReturnsNull_WhenUserNotFound()
    {
        _repository.FindByUsernameAsync(Arg.Any<string>(), Arg.Any<CancellationToken>())
                   .Returns((LegacyUser?)null);

        var result = await _sut.AuthenticateAsync("ghost", "anything", CancellationToken.None);

        result.ShouldBeNull();
        _verifier.DidNotReceiveWithAnyArgs().Verify(default!, default!);
    }

    [Fact]
    public async Task AuthenticateAsync_ReturnsNull_WhenPasswordIncorrect()
    {
        var user = new LegacyUser { Id = 1, Username = "alice", PasswordHash = "$2a$..." };
        _repository.FindByUsernameAsync("alice", Arg.Any<CancellationToken>()).Returns(user);
        _verifier.Verify("wrong", "$2a$...").Returns(false);

        var result = await _sut.AuthenticateAsync("alice", "wrong", CancellationToken.None);

        result.ShouldBeNull();
    }

    [Theory]
    [InlineData("", "password")]
    [InlineData("   ", "password")]
    [InlineData("alice", "")]
    public async Task AuthenticateAsync_ReturnsNull_WithoutHittingDb_ForMissingInputs(string username, string password)
    {
        var result = await _sut.AuthenticateAsync(username, password, CancellationToken.None);

        result.ShouldBeNull();
        await _repository.DidNotReceiveWithAnyArgs().FindByUsernameAsync(default!, default);
    }

    [Fact]
    public async Task AuthenticateAsync_PropagatesCancellation()
    {
        using var cts = new CancellationTokenSource();
        cts.Cancel();

        _repository.FindByUsernameAsync(Arg.Any<string>(), cts.Token)
                   .Returns<Task<LegacyUser?>>(_ => throw new OperationCanceledException(cts.Token));

        await Should.ThrowAsync<OperationCanceledException>(
            () => _sut.AuthenticateAsync("alice", "pw", cts.Token));
    }
}
