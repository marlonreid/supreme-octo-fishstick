using System.Security.Claims;
using LegacyOidc.Infrastructure.Legacy;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using OpenIddict.Abstractions;
using OpenIddict.Server.AspNetCore;
using static OpenIddict.Abstractions.OpenIddictConstants;

namespace LegacyOidc.Api.Controllers;

/// <summary>
/// Hosts the OIDC authorize / token / userinfo / end-session endpoints.
/// PAR is handled transparently by OpenIddict's server middleware — the
/// authorize endpoint receives the dereferenced request whether it was
/// pushed or query-string-supplied.
/// </summary>
public sealed class AuthorizationController : Controller
{
    private readonly ILegacyUserRepository _users;
    private readonly ILogger<AuthorizationController> _logger;

    public AuthorizationController(ILegacyUserRepository users, ILogger<AuthorizationController> logger)
    {
        _users = users;
        _logger = logger;
    }

    [HttpGet("~/connect/authorize"), HttpPost("~/connect/authorize")]
    public async Task<IActionResult> Authorize()
    {
        var request = HttpContext.GetOpenIddictServerRequest()
            ?? throw new InvalidOperationException("The OpenID Connect request cannot be retrieved.");

        var cookieResult = await HttpContext.AuthenticateAsync(CookieAuthenticationDefaults.AuthenticationScheme);

        var requireReauth = !cookieResult.Succeeded
            || request.HasPromptValue(PromptValues.Login)
            || (request.MaxAge is { } maxAge
                && cookieResult.Properties?.IssuedUtc is { } issuedUtc
                && DateTimeOffset.UtcNow - issuedUtc > TimeSpan.FromSeconds(maxAge));

        if (requireReauth)
        {
            // Strip prompt=login so we don't loop after re-authentication.
            var parameters = Request.HasFormContentType
                ? Request.Form.Where(p => p.Key != Parameters.Prompt).ToList()
                : Request.Query.Where(p => p.Key != Parameters.Prompt).ToList();

            return Challenge(
                authenticationSchemes: CookieAuthenticationDefaults.AuthenticationScheme,
                properties: new AuthenticationProperties
                {
                    RedirectUri = Request.PathBase + Request.Path + QueryString.Create(parameters!)
                });
        }

        var subjectClaim = cookieResult.Principal?.FindFirstValue(ClaimTypes.NameIdentifier);
        if (!long.TryParse(subjectClaim, out var userId))
        {
            return Forbid(
                authenticationSchemes: OpenIddictServerAspNetCoreDefaults.AuthenticationScheme,
                properties: new AuthenticationProperties(new Dictionary<string, string?>
                {
                    [OpenIddictServerAspNetCoreConstants.Properties.Error] = Errors.AccessDenied,
                    [OpenIddictServerAspNetCoreConstants.Properties.ErrorDescription] = "The session is invalid."
                }));
        }

        var user = await _users.FindByIdAsync(userId, HttpContext.RequestAborted);
        if (user is null)
        {
            // Cookie references a user that no longer exists in the legacy DB.
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            return Forbid(
                authenticationSchemes: OpenIddictServerAspNetCoreDefaults.AuthenticationScheme,
                properties: new AuthenticationProperties(new Dictionary<string, string?>
                {
                    [OpenIddictServerAspNetCoreConstants.Properties.Error] = Errors.AccessDenied,
                    [OpenIddictServerAspNetCoreConstants.Properties.ErrorDescription] = "The user no longer exists."
                }));
        }

        var identity = BuildIdentity(user, request.GetScopes());

        return SignIn(new ClaimsPrincipal(identity), OpenIddictServerAspNetCoreDefaults.AuthenticationScheme);
    }

    [HttpPost("~/connect/token"), Produces("application/json")]
    public async Task<IActionResult> Exchange()
    {
        var request = HttpContext.GetOpenIddictServerRequest()
            ?? throw new InvalidOperationException("The OpenID Connect request cannot be retrieved.");

        if (!request.IsAuthorizationCodeGrantType() && !request.IsRefreshTokenGrantType())
        {
            throw new InvalidOperationException("The specified grant type is not supported.");
        }

        var result = await HttpContext.AuthenticateAsync(OpenIddictServerAspNetCoreDefaults.AuthenticationScheme);
        if (result.Principal is null)
        {
            return Forbid(
                authenticationSchemes: OpenIddictServerAspNetCoreDefaults.AuthenticationScheme,
                properties: new AuthenticationProperties(new Dictionary<string, string?>
                {
                    [OpenIddictServerAspNetCoreConstants.Properties.Error] = Errors.InvalidGrant,
                    [OpenIddictServerAspNetCoreConstants.Properties.ErrorDescription] = "The authorization is no longer valid."
                }));
        }

        var subjectClaim = result.Principal.GetClaim(Claims.Subject);
        if (!long.TryParse(subjectClaim, out var userId))
        {
            return Forbid(OpenIddictServerAspNetCoreDefaults.AuthenticationScheme);
        }

        // Re-fetch from the source of truth on every token exchange so that
        // a deleted/renamed legacy user can no longer obtain new tokens.
        var user = await _users.FindByIdAsync(userId, HttpContext.RequestAborted);
        if (user is null)
        {
            return Forbid(
                authenticationSchemes: OpenIddictServerAspNetCoreDefaults.AuthenticationScheme,
                properties: new AuthenticationProperties(new Dictionary<string, string?>
                {
                    [OpenIddictServerAspNetCoreConstants.Properties.Error] = Errors.InvalidGrant,
                    [OpenIddictServerAspNetCoreConstants.Properties.ErrorDescription] = "The user no longer exists."
                }));
        }

        var identity = BuildIdentity(user, result.Principal.GetScopes());

        return SignIn(new ClaimsPrincipal(identity), OpenIddictServerAspNetCoreDefaults.AuthenticationScheme);
    }

    [HttpGet("~/connect/userinfo"), HttpPost("~/connect/userinfo")]
    [Microsoft.AspNetCore.Authorization.Authorize(AuthenticationSchemes = OpenIddictServerAspNetCoreDefaults.AuthenticationScheme)]
    public async Task<IActionResult> UserInfo()
    {
        var subjectClaim = User.GetClaim(Claims.Subject);
        if (!long.TryParse(subjectClaim, out var userId))
        {
            return Challenge(
                authenticationSchemes: OpenIddictServerAspNetCoreDefaults.AuthenticationScheme,
                properties: new AuthenticationProperties(new Dictionary<string, string?>
                {
                    [OpenIddictServerAspNetCoreConstants.Properties.Error] = Errors.InvalidToken
                }));
        }

        var user = await _users.FindByIdAsync(userId, HttpContext.RequestAborted);
        if (user is null)
        {
            return Challenge(
                authenticationSchemes: OpenIddictServerAspNetCoreDefaults.AuthenticationScheme,
                properties: new AuthenticationProperties(new Dictionary<string, string?>
                {
                    [OpenIddictServerAspNetCoreConstants.Properties.Error] = Errors.InvalidToken,
                    [OpenIddictServerAspNetCoreConstants.Properties.ErrorDescription] = "The user no longer exists."
                }));
        }

        var claims = new Dictionary<string, object>(StringComparer.Ordinal)
        {
            [Claims.Subject] = user.Id.ToString()
        };

        if (User.HasScope(Scopes.Profile))
        {
            claims[Claims.PreferredUsername] = user.Username;
            claims[Claims.Name] = user.Username;
        }

        return Ok(claims);
    }

    [HttpGet("~/connect/logout"), HttpPost("~/connect/logout")]
    public async Task<IActionResult> Logout()
    {
        await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);

        return SignOut(
            authenticationSchemes: OpenIddictServerAspNetCoreDefaults.AuthenticationScheme,
            properties: new AuthenticationProperties { RedirectUri = "/" });
    }

    private static ClaimsIdentity BuildIdentity(LegacyUser user, IEnumerable<string> scopes)
    {
        var identity = new ClaimsIdentity(
            authenticationType: TokenValidationParameters.DefaultAuthenticationType,
            nameType: Claims.Name,
            roleType: Claims.Role);

        identity.SetClaim(Claims.Subject, user.Id.ToString())
                .SetClaim(Claims.Name, user.Username)
                .SetClaim(Claims.PreferredUsername, user.Username);

        identity.SetScopes(scopes);

        identity.SetDestinations(claim => claim.Type switch
        {
            Claims.Name or Claims.PreferredUsername
                when claim.Subject!.HasScope(Scopes.Profile) =>
                    new[] { Destinations.AccessToken, Destinations.IdentityToken },

            // Subject claim is always emitted to both tokens.
            Claims.Subject => new[] { Destinations.AccessToken, Destinations.IdentityToken },

            _ => new[] { Destinations.AccessToken }
        });

        return identity;
    }
}
