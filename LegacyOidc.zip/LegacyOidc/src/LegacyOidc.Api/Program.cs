using LegacyOidc.Api.Controllers;
using LegacyOidc.Api.Services;
using LegacyOidc.Api.Telemetry;
using LegacyOidc.Infrastructure.Legacy;
using LegacyOidc.Infrastructure.OpenIddict;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.EntityFrameworkCore;
using OpenIddict.Abstractions;

var builder = WebApplication.CreateBuilder(args);

// ---------------------------------------------------------------------------
// Logging / metrics / tracing
// ---------------------------------------------------------------------------
builder.Services.AddObservability(builder.Configuration, builder.Logging);

// ---------------------------------------------------------------------------
// MVC / Razor Pages
// ---------------------------------------------------------------------------
builder.Services.AddControllersWithViews();
builder.Services.AddRazorPages();

// ---------------------------------------------------------------------------
// Cookie auth — the local session backing the Razor login page.
// ---------------------------------------------------------------------------
builder.Services
    .AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.LoginPath = "/Account/Login";
        options.LogoutPath = "/connect/logout";
        options.ExpireTimeSpan = TimeSpan.FromHours(8);
        options.SlidingExpiration = false;
        options.Cookie.Name = "legacy-oidc.session";
        options.Cookie.HttpOnly = true;
        options.Cookie.SameSite = SameSiteMode.Lax;
        options.Cookie.SecurePolicy = CookieSecurePolicy.SameAsRequest;
    });

// ---------------------------------------------------------------------------
// Legacy users DB (read-only Postgres)
// ---------------------------------------------------------------------------
builder.Services.AddDbContext<LegacyUserDbContext>(options =>
{
    var connectionString = builder.Configuration.GetConnectionString("LegacyUsers")
        ?? throw new InvalidOperationException("ConnectionStrings:LegacyUsers is not configured.");

    options.UseNpgsql(connectionString, npgsql =>
    {
        npgsql.EnableRetryOnFailure(maxRetryCount: 3);
    });

    // Defensive — also enforced inside the DbContext itself.
    options.UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking);
});

builder.Services.AddScoped<ILegacyUserRepository, LegacyUserRepository>();

// ---------------------------------------------------------------------------
// OpenIddict storage (in-memory for the POC; swap provider for production)
// ---------------------------------------------------------------------------
builder.Services.AddDbContext<OpenIddictDbContext>(options =>
{
    options.UseInMemoryDatabase("openiddict");
    options.UseOpenIddict();
});

// ---------------------------------------------------------------------------
// OpenIddict server
// ---------------------------------------------------------------------------
builder.Services
    .AddOpenIddict()
    .AddCore(options =>
    {
        options.UseEntityFrameworkCore()
               .UseDbContext<OpenIddictDbContext>();
    })
    .AddServer(options =>
    {
        options
            .SetAuthorizationEndpointUris("connect/authorize")
            .SetTokenEndpointUris("connect/token")
            .SetUserInfoEndpointUris("connect/userinfo")
            .SetEndSessionEndpointUris("connect/logout")
            .SetIntrospectionEndpointUris("connect/introspect")
            .SetPushedAuthorizationEndpointUris("connect/par");

        options
            .AllowAuthorizationCodeFlow()
            .AllowRefreshTokenFlow()
            .RequireProofKeyForCodeExchange();

        // To make PAR mandatory (recommended when the only client is Keycloak,
        // which supports PAR natively), uncomment:
        // options.RequirePushedAuthorizationRequests();

        options.RegisterScopes(
            OpenIddictConstants.Scopes.OpenId,
            OpenIddictConstants.Scopes.Profile,
            OpenIddictConstants.Scopes.Email,
            OpenIddictConstants.Scopes.OfflineAccess);

        options.SetAccessTokenLifetime(TimeSpan.FromMinutes(15));
        options.SetRefreshTokenLifetime(TimeSpan.FromHours(8));
        options.SetAuthorizationCodeLifetime(TimeSpan.FromMinutes(2));

        // Development signing/encryption — ephemeral, regenerated per process.
        // Production: load an RSA key mounted as a Kubernetes Secret. See README.
        if (builder.Environment.IsDevelopment())
        {
            options.AddDevelopmentEncryptionCertificate()
                   .AddDevelopmentSigningCertificate();
        }
        else
        {
            var signingKeyPath = builder.Configuration["OpenIddict:SigningKeyPath"];
            var encryptionKeyPath = builder.Configuration["OpenIddict:EncryptionKeyPath"];

            if (string.IsNullOrEmpty(signingKeyPath) || string.IsNullOrEmpty(encryptionKeyPath))
            {
                throw new InvalidOperationException(
                    "OpenIddict:SigningKeyPath and OpenIddict:EncryptionKeyPath must be set in non-development environments. " +
                    "Mount RSA keys via a Kubernetes Secret.");
            }

            options.AddSigningCertificate(LoadCertificate(signingKeyPath))
                   .AddEncryptionCertificate(LoadCertificate(encryptionKeyPath));
        }

        options.UseAspNetCore()
               .EnableAuthorizationEndpointPassthrough()
               .EnableTokenEndpointPassthrough()
               .EnableUserInfoEndpointPassthrough()
               .EnableEndSessionEndpointPassthrough();
    })
    .AddValidation(options =>
    {
        options.UseLocalServer();
        options.UseAspNetCore();
    });

// ---------------------------------------------------------------------------
// App services
// ---------------------------------------------------------------------------
builder.Services.AddScoped<IPasswordVerifier, BCryptPasswordVerifier>();
builder.Services.AddScoped<IUserAuthenticator, UserAuthenticator>();
builder.Services.AddHostedService<ClientSeeder>();

builder.Services.AddHealthChecks()
    .AddDbContextCheck<LegacyUserDbContext>("legacy-users-db");

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();

app.UseAuthentication();
app.UseAuthorization();

app.MapRazorPages();
app.MapControllers();
app.MapHealthChecks("/health");

app.Run();

static System.Security.Cryptography.X509Certificates.X509Certificate2 LoadCertificate(string path)
{
    // Supports either a full PFX (with password supplied via env) or a PEM cert + key pair.
    // Implementation kept minimal here — extend as needed.
    return new System.Security.Cryptography.X509Certificates.X509Certificate2(path);
}

// Exposed for WebApplicationFactory in tests.
public partial class Program { }
