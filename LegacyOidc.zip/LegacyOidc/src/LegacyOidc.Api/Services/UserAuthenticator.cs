using System.Diagnostics;
using LegacyOidc.Infrastructure.Legacy;

namespace LegacyOidc.Api.Services;

public interface IUserAuthenticator
{
    Task<LegacyUser?> AuthenticateAsync(string username, string password, CancellationToken cancellationToken);
}

public sealed class UserAuthenticator : IUserAuthenticator
{
    internal static readonly ActivitySource ActivitySource = new("LegacyOidc.UserAuthenticator");

    private readonly ILegacyUserRepository _repository;
    private readonly IPasswordVerifier _passwordVerifier;
    private readonly ILogger<UserAuthenticator> _logger;

    public UserAuthenticator(
        ILegacyUserRepository repository,
        IPasswordVerifier passwordVerifier,
        ILogger<UserAuthenticator> logger)
    {
        _repository = repository;
        _passwordVerifier = passwordVerifier;
        _logger = logger;
    }

    public async Task<LegacyUser?> AuthenticateAsync(
        string username,
        string password,
        CancellationToken cancellationToken)
    {
        using var activity = ActivitySource.StartActivity("Authenticate");

        if (string.IsNullOrWhiteSpace(username) || string.IsNullOrEmpty(password))
        {
            activity?.SetTag("auth.outcome", "missing_input");
            return null;
        }

        var user = await _repository.FindByUsernameAsync(username, cancellationToken);
        if (user is null)
        {
            // Log without including the username at info level — log analytics
            // queries can correlate via trace id.
            _logger.LogInformation("Authentication failed: user not found");
            activity?.SetTag("auth.outcome", "user_not_found");
            return null;
        }

        if (!_passwordVerifier.Verify(password, user.PasswordHash))
        {
            _logger.LogInformation("Authentication failed: bad password for user id {UserId}", user.Id);
            activity?.SetTag("auth.outcome", "bad_password");
            activity?.SetTag("auth.user_id", user.Id);
            return null;
        }

        _logger.LogInformation("Authentication succeeded for user id {UserId}", user.Id);
        activity?.SetTag("auth.outcome", "success");
        activity?.SetTag("auth.user_id", user.Id);
        return user;
    }
}
