namespace LegacyOidc.Api.Services;

public interface IPasswordVerifier
{
    bool Verify(string password, string hash);
}

public sealed class BCryptPasswordVerifier : IPasswordVerifier
{
    public bool Verify(string password, string hash)
    {
        if (string.IsNullOrEmpty(password) || string.IsNullOrEmpty(hash))
        {
            return false;
        }

        try
        {
            return BCrypt.Net.BCrypt.Verify(password, hash);
        }
        catch (BCrypt.Net.SaltParseException)
        {
            // Malformed hash — treat as failed verification rather than 500.
            return false;
        }
    }
}
