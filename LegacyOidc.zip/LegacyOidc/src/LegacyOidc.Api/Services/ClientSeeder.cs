using LegacyOidc.Infrastructure.OpenIddict;
using Microsoft.EntityFrameworkCore;
using OpenIddict.Abstractions;
using static OpenIddict.Abstractions.OpenIddictConstants;

namespace LegacyOidc.Api.Services;

/// <summary>
/// Seeds the Keycloak client registration into OpenIddict's store on startup.
/// Configuration is bound from <c>OpenIddict:Clients</c> in appsettings; if no
/// clients are configured a single development client (id <c>keycloak</c>) is
/// seeded with placeholder values.
/// </summary>
public sealed class ClientSeeder : IHostedService
{
    private readonly IServiceProvider _services;
    private readonly ILogger<ClientSeeder> _logger;
    private readonly IConfiguration _configuration;

    public ClientSeeder(
        IServiceProvider services,
        IConfiguration configuration,
        ILogger<ClientSeeder> logger)
    {
        _services = services;
        _configuration = configuration;
        _logger = logger;
    }

    public async Task StartAsync(CancellationToken cancellationToken)
    {
        await using var scope = _services.CreateAsyncScope();

        // Ensure the in-memory store is created (no-op on relational, idempotent here).
        var context = scope.ServiceProvider.GetRequiredService<OpenIddictDbContext>();
        await context.Database.EnsureCreatedAsync(cancellationToken);

        var manager = scope.ServiceProvider.GetRequiredService<IOpenIddictApplicationManager>();

        var clients = _configuration.GetSection("OpenIddict:Clients").Get<List<ClientConfig>>()
            ?? new List<ClientConfig>
            {
                new()
                {
                    ClientId = "keycloak",
                    ClientSecret = "keycloak-dev-secret-change-me",
                    DisplayName = "Keycloak (development)",
                    RedirectUris = new List<string>
                    {
                        "http://localhost:8080/realms/master/broker/legacy-oidc/endpoint"
                    },
                    PostLogoutRedirectUris = new List<string>()
                }
            };

        foreach (var client in clients)
        {
            var existing = await manager.FindByClientIdAsync(client.ClientId, cancellationToken);

            if (existing is null)
            {
                await manager.CreateAsync(BuildDescriptor(client), cancellationToken);
                _logger.LogInformation("Seeded OpenIddict client {ClientId}", client.ClientId);
            }
            else
            {
                // POC behaviour: existing clients are kept as-is. Restart the
                // process to re-seed (the in-memory store is empty after restart).
                _logger.LogDebug("OpenIddict client {ClientId} already present; skipping", client.ClientId);
            }
        }
    }

    public Task StopAsync(CancellationToken cancellationToken) => Task.CompletedTask;

    private static OpenIddictApplicationDescriptor BuildDescriptor(ClientConfig client)
    {
        var descriptor = new OpenIddictApplicationDescriptor
        {
            ClientId = client.ClientId,
            ClientSecret = client.ClientSecret,
            DisplayName = client.DisplayName,
            ConsentType = ConsentTypes.Implicit,
            ClientType = ClientTypes.Confidential,
            Permissions =
            {
                Permissions.Endpoints.Authorization,
                Permissions.Endpoints.Token,
                Permissions.Endpoints.EndSession,
                Permissions.Endpoints.PushedAuthorization,
                Permissions.Endpoints.Introspection,
                Permissions.GrantTypes.AuthorizationCode,
                Permissions.GrantTypes.RefreshToken,
                Permissions.ResponseTypes.Code,
                Permissions.Scopes.Email,
                Permissions.Scopes.Profile,
                Permissions.Prefixes.Scope + Scopes.OpenId,
                Permissions.Prefixes.Scope + Scopes.OfflineAccess
            },
            Requirements =
            {
                // PKCE remains required even when PAR is in use.
                Requirements.Features.ProofKeyForCodeExchange
            }
        };

        foreach (var redirect in client.RedirectUris)
        {
            descriptor.RedirectUris.Add(new Uri(redirect));
        }

        foreach (var redirect in client.PostLogoutRedirectUris)
        {
            descriptor.PostLogoutRedirectUris.Add(new Uri(redirect));
        }

        return descriptor;
    }

    private sealed class ClientConfig
    {
        public string ClientId { get; set; } = string.Empty;
        public string ClientSecret { get; set; } = string.Empty;
        public string DisplayName { get; set; } = string.Empty;
        public List<string> RedirectUris { get; set; } = new();
        public List<string> PostLogoutRedirectUris { get; set; } = new();
    }
}
