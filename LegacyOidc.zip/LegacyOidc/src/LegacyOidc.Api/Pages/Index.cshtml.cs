using Microsoft.AspNetCore.Mvc.RazorPages;

namespace LegacyOidc.Api.Pages;

public sealed class IndexModel : PageModel { }
