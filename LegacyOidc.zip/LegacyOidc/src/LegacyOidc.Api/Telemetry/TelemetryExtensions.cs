using LegacyOidc.Api.Services;
using OpenTelemetry;
using OpenTelemetry.Logs;
using OpenTelemetry.Metrics;
using OpenTelemetry.Resources;
using OpenTelemetry.Trace;

namespace LegacyOidc.Api.Telemetry;

public static class TelemetryExtensions
{
    public const string ServiceName = "legacy-oidc";

    public static IServiceCollection AddObservability(
        this IServiceCollection services,
        IConfiguration configuration,
        ILoggingBuilder logging)
    {
        var resource = ResourceBuilder.CreateDefault()
            .AddService(ServiceName, serviceVersion: typeof(TelemetryExtensions).Assembly.GetName().Version?.ToString())
            .AddEnvironmentVariableDetector();

        services
            .AddOpenTelemetry()
            .ConfigureResource(b => b.AddService(ServiceName))
            .WithMetrics(metrics => metrics
                .AddAspNetCoreInstrumentation()
                .AddHttpClientInstrumentation()
                .AddRuntimeInstrumentation()
                .AddMeter("LegacyOidc.*")
                .AddOtlpExporter())
            .WithTracing(tracing => tracing
                .AddAspNetCoreInstrumentation(o =>
                {
                    // Don't trace static asset noise.
                    o.Filter = ctx => !ctx.Request.Path.StartsWithSegments("/_framework")
                                   && !ctx.Request.Path.StartsWithSegments("/css")
                                   && !ctx.Request.Path.StartsWithSegments("/lib");
                })
                .AddHttpClientInstrumentation()
                .AddEntityFrameworkCoreInstrumentation(o =>
                {
                    o.SetDbStatementForText = false; // never emit SQL — may contain PII
                })
                .AddSource(UserAuthenticator.ActivitySource.Name)
                .AddSource("OpenIddict.Server")
                .AddOtlpExporter());

        logging.AddOpenTelemetry(o =>
        {
            o.IncludeFormattedMessage = true;
            o.IncludeScopes = true;
            o.ParseStateValues = true;
            o.SetResourceBuilder(resource);
            o.AddOtlpExporter();
        });

        return services;
    }
}
