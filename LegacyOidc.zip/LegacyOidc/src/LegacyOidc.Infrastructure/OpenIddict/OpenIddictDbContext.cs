using Microsoft.EntityFrameworkCore;

namespace LegacyOidc.Infrastructure.OpenIddict;

/// <summary>
/// Backing store for OpenIddict's applications, scopes, authorizations and tokens.
/// Configured against EF Core's in-memory provider for the POC. To migrate to
/// production: register a relational provider (Postgres/SQL Server) against this
/// same context — no other code changes required.
/// </summary>
public sealed class OpenIddictDbContext : DbContext
{
    public OpenIddictDbContext(DbContextOptions<OpenIddictDbContext> options) : base(options) { }
}
