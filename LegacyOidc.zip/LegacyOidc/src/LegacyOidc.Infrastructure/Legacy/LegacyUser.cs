namespace LegacyOidc.Infrastructure.Legacy;

/// <summary>
/// Read-only projection of a row in the legacy <c>users</c> table.
/// The <see cref="Id"/> is the immutable primary key and is used as the
/// OIDC <c>sub</c> claim. Username is informational only.
/// </summary>
/// <remarks>
/// The Id type is set to <see cref="long"/> as a reasonable default for
/// legacy postgres tables using <c>SERIAL</c>/<c>BIGSERIAL</c>. Adjust to
/// <c>Guid</c> or <c>int</c> if your schema differs.
/// </remarks>
public sealed class LegacyUser
{
    public long Id { get; init; }
    public string Username { get; init; } = string.Empty;
    public string PasswordHash { get; init; } = string.Empty;
}
