using Microsoft.EntityFrameworkCore;

namespace LegacyOidc.Infrastructure.Legacy;

/// <summary>
/// Read-only EF Core context over the legacy users database.
/// Migrations are intentionally not registered. Writes throw at runtime
/// to enforce the read-only contract even if a future caller tries to
/// add tracked entities.
/// </summary>
public sealed class LegacyUserDbContext : DbContext
{
    public LegacyUserDbContext(DbContextOptions<LegacyUserDbContext> options) : base(options)
    {
        ChangeTracker.QueryTrackingBehavior = QueryTrackingBehavior.NoTracking;
        ChangeTracker.AutoDetectChangesEnabled = false;
        SavingChanges += ThrowOnSave;
    }

    public DbSet<LegacyUser> Users => Set<LegacyUser>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<LegacyUser>(b =>
        {
            b.ToTable("users");
            b.HasKey(u => u.Id);
            b.Property(u => u.Id).HasColumnName("id");
            b.Property(u => u.Username).HasColumnName("username").IsRequired();
            b.Property(u => u.PasswordHash).HasColumnName("password_hash").IsRequired();
            b.HasIndex(u => u.Username).IsUnique();
        });
    }

    public override int SaveChanges() =>
        throw new InvalidOperationException("LegacyUserDbContext is read-only.");

    public override int SaveChanges(bool acceptAllChangesOnSuccess) =>
        throw new InvalidOperationException("LegacyUserDbContext is read-only.");

    public override Task<int> SaveChangesAsync(CancellationToken cancellationToken = default) =>
        throw new InvalidOperationException("LegacyUserDbContext is read-only.");

    public override Task<int> SaveChangesAsync(bool acceptAllChangesOnSuccess, CancellationToken cancellationToken = default) =>
        throw new InvalidOperationException("LegacyUserDbContext is read-only.");

    private static void ThrowOnSave(object? sender, Microsoft.EntityFrameworkCore.SavingChangesEventArgs e) =>
        throw new InvalidOperationException("LegacyUserDbContext is read-only.");
}
