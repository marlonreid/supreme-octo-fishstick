using Microsoft.EntityFrameworkCore;

namespace LegacyOidc.Infrastructure.Legacy;

public interface ILegacyUserRepository
{
    Task<LegacyUser?> FindByUsernameAsync(string username, CancellationToken cancellationToken);
    Task<LegacyUser?> FindByIdAsync(long id, CancellationToken cancellationToken);
}

public sealed class LegacyUserRepository : ILegacyUserRepository
{
    private readonly LegacyUserDbContext _db;

    public LegacyUserRepository(LegacyUserDbContext db) => _db = db;

    public Task<LegacyUser?> FindByUsernameAsync(string username, CancellationToken cancellationToken) =>
        _db.Users.AsNoTracking()
            .FirstOrDefaultAsync(u => u.Username == username, cancellationToken);

    public Task<LegacyUser?> FindByIdAsync(long id, CancellationToken cancellationToken) =>
        _db.Users.AsNoTracking()
            .FirstOrDefaultAsync(u => u.Id == id, cancellationToken);
}
