-- Schema and test data for the legacy users database.
-- The OIDC service is granted SELECT only — no writes.

CREATE TABLE IF NOT EXISTS users (
    id            BIGSERIAL PRIMARY KEY,
    username      TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL
);

-- Sample users with verified bcrypt hashes (work factor 10).
--   alice / hunter2
--   bob   / correct horse battery staple
INSERT INTO users (username, password_hash) VALUES
    ('alice', '$2b$10$PEWKLgnmZSTMTJBB7vB0yuNHxd7ccXlp6G/QRwI7x9b.RALgJyfSS'),
    ('bob',   '$2b$10$NSYEi7k3T6WHVLjX4jWTHejrJFiAxmCnVmZFMFjZnC1AcaPfjFvmW')
ON CONFLICT (username) DO NOTHING;

-- Read-only role for the OIDC service.
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'legacy_ro') THEN
        CREATE ROLE legacy_ro LOGIN PASSWORD 'legacy_ro_pw';
    END IF;
END
$$;

GRANT CONNECT ON DATABASE legacy_users TO legacy_ro;
GRANT USAGE ON SCHEMA public TO legacy_ro;
GRANT SELECT ON users TO legacy_ro;

-- Defensive: revoke any default write permissions.
REVOKE INSERT, UPDATE, DELETE, TRUNCATE ON users FROM legacy_ro;
