# Legacy OIDC

A C# / ASP.NET Core service that exposes a legacy Postgres `users` table as an
OpenID Connect identity provider, intended to be federated into Keycloak as an
OIDC IdP.

Targets **.NET 10 (LTS)**. Requires the .NET 10 SDK to build locally; the
container build is self-contained.

The service:

- Reads from the legacy `users` table read-only (no migrations, writes throw).
- Verifies passwords against the legacy bcrypt hashes.
- Issues OIDC tokens via [OpenIddict](https://documentation.openiddict.com).
- Supports **PAR** (RFC 9126), **PKCE** (RFC 7636), authorization code flow,
  refresh tokens, and standard discovery / userinfo / introspection / end-session
  endpoints.
- Emits OpenTelemetry traces, metrics, and logs over OTLP.
- Renders a minimal Razor Pages login form.

The `sub` claim in issued tokens is the legacy `users.id`. The username is exposed
as `preferred_username` and `name` (when the `profile` scope is granted).

---

## Why the architecture looks this way

| Decision | Reasoning |
|---|---|
| Not a Keycloak SPI | Username clashes with the existing federated source; SPI couples deployment to the Keycloak lifecycle. An external OIDC IdP is independent. |
| Username collisions avoided | The OIDC `sub` is `users.id`, not the username. Two `alice`s in two IdPs become two distinct subjects in Keycloak. |
| EF Core In-Memory for OpenIddict | Simplest possible POC backing — zero infrastructure. Provider swap is a one-line change for production. |
| **Not** degraded mode | Degraded mode disables OpenIddict's stores entirely. PAR requires server-side request storage, single-use auth codes need replay tracking, and refresh-token rotation needs persistence. All would have to be re-implemented by hand. |
| Read-only `LegacyUserDbContext` | Migrations not registered, `SaveChanges*` overridden to throw, `NoTracking` set globally. The Postgres role used (`legacy_ro`) is also `SELECT`-only as defence in depth. |
| Re-fetch user on every token exchange | A user deleted in the legacy DB cannot refresh tokens. |
| Ephemeral dev signing keys in the POC | Auto-generated per process. Production loads RSA keys from a Kubernetes Secret — see below. |

---

## Project layout

```
LegacyOidc/
├── src/
│   ├── LegacyOidc.Api/                 ASP.NET Core host + OpenIddict server + Razor login
│   └── LegacyOidc.Infrastructure/      Read-only legacy DbContext + OpenIddict DbContext
├── tests/
│   └── LegacyOidc.Tests/               xUnit + NSubstitute + WebApplicationFactory
├── deploy/
│   └── postgres-init.sql               Schema, sample users, RO role
├── docker-compose.yml                  Postgres + the API
└── README.md
```

---

## Running the POC locally

```bash
docker compose up --build
```

That brings up:

- Postgres on `localhost:5432` with two sample users (see below).
- The OIDC service on `http://localhost:5050`.

Sample users (seeded by `deploy/postgres-init.sql`):

| Username | Password |
|---|---|
| `alice` | `hunter2` |
| `bob`   | `correct horse battery staple` |

Verify discovery:

```bash
curl http://localhost:5050/.well-known/openid-configuration | jq .
```

The response will include `pushed_authorization_request_endpoint`,
`code_challenge_methods_supported: ["S256"]`, and the standard endpoints.

---

## Wiring this into Keycloak

In Keycloak admin → your realm → **Identity Providers** → **Add provider** →
**OpenID Connect v1.0**.

| Field | Value |
|---|---|
| Alias | `legacy-oidc` |
| Discovery endpoint | `http://legacy-oidc:5050/.well-known/openid-configuration` |
| Client authentication | Client secret sent as basic auth |
| Client ID | `keycloak` |
| Client Secret | matches `OpenIddict__Clients__0__ClientSecret` (default: `keycloak-dev-secret-change-me`) |
| Default scopes | `openid profile` |
| PKCE Method | `S256` |
| Pushed Authorization | enabled (Keycloak 24+) |

The redirect URI Keycloak provides (under "Endpoints") must be added to the client's
`RedirectUris` list in `appsettings.json` or `OpenIddict__Clients__0__RedirectUris__0`
env var. The default value points at
`http://localhost:8080/realms/master/broker/legacy-oidc/endpoint` — adjust for
your realm.

To prevent username clashes with your existing federated IdP, configure the
**username template** mapper on the Keycloak side, e.g. `legacy-${ALIAS}-${CLAIM.preferred_username}`.

---

## Testing

```bash
dotnet test
```

Coverage:

- **`BCryptPasswordVerifierTests`** — happy path, mismatch, malformed-hash safety,
  null/empty inputs.
- **`UserAuthenticatorTests`** (NSubstitute) — happy path, user-not-found, bad
  password, missing input doesn't hit the DB, cancellation propagates.
- **`LegacyUserDbContextTests`** — `SaveChanges` and `SaveChangesAsync` both throw,
  `NoTracking` is set.
- **`LegacyUserRepositoryTests`** — find by username and id.
- **`DiscoveryEndpointTests`** (`WebApplicationFactory<Program>`) — boots the full
  app with the legacy DB swapped to in-memory; asserts that PAR is advertised
  in the discovery document and that PKCE/S256 is supported.

NSubstitute is the only mocking framework. `xUnit` for the runner. `Shouldly`
for assertion readability — chosen over FluentAssertions because v8+ of the
latter requires a paid commercial licence (Apache 2.0 was abandoned in Jan 2025).
Shouldly remains BSD-licensed and free for commercial use.

---

## Observability

OpenTelemetry is wired up in `Telemetry/TelemetryExtensions.cs` and configured via the
standard `OTEL_*` environment variables (most importantly `OTEL_EXPORTER_OTLP_ENDPOINT`).

- **Traces:** ASP.NET Core, HttpClient, EF Core (without SQL text — never emit
  query text, the legacy DB has hashed credentials in it), the
  `LegacyOidc.UserAuthenticator` activity source, and `OpenIddict.Server`.
- **Metrics:** ASP.NET Core, HttpClient, .NET runtime.
- **Logs:** structured logs exported via OTLP.

Every authentication attempt produces an activity tagged with `auth.outcome`
(`success`, `user_not_found`, `bad_password`, `missing_input`).

---

## Production hardening checklist

This is a POC. Before anything resembling production:

1. **Swap the OpenIddict store to a relational provider.** The `OpenIddictDbContext`
   is the only thing to change; OpenIddict's API stays identical.

   ```csharp
   builder.Services.AddDbContext<OpenIddictDbContext>(options =>
       options.UseNpgsql(connectionString).UseOpenIddict());
   ```

2. **Mount real signing and encryption keys via Kubernetes Secrets.** The dev
   certificates regenerate per pod restart, which invalidates all live sessions.

   ```yaml
   apiVersion: v1
   kind: Secret
   metadata:
     name: legacy-oidc-keys
   type: Opaque
   data:
     signing.pfx:    <base64>
     encryption.pfx: <base64>
   ```

   Mount as a volume at `/etc/oidc-keys/`, then set:

   ```
   OpenIddict__SigningKeyPath=/etc/oidc-keys/signing.pfx
   OpenIddict__EncryptionKeyPath=/etc/oidc-keys/encryption.pfx
   ```

   For automated rotation, use cert-manager or external-secrets to rotate the
   secret in place. OpenIddict supports multiple registered keys for rollover.

3. **Make PAR mandatory** by uncommenting `options.RequirePushedAuthorizationRequests()`
   in `Program.cs`. Keycloak supports PAR natively from v24, so there's no
   downside once you've confirmed your Keycloak version.

4. **Postgres role.** The included `postgres-init.sql` already creates `legacy_ro`
   with `SELECT` only on `users`. Use that connection string in production —
   not a superuser.

5. **Connection string secrets.** Use Kubernetes Secret + `valueFrom.secretKeyRef`,
   not env vars in plaintext.

6. **HTTPS termination.** The container listens on HTTP:8080. Terminate TLS at
   the ingress and ensure `Forwarded` headers are honoured (`UseForwardedHeaders`)
   if you need correct issuer URLs in tokens.

7. **Issuer URL.** Set `OpenIddict__Issuer` to the public-facing URL. By default
   OpenIddict derives it from the request, which is wrong behind a load balancer
   unless forwarded headers are configured.

8. **Rate limiting on `/Account/Login`.** Add ASP.NET Core's rate limiter to slow
   down credential stuffing — bcrypt's work factor helps but isn't enough on its own.

9. **Audit logging.** The current `_logger.LogInformation` calls cover the basics;
   for compliance you'll want a dedicated audit sink (separate index, longer retention).

---

## Known POC trade-offs

- **No consent screen.** Clients are configured `ConsentTypes.Implicit`. Fine for
  a federation client; if you ever expose this to third parties, change it.
- **No account lockout.** Repeated bad-password attempts will not lock the user
  out. Add this if the legacy DB doesn't already track failed-login state.
- **No password reset / change flow.** Out of scope — passwords are managed in the
  legacy system.
- **In-memory OpenIddict store** loses authorizations on pod restart. Auth codes
  are 2-minute-lived so users in flight will retry. Refresh tokens currently in
  use will fail until reissue. Acceptable for POC; not for production (see #1 above).
